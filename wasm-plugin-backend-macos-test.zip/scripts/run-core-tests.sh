#!/bin/bash
# Offline reproduction of the patched-runtime Core tests.
# Builds the native Core/test harness and runs all Wasm execution in wasm3
# (interpreter, no JIT). No network access is required.
set -uo pipefail

LAB_ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
cd "$LAB_ROOT"
mkdir -p logs

if ! bash "$LAB_ROOT/core/build-core.sh" > "$LAB_ROOT/logs/core-build.log" 2>&1; then
    echo "FAIL stage=build-core; see logs/core-build.log" >&2
    tail -40 "$LAB_ROOT/logs/core-build.log" >&2
    exit 1
fi

if [ -x /usr/bin/time ]; then
    if [ "$(uname -s)" = Darwin ]; then time_args=(-l); else time_args=(-v); fi
    /usr/bin/time "${time_args[@]}" "$LAB_ROOT/work/runtime/core_tests" "$LAB_ROOT" > logs/core-tests-console.txt 2> logs/core-tests-time.txt
    rc=$?
else
    { time "$LAB_ROOT/work/runtime/core_tests" "$LAB_ROOT" > logs/core-tests-console.txt; } 2> logs/core-tests-time.txt
    rc=$?
fi

cat "$LAB_ROOT/logs/core-tests-console.txt"
if [ "$rc" -ne 0 ]; then
    echo "RESULT: FAIL (exit $rc)" >&2
    exit "$rc"
fi
echo "RESULT: PASS"
exit 0
