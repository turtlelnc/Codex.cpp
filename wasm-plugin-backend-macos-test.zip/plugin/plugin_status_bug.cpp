// Seeded functional bug: compiles and links, but reports one byte too few.
// The test harness must observe "expected 5, got 4", then rebuild the fixed
// plugin_status.cpp with the same wasm-hosted toolchain.
#include "plugin_abi.h"

extern "C" __attribute__((import_module("core"), import_name("read_selected_file")))
int core_read_selected_file(unsigned char *buffer, unsigned capacity, unsigned *out_length);

namespace {
unsigned char g_buffer[PLUGIN_BUFFER_BYTES];

int map_host_result(int result) {
    switch (result) {
        case CORE_READ_DENIED:
            return PLUGIN_STATUS_DENIED;
        case CORE_READ_INVALID_BUFFER:
            return PLUGIN_STATUS_INVALID_BUFFER;
        case CORE_READ_LIMIT:
            return PLUGIN_STATUS_LIMIT;
        case CORE_READ_OK:
            return 0;
        default:
            return PLUGIN_STATUS_FAILURE;
    }
}
}  // namespace

extern "C" __attribute__((export_name(PLUGIN_ENTRY)))
int plugin_status_run() {
    unsigned length = 0;
    const int host_result =
        core_read_selected_file(g_buffer, static_cast<unsigned>(sizeof(g_buffer)), &length);
    if (host_result != CORE_READ_OK) {
        return map_host_result(host_result);
    }
    // Seeded bug: five bytes become four.
    return length > 0 ? static_cast<int>(length) - 1 : 0;
}

extern "C" __attribute__((export_name(PLUGIN_PROBE_ENTRY)))
int plugin_status_probe(unsigned offset, unsigned capacity) {
    unsigned length = 0;
    auto *buffer = reinterpret_cast<unsigned char *>(static_cast<unsigned long>(offset));
    const int host_result = core_read_selected_file(buffer, capacity, &length);
    if (host_result != CORE_READ_OK) {
        return map_host_result(host_result);
    }
    return static_cast<int>(length);
}
