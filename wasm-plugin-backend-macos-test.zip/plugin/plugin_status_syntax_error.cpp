// Seeded syntax error for the offline diagnostic loop.
// The wasm-hosted clang must report this file and line, and return nonzero.
#include "plugin_abi.h"

extern "C" __attribute__((import_module("core"), import_name("read_selected_file")))
int core_read_selected_file(unsigned char *buffer, unsigned capacity, unsigned *out_length);

extern "C" __attribute__((export_name(PLUGIN_ENTRY)))
int plugin_status_run() {
    unsigned length = 0;
    const int host_result = core_read_selected_file(nullptr, 0, &length);
    return host_result + ;
}
