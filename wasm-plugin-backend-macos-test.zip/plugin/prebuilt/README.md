# 预构建插件产物

这些是实验实际生成的 Wasm 插件，便于检查或在不重新编译的情况下查看。Core tests
本身会通过 `core/core_api.cpp` 的 `RunCompiler` 用 wasm-hosted Clang/LLD **重新
编译**插件，不依赖这里的预构建文件。

| 文件 | 字节 | SHA-256 | 说明 |
|---|---:|---|---|
| `plugin_status.wasm` | 1098 | `8aa2530c3aabd8b37409b858f97cf47a6802202eb6eb531bc53128e30aa3be93` | 修复后的正常插件 |
| `plugin_status_fixed.wasm` | 1098 | 同上 | 修复后副本 |
| `plugin_status_bug.wasm` | 1167 | `ec6d5c53e784a1b59bfeb8bf6efbbc2a4ebe7732ea50cfa5f4f3799d7d2acb56` | 返回 `4` 的种子功能错误 |
| `plugin_status_after_syntax.wasm` | 1098 | `203b6e56669259cffb314e0ba1c07e9b5f20ba62e41c14340702673dfbbca109` | 语法错误修复后重编产物 |
| `plugin_spin.wasm` | 474 | `e64db8a1b72802af7086f8bc8da6c54afcdda32e50b834f31fa37081f4dc8380` | 第二阶段合作式 metering 测试插件；不是第三阶段强制中止的依据 |

正常插件对 5 字节 `tests/fixtures/five.txt` 返回 `5`；对空输入返回 `0`；默认
拒绝返回 `-1`；越界缓冲返回 `-2`；读取失败返回 `-3`；超限返回 `-4`。

`plugin_spin.wasm` 依赖插件主动调用 `metering.usegas`，只保留作历史对照；
第三阶段使用无导入的 `tests/wasm/spin.wasm` 和 patched wasm3 的指令预算/取消。
