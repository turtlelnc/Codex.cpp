// Freestanding plugin source for the Codex.cpp plugin_status prototype.
// Built by the wasm-hosted Clang and linked by the wasm-hosted wasm-ld.
#include "plugin_abi.h"

extern "C" __attribute__((import_module("core"), import_name("read_selected_file")))
int core_read_selected_file(unsigned char *buffer, unsigned capacity, unsigned *out_length);

namespace {
unsigned char g_buffer[PLUGIN_BUFFER_BYTES];

int map_host_result(int result) {
    switch (result) {
        case CORE_READ_DENIED:
            return PLUGIN_STATUS_DENIED;
        case CORE_READ_INVALID_BUFFER:
            return PLUGIN_STATUS_INVALID_BUFFER;
        case CORE_READ_LIMIT:
            return PLUGIN_STATUS_LIMIT;
        case CORE_READ_OK:
            return 0;
        default:
            return PLUGIN_STATUS_FAILURE;
    }
}
}  // namespace

extern "C" __attribute__((export_name(PLUGIN_ENTRY)))
int plugin_status_run() {
    unsigned length = 0;
    const int host_result =
        core_read_selected_file(g_buffer, static_cast<unsigned>(sizeof(g_buffer)), &length);
    if (host_result != CORE_READ_OK) {
        return map_host_result(host_result);
    }
    return static_cast<int>(length);
}

// Test-only export: call the same host import with an arbitrary Wasm memory
// offset. The host must validate the range before touching the file.
extern "C" __attribute__((export_name(PLUGIN_PROBE_ENTRY)))
int plugin_status_probe(unsigned offset, unsigned capacity) {
    unsigned length = 0;
    auto *buffer = reinterpret_cast<unsigned char *>(static_cast<unsigned long>(offset));
    const int host_result = core_read_selected_file(buffer, capacity, &length);
    if (host_result != CORE_READ_OK) {
        return map_host_result(host_result);
    }
    return static_cast<int>(length);
}
