#ifndef CODEX_PLUGIN_STATUS_ABI_H
#define CODEX_PLUGIN_STATUS_ABI_H

/*
 * Codex.cpp plugin ABI v1 (prototype).
 *
 * The plugin is a freestanding wasm32-wasip1 module.  It has exactly one
 * capability: it can ask the Core host to fill a buffer with the file the
 * host selected.  The plugin never receives or supplies a host path.
 *
 * Host import:
 *   module "core", name "read_selected_file"
 *   i32 read_selected_file(i32 wasm_buffer_offset, i32 capacity, i32 wasm_out_len_offset)
 *
 * Host import result:
 *   0 = OK; out_len was written
 *   1 = denied (no current one-shot grant)
 *   2 = invalid buffer (out of Wasm memory or malformed out_len pointer)
 *   3 = host I/O failure
 *   4 = limit exceeded (host read limit or capacity)
 *
 * Plugin entry result:
 *   >= 0 = success, value is the file length (empty file is 0)
 *   -1   = denied
 *   -2   = invalid buffer
 *   -3   = read failure
 *   -4   = limit exceeded
 */

#define PLUGIN_ABI_VERSION 1
#define PLUGIN_ID "codex.cpp.plugin_status"
#define PLUGIN_ENTRY "plugin_status_run"
#define PLUGIN_PROBE_ENTRY "plugin_status_probe"

#define CORE_READ_OK 0
#define CORE_READ_DENIED 1
#define CORE_READ_INVALID_BUFFER 2
#define CORE_READ_ERROR 3
#define CORE_READ_LIMIT 4

#define PLUGIN_STATUS_DENIED (-1)
#define PLUGIN_STATUS_INVALID_BUFFER (-2)
#define PLUGIN_STATUS_FAILURE (-3)
#define PLUGIN_STATUS_LIMIT (-4)

#define PLUGIN_BUFFER_BYTES 64

#endif
