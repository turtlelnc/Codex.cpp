# plugin_status ABI v1

## Module

- Plugin ID: `codex.cpp.plugin_status`
- ABI version: `1`
- Entry: `plugin_status_run`
- Required capability: `core.read_selected_file`
- Manifest: [`plugin_status.json`](plugin_status.json)

The plugin is a freestanding `wasm32-wasip1` module. It imports exactly one
host function in the production build; it has no WASI, network, or process
imports. The host decides which file is selected and when a one-shot read
grant exists. A host path is never passed into the plugin.

## Host import

```text
module:  core
name:    read_selected_file
type:    (i32 buffer_offset, i32 capacity, i32 out_len_offset) -> i32
```

| Host result | Meaning |
|---:|---|
| `0` | OK; `out_len_offset` contains the number of bytes written |
| `1` | denied; no current one-shot grant |
| `2` | invalid buffer: offset/capacity/out_len pointer outside Wasm memory |
| `3` | host read failure (for example, missing file) |
| `4` | limit exceeded (host read limit or `capacity`) |

The host validates all three Wasm-memory pointers/ranges before opening the
file. It does not read the file for denied, invalid-buffer, or limit results.
The one-shot grant is consumed by every callback invocation, including invalid
or rejected calls. `read_count` counts only actual successful file reads.

## Plugin exports

```text
plugin_status_run() -> i32
```

| Plugin result | Meaning |
|---:|---|
| `>= 0` | success; value is the file length. Empty file is `0` |
| `-1` | denied |
| `-2` | invalid Wasm buffer |
| `-3` | host read failure |
| `-4` | limit exceeded |

The status distinction is explicit: empty success is `0`, denial is `-1`, and
a read failure is `-3`.

Test-only exports:

- `plugin_status_probe(offset, capacity) -> i32` calls the same import with an
  arbitrary Wasm-memory offset, used to verify host bounds checking.
- `plugin_spin_forever()` exists only in `plugin_spin.cpp`; it cooperatively
  calls the test-only `metering.usegas` import so the host can demonstrate a
  verifiable Wasm trap. It is not part of the production manifest.

## Core callback contract

The native prototype is in `host/core_host.cpp`. For iPadOS, keep the same
interface but replace host `std::filesystem`/`std::ifstream` with the app's
selected-file buffer or VFS:

```text
if (not authorized) return DENIED;
granted = false;                       // consume the one-shot grant
if (buffer/out_len out of Wasm memory) return INVALID_BUFFER;
if (file size > capacity or read_limit) return LIMIT;
read selected file; copy into plugin memory; write out_len;
read_count += 1;
return OK;
```

The plugin cannot request a path: the import has no path argument. The host
must not read a file for an invalid buffer request, and must not reuse a grant
after any call.

## Agent-facing diagnostics

The test harness prints parseable lines:

```text
stage=compile source=plugin/plugin_status_syntax_error.cpp:12:26 result=EXPECTED_FAIL
stage=test test=plugin_status_five_bytes expected=5 actual=4 read_count=1 result=FAIL
diagnostic: expected 5, got 4 (test=plugin_status_five_bytes)
```

A future Agent can use the stage, source location, test name, expected value,
actual value, and artifact SHA-256 to decide whether to edit source, rebuild,
or change the host grant.
