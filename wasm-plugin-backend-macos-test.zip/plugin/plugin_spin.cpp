// Test-only plugin for verifiable interpreter abort.
// It cooperatively calls the host metering import; the host traps when the
// gas budget is exhausted. This is not generic preemption, but it is a real
// Wasm trap that the host can observe and recover from with a new instance.
extern "C" __attribute__((import_module("metering"), import_name("usegas")))
void metering_usegas(unsigned gas);

extern "C" __attribute__((export_name("plugin_spin_forever")))
void plugin_spin_forever() {
    volatile unsigned counter = 0;
    for (;;) {
        counter = counter + 1;
        metering_usegas(1);
    }
}
