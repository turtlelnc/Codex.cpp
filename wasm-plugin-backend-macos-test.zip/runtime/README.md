# Patched wasm3 runtime: instruction budget + host-thread cancellation

## Base and license

- Upstream: wasm3 v0.9.0 (<https://github.com/wasm3/wasm3>)
- Tarball: <https://github.com/wasm3/wasm3/archive/refs/tags/v0.9.0.tar.gz>
- Tarball SHA-256: `cab79ce74bcac25bbf80b5ebe14af9795b9bac30b05ee8f620a3bc8002f3b8e6`
- License: MIT; see [`wasm3-src/LICENSE`](wasm3-src/LICENSE) and
  [`licenses/LICENSE-wasm3.txt`](licenses/LICENSE-wasm3.txt); uvwasi/libuv
  MIT licenses are in [`licenses/`](licenses).
- Patched tree: [`wasm3-src/source`](wasm3-src/source)
- Self-maintained patch: [`patches/0001-wasm3-budget-cancel.patch`](patches/0001-wasm3-budget-cancel.patch)
- Patch SHA-256: `f6c3db2127bc53bfdec1583ea5d9a2d721937e2cb7d79b18a5dbb9be98545ca9`

The patch is relative to `source/` (`a/m3_env.c` → `b/m3_env.c`). The checked-in
`runtime/wasm3-src/source` is the already-patched source used by
`core/build-core.sh`, so no network access is needed for the normal test run.

To rebuild from the pristine tarball (`host/vendor/wasm3` is intentionally not
included in this handoff):

```bash
curl -L --fail -o /tmp/wasm3-v0.9.0.tar.gz \
  https://github.com/wasm3/wasm3/archive/refs/tags/v0.9.0.tar.gz
tar -xzf /tmp/wasm3-v0.9.0.tar.gz -C /tmp
mv /tmp/wasm3-0.9.0/source runtime/build-src
(cd runtime/build-src && patch -p1 < ../patches/0001-wasm3-budget-cancel.patch)
```

## Why patch wasm3

Inspection of wasm3 0.9.0 and the wasm3-self-compiling usage:

- `m3_Yield()` is a weak hook called only around Wasm calls; it has no runtime
  argument and cannot see a per-instance cancel/budget state.
- The CLI `--gas-limit` only applies to modules pre-instrumented with a
  `metering.usegas` import (`platforms/app/main.c` comment). It is cooperative
  and cannot stop an arbitrary/uninstrumented module.
- There is no public runtime interrupt API that can stop an arbitrary Wasm
  instruction stream.

Alternatives considered:

| Route | Why not chosen |
|---|---|
| Loading-time instrumentation (insert metering calls at loop backedges) | Requires rewriting every module, including the 52 MB `llvm.wasm`; only instrumented sites can stop; adds host-import overhead and more moving parts. |
| Replace interpreter with one exposing gas/cancel | Would require another WASI/loader integration and re-validation for `llvm.wasm`; larger than the minimal patch needed here. |
| Per-instruction check inside wasm3's interpreter (chosen) | No module rewriting; works for uncooperative code; exact per-instance instruction count and atomic cancel flag; small self-maintained patch. |

## Patch behavior

`m3_CheckRuntimeControl()` is called from `nextOpDirect`, `jumpOpDirect`, and
the `Loop` iteration wrapper:

- reads an atomic `cancel_requested` flag (set by any host thread through
  `m3_RequestCancel`);
- increments `instructions_executed` for every dispatched Wasm instruction;
- returns `m3Err_trapInstructionBudget` when an enabled budget is exhausted;
- returns `m3Err_trapCancelled` when cancellation is pending;
- skips the check when `_mem == nullptr`, which occurs for short constant
  expression execution during module setup (this caused a null dereference in
  the first patch iteration).

Public additions:

```c
void     m3_ResetExecutionControl(IM3Runtime);
void     m3_SetInstructionBudget(IM3Runtime, uint64_t budget); // 0 = unlimited
void     m3_RequestCancel(IM3Runtime);                         // thread-safe flag
uint32_t m3_GetAbortStatus(IM3Runtime);                       // 0/1/2
const char* m3_GetAbortReason(IM3Runtime);
uint64_t m3_GetInstructionsExecuted(IM3Runtime);
uint32_t m3_HasEnteredInterpreter(IM3Runtime);
```

Abort status: `0` none, `1` instruction budget, `2` cancellation.

The execution thread owns the runtime. A controller thread may call
`m3_RequestCancel()`; it must not free/destroy the instance. The Core joins the
controller before freeing the runtime.

## Execution mode

wasm3 is an interpreter; no JIT is used. `core/build-core.sh` builds the patched
runtime and Core against Homebrew `uvwasi 0.0.23` / `libuv 1.53.0` for the
compiler's WASI filesystem. Both are MIT.

## Known limits

- Checks are per Wasm instruction, but **host imports are not interrupted while
  they run**. A blocking `uvwasi` file operation, a long host callback, or
  module load/compile/validation is outside the cancellation window.
- Module parse/load/WASI linking happens before the execution timer starts;
  cancellation only covers actual interpreted Wasm execution.
- The cancellation controller polls every 1 ms; measured post-request latency is
  sub-millisecond for the instruction checks, but the request itself can be
  delayed by up to the poll interval.
- Per-instruction checks add overhead. Measured normal builds in this lab:
  Clang ~0.27–0.38 s, LLD ~16–20 ms (see `logs/core-tests-console.txt`).
