#include <algorithm>
#include <cstring>
#include <mutex>
#include "core_api.h"

#include "wasm3.h"
#include "m3_api_wasi.h"

#include <uvwasi.h>

#include <chrono>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <sstream>
#include <string>
#include <sys/resource.h>
#include <thread>
#include <unistd.h>
#include <vector>

namespace codex {
namespace {

using Clock = std::chrono::steady_clock;
using Ms = std::chrono::milliseconds;

uint64_t PeakRssBytes() {
    struct rusage usage {};
    if (getrusage(RUSAGE_SELF, &usage) != 0) return 0;
#if defined(__APPLE__)
    return static_cast<uint64_t>(usage.ru_maxrss);  // bytes on macOS
#else
    return static_cast<uint64_t>(usage.ru_maxrss) * 1024;  // KiB on Linux
#endif
}

double MsSince(Clock::time_point start, Clock::time_point end) {
    return std::chrono::duration<double, std::milli>(end - start).count();
}

std::string JsonEscape(const std::string& value) {
    std::string out;
    out.reserve(value.size() + 8);
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    return out;
}

struct PluginHostState {
    const uint8_t* input = nullptr;
    size_t input_size = 0;
    uint64_t read_limit = 0;
    bool grant = false;
    uint64_t read_count = 0;
};

thread_local PluginHostState* g_plugin_host = nullptr;

m3ApiRawFunction(host_read_selected_file) {
    m3ApiReturnType(uint32_t)
    m3ApiGetArg(uint32_t, buffer_offset)
    m3ApiGetArg(uint32_t, capacity)
    m3ApiGetArg(uint32_t, out_length_offset)

    PluginHostState* host = g_plugin_host;
    if (!host) {
        m3ApiReturn(3);
    }

    const bool authorized = host->grant;
    host->grant = false;  // one-shot, consumed by every call

    if (!authorized) {
        m3ApiReturn(1);
    }

    uint32_t memory_size = 0;
    uint8_t* memory = m3_GetMemory(runtime, &memory_size, 0);
    if (!memory) {
        m3ApiReturn(3);
    }

    const uint64_t buffer_end =
        static_cast<uint64_t>(buffer_offset) + static_cast<uint64_t>(capacity);
    if (buffer_end > memory_size ||
        out_length_offset > memory_size ||
        memory_size - out_length_offset < 4 ||
        (out_length_offset & 3u) != 0) {
        m3ApiReturn(2);
    }

    if (host->input_size > 0 && host->input == nullptr) {
        m3ApiReturn(3);
    }
    const uint64_t length = static_cast<uint64_t>(host->input_size);
    if (length > capacity || length > host->read_limit) {
        m3ApiReturn(4);
    }
    if (length > 0) {
        std::memcpy(memory + buffer_offset, host->input, static_cast<size_t>(length));
    }
    const uint32_t length32 = static_cast<uint32_t>(length);
    std::memcpy(memory + out_length_offset, &length32, sizeof(length32));
    host->read_count += 1;
    m3ApiReturn(0);
}

// A single controller thread per execution. It never owns/frees the runtime;
// it only requests cancellation through the patched atomic flag.
struct CancelController {
    std::thread thread;
    std::atomic<bool> done{false};
    std::atomic<bool> sent{false};
    Clock::time_point sent_at{};

    void Start(IM3Runtime runtime, const RunControl& control) {
        if (control.cancel_after_ms == 0 && control.cancel_token == nullptr) return;
        thread = std::thread([this, runtime, control] {
            const auto start = Clock::now();
            while (!done.load(std::memory_order_acquire)) {
                if (control.cancel_token && control.cancel_token->is_requested()) {
                    sent_at = Clock::now();
                    sent.store(true, std::memory_order_release);
                    m3_RequestCancel(runtime);
                    return;
                }
                if (control.cancel_after_ms > 0 &&
                    std::chrono::duration_cast<Ms>(Clock::now() - start).count() >=
                        static_cast<long long>(control.cancel_after_ms)) {
                    sent_at = Clock::now();
                    sent.store(true, std::memory_order_release);
                    m3_RequestCancel(runtime);
                    return;
                }
                std::this_thread::sleep_for(Ms(1));
            }
        });
    }

    void Stop() {
        done.store(true, std::memory_order_release);
        if (thread.joinable()) thread.join();
    }
};

RunStatus MapAbort(IM3Runtime runtime, M3Result result, int* exit_code,
                   std::string* error) {
    const uint32_t abort = m3_GetAbortStatus(runtime);
    if (abort == 1) {
        *error = m3_GetAbortReason(runtime);
        return RunStatus::BudgetExceeded;
    }
    if (abort == 2) {
        *error = m3_GetAbortReason(runtime);
        return RunStatus::Cancelled;
    }
    if (result == m3Err_trapExit) {
        *exit_code = m3_GetWasiContext() ? m3_GetWasiContext()->exit_code : 0;
        return RunStatus::Exit;
    }
    if (!result) {
        return RunStatus::Ok;
    }
    *error = result;
    return RunStatus::RuntimeError;
}

void FillMetrics(IM3Runtime runtime, RunResult* result, Clock::time_point start,
                 Clock::time_point load_done, Clock::time_point exec_done,
                 const CancelController& controller, double cancel_latency) {
    (void)start;
    (void)exec_done;
    result->metrics.load_ms = MsSince(start, load_done);
    result->metrics.exec_ms = MsSince(load_done, exec_done);
    result->metrics.elapsed_ms = MsSince(start, exec_done);
    result->metrics.cancel_latency_ms = cancel_latency;
    result->metrics.instructions = m3_GetInstructionsExecuted(runtime);
    result->metrics.entered_interpreter = m3_HasEnteredInterpreter(runtime) != 0;
    result->metrics.peak_rss_bytes = PeakRssBytes();
    (void)controller;
}

struct Diagnostics {
    static constexpr size_t limit = 64 * 1024;
    char bytes[limit];
    size_t size = 0;
    bool truncated = false;

    static void Write(void* context, const void* data, size_t length) {
        auto& output = *static_cast<Diagnostics*>(context);
        const auto count = std::min(length, limit - output.size);
        if (count) std::memcpy(output.bytes + output.size, data, count);
        output.size += count;
        output.truncated |= count != length;
    }

    explicit Diagnostics(bool enabled) {
        if (enabled) m3_SetWasiStderrSink(Write, this);
    }
    ~Diagnostics() { m3_SetWasiStderrSink(nullptr, nullptr); }
};

std::timed_mutex compiler_mutex;
struct WasiSession {
    ~WasiSession() { m3_ResetWasiSession(); }
};

}  // namespace

const char* status_name(RunStatus status) {
    switch (status) {
        case RunStatus::Ok: return "ok";
        case RunStatus::Exit: return "exit";
        case RunStatus::BudgetExceeded: return "budget";
        case RunStatus::Cancelled: return "cancel";
        case RunStatus::RuntimeError: return "error";
        case RunStatus::HostError: return "host_error";
    }
    return "unknown";
}

std::string RunResult::to_json() const {
    std::ostringstream out;
    out << std::fixed << std::setprecision(3);
    out << "{\"status\":\"" << status_name(status) << "\","
        << "\"exit_code\":" << exit_code << ","
        << "\"load_ms\":" << metrics.load_ms << ","
        << "\"exec_ms\":" << metrics.exec_ms << ","
        << "\"elapsed_ms\":" << metrics.elapsed_ms << ","
        << "\"cancel_latency_ms\":" << metrics.cancel_latency_ms << ","
        << "\"instructions\":" << metrics.instructions << ","
        << "\"entered\":" << (metrics.entered_interpreter ? "true" : "false") << ","
        << "\"peak_rss_bytes\":" << metrics.peak_rss_bytes << ","
        << "\"error\":\"" << JsonEscape(error) << "\","
        << "\"stderr\":\"" << JsonEscape(stderr_text) << "\"}";
    return out.str();
}

#ifdef CODEX_CORE_TEST_HOOKS
void CompilerQueueTestHook(bool acquired);
#endif

RunResult RunCompiler(const CompilerRequest& request) {
    RunResult result;
    const auto start = Clock::now();
    if (!request.wasm || request.wasm->empty() || request.root_dir.empty()) {
        result.status = RunStatus::HostError;
        result.error = "missing wasm bytes or root_dir";
        return result;
    }
    const auto cancelled = [&] {
        return request.control.cancel_token && request.control.cancel_token->is_requested();
    };
    std::unique_lock<std::timed_mutex> lock(compiler_mutex, std::defer_lock);
    while (!cancelled() && !lock.try_lock_for(std::chrono::milliseconds(5))) {
#ifdef CODEX_CORE_TEST_HOOKS
        CompilerQueueTestHook(false);
#endif
    }
    if (cancelled()) {
        result.status = RunStatus::Cancelled;
        result.error = "Compiler cancelled before loading";
        result.metrics.elapsed_ms = MsSince(start, Clock::now());
        return result;
    }
#ifdef CODEX_CORE_TEST_HOOKS
    CompilerQueueTestHook(true);
#endif
    WasiSession wasi_session;

    IM3Environment env = m3_NewEnvironment();
    IM3Runtime runtime = m3_NewRuntime(env, 4 * 1024 * 1024, nullptr);
    IM3Module module = nullptr;
    M3Result m3r = m3_ParseModule(env, &module, request.wasm->data(),
                                  static_cast<uint32_t>(request.wasm->size()));
    if (!m3r) m3r = m3_LoadModule(runtime, module);
    if (m3r) {
        result.status = RunStatus::RuntimeError;
        result.error = m3r;
        result.metrics.elapsed_ms = MsSince(start, Clock::now());
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return result;
    }

    std::vector<std::string> arg_storage = request.args;
    std::vector<const char*> argv;
    argv.reserve(arg_storage.size() + 1);
    for (const auto& arg : arg_storage) argv.push_back(arg.c_str());
    argv.push_back(nullptr);

    const char* envp[] = {"PWD=/", "HOME=/", "PATH=/", "LANG=C", nullptr};
    uvwasi_preopen_t preopen{};
    preopen.mapped_path = "/";
    preopen.real_path = request.root_dir.c_str();
    uvwasi_options_t options;
    uvwasi_options_init(&options);
    options.argc = static_cast<uvwasi_size_t>(arg_storage.size());
    options.argv = const_cast<const char**>(argv.data());
    options.envp = envp;
    options.preopenc = 1;
    options.preopens = &preopen;

    m3r = m3_LinkWASIWithOptions(module, options);
    if (m3r) {
        result.status = RunStatus::RuntimeError;
        result.error = m3r;
        result.metrics.elapsed_ms = MsSince(start, Clock::now());
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return result;
    }

    m3_wasi_context_t* wasi = m3_GetWasiContext();
    if (!wasi) {
        result.status = RunStatus::RuntimeError;
        result.error = "WASI context missing";
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return result;
    }
    wasi->argc = static_cast<u32>(arg_storage.size());
    wasi->argv = reinterpret_cast<ccstr_t*>(argv.data());

    IM3Function entry = nullptr;
    m3r = m3_FindFunction(&entry, runtime, "_start");
    if (m3r) {
        result.status = RunStatus::RuntimeError;
        result.error = m3r;
        result.metrics.elapsed_ms = MsSince(start, Clock::now());
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return result;
    }

    const auto load_done = Clock::now();
    m3_ResetExecutionControl(runtime);
    if (request.control.instruction_budget > 0) {
        m3_SetInstructionBudget(runtime, request.control.instruction_budget);
    }

    Diagnostics diagnostics(request.capture_stderr);

    CancelController controller;
    controller.Start(runtime, request.control);
    m3r = m3_CallArgv(entry, 0, nullptr);
    const auto exec_done = Clock::now();
    controller.Stop();

    result.stderr_text.assign(diagnostics.bytes, diagnostics.size);
    if (diagnostics.truncated) result.stderr_text += "\n[diagnostics truncated]\n";

    double cancel_latency = 0.0;
    if (controller.sent.load(std::memory_order_acquire)) {
        cancel_latency = MsSince(controller.sent_at, exec_done);
    }
    result.status = MapAbort(runtime, m3r, &result.exit_code, &result.error);
    FillMetrics(runtime, &result, start, load_done, exec_done, controller,
                cancel_latency);

    m3_FreeRuntime(runtime);
    m3_FreeEnvironment(env);
    return result;
}

PluginResult RunPlugin(const PluginRequest& request) {
    PluginResult plugin_result;
    RunResult& result = plugin_result.run;
    const auto start = Clock::now();
    if (!request.wasm || request.wasm->empty()) {
        result.status = RunStatus::HostError;
        result.error = "missing plugin wasm bytes";
        return plugin_result;
    }

    IM3Environment env = m3_NewEnvironment();
    IM3Runtime runtime = m3_NewRuntime(env, 1024 * 1024, nullptr);
    IM3Module module = nullptr;
    M3Result m3r = m3_ParseModule(env, &module, request.wasm->data(),
                                  static_cast<uint32_t>(request.wasm->size()));
    if (!m3r) m3r = m3_LoadModule(runtime, module);
    if (m3r) {
        result.status = RunStatus::RuntimeError;
        result.error = m3r;
        result.metrics.elapsed_ms = MsSince(start, Clock::now());
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return plugin_result;
    }

    m3r = m3_LinkRawFunction(module, "core", "read_selected_file", "i(iii)",
                             host_read_selected_file);
    if (m3r && m3r != m3Err_functionLookupFailed) {
        result.status = RunStatus::RuntimeError;
        result.error = m3r;
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return plugin_result;
    }

    IM3Function entry = nullptr;
    m3r = m3_FindFunction(&entry, runtime, request.entry.c_str());
    if (m3r) {
        result.status = RunStatus::RuntimeError;
        result.error = m3r;
        m3_FreeRuntime(runtime);
        m3_FreeEnvironment(env);
        return plugin_result;
    }

    PluginHostState host;
    host.input = request.input;
    host.input_size = request.input_size;
    host.read_limit = request.read_limit > 0 ? request.read_limit : request.input_size;
    host.grant = request.grant;
    g_plugin_host = &host;

    const auto load_done = Clock::now();
    m3_ResetExecutionControl(runtime);
    if (request.control.instruction_budget > 0) {
        m3_SetInstructionBudget(runtime, request.control.instruction_budget);
    }
    CancelController controller;
    controller.Start(runtime, request.control);
    m3r = m3_CallV(entry);
    const auto exec_done = Clock::now();
    controller.Stop();
    g_plugin_host = nullptr;

    double cancel_latency = 0.0;
    if (controller.sent.load(std::memory_order_acquire)) {
        cancel_latency = MsSince(controller.sent_at, exec_done);
    }
    result.status = MapAbort(runtime, m3r, &result.exit_code, &result.error);
    FillMetrics(runtime, &result, start, load_done, exec_done, controller,
                cancel_latency);
    plugin_result.read_count = host.read_count;

    if (m3r == m3Err_none && m3_GetRetCount(entry) >= 1) {
        int32_t value = 0;
        if (m3_GetResultsV(entry, &value) == m3Err_none) {
            plugin_result.plugin_status = value;
        }
    }

    m3_FreeRuntime(runtime);
    m3_FreeEnvironment(env);
    return plugin_result;
}

}  // namespace codex
