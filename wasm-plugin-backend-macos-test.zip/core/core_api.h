#pragma once

// Minimal C++ Core interface for Codex.cpp's plugin/runtime prototype.
//
// The interpreter state is owned by the thread that calls RunCompiler() or
// RunPlugin(). A CancelToken may be set from another thread; the controller
// thread only calls m3_RequestCancel(), never destroys the instance.
//
// The compiler runs llvm.wasm with a restricted guest root. The plugin runs
// separately with no WASI/network/process imports; its only host capability is
// an in-memory, host-owned bounded byte buffer.

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace codex {

enum class RunStatus {
    Ok = 0,
    Exit = 1,           // compiler called proc_exit; see exit_code
    BudgetExceeded = 2,
    Cancelled = 3,
    RuntimeError = 4,
    HostError = 5,
};

const char* status_name(RunStatus status);

struct CancelToken {
    std::atomic<bool> requested{false};

    void request() { requested.store(true, std::memory_order_release); }
    bool is_requested() const { return requested.load(std::memory_order_acquire); }
};

struct RunControl {
    // 0 = unlimited. The patched wasm3 checks this at every Wasm instruction.
    uint64_t instruction_budget = 0;
    // 0 = no automatic cancel. A non-zero value starts a host controller thread
    // that sleeps then calls m3_RequestCancel(); it never destroys the runtime.
    uint32_t cancel_after_ms = 0;
    // Optional external cancel request, polled by the controller thread.
    CancelToken* cancel_token = nullptr;
};

struct RunMetrics {
    double load_ms = 0.0;
    double exec_ms = 0.0;
    double elapsed_ms = 0.0;
    double cancel_latency_ms = 0.0;
    uint64_t instructions = 0;
    bool entered_interpreter = false;
    uint64_t peak_rss_bytes = 0;
};

struct RunResult {
    RunStatus status = RunStatus::RuntimeError;
    int exit_code = 0;
    RunMetrics metrics;
    std::string error;
    std::string stderr_text;
    std::string to_json() const;
};

struct CompilerRequest {
    const std::vector<uint8_t>* wasm = nullptr;  // llvm.wasm bytes, persistent during call
    std::string root_dir;                        // guest "/" preopen; must already exist
    std::vector<std::string> args;               // argv passed to _start
    RunControl control;
    bool capture_stderr = true;
};

RunResult RunCompiler(const CompilerRequest& request);

struct PluginRequest {
    const std::vector<uint8_t>* wasm = nullptr;
    const uint8_t* input = nullptr;   // host-owned bounded byte buffer
    size_t input_size = 0;
    uint64_t read_limit = 0;          // 0 = input_size; otherwise max bytes readable
    bool grant = false;               // one-shot read authorization for this call
    std::string entry = "plugin_status_run";
    RunControl control;
};

struct PluginResult {
    RunResult run;
    int plugin_status = -999;         // value returned by the entry, if it returned
    uint64_t read_count = 0;          // actual successful host-buffer copies
};

PluginResult RunPlugin(const PluginRequest& request);

}  // namespace codex
