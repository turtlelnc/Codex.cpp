// End-to-end Core tests for the patched wasm3 runtime.
//
// All Wasm execution happens in one host process. The watchdog only prevents
// a hung test from blocking CI; a watchdog exit is a failure, never a pass.
#include "core_api.h"

#ifdef __APPLE__
#include <CommonCrypto/CommonDigest.h>
#else
#include <openssl/sha.h>
#define CC_SHA256 SHA256
#define CC_SHA256_DIGEST_LENGTH SHA256_DIGEST_LENGTH
using CC_LONG = size_t;
#endif

#include <atomic>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <future>
#include <functional>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

#ifdef CODEX_CORE_TEST_HOOKS
namespace codex {
thread_local std::function<void(bool)> compiler_queue_hook;
void CompilerQueueTestHook(bool acquired) {
    if (compiler_queue_hook) compiler_queue_hook(acquired);
}
}
#endif

namespace fs = std::filesystem;

namespace {

int g_failures = 0;
std::string g_lab;
std::vector<std::string> g_test_entries;

std::string JsonEscape(const std::string& value) {
    std::string out;
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: out += static_cast<char>(c); break;
        }
    }
    return out;
}

void Check(const std::string& test, bool ok, const std::string& expected,
           const std::string& actual) {
    std::cout << "stage=test test=" << test
              << " expected=" << expected
              << " actual=" << actual
              << " result=" << (ok ? "PASS" : "FAIL") << "\n";
    g_test_entries.push_back(
        "{\"test\":\"" + JsonEscape(test) + "\",\"expected\":\"" +
        JsonEscape(expected) + "\",\"actual\":\"" + JsonEscape(actual) +
        "\",\"result\":\"" + (ok ? "PASS" : "FAIL") + "\"}");
    if (!ok) {
        ++g_failures;
        std::cout << "diagnostic: expected " << expected << ", got " << actual
                  << " (test=" << test << ")\n";
    }
}

std::vector<uint8_t> ReadFile(const std::string& path) {
    std::ifstream input(path, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(input)),
                                std::istreambuf_iterator<char>());
}

std::string Sha256(const std::vector<uint8_t>& bytes) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(bytes.empty() ? nullptr : bytes.data(),
              static_cast<CC_LONG>(bytes.size()), digest);
    static const char* hex = "0123456789abcdef";
    std::string out(CC_SHA256_DIGEST_LENGTH * 2, '0');
    for (size_t i = 0; i < CC_SHA256_DIGEST_LENGTH; ++i) {
        out[i * 2] = hex[digest[i] >> 4];
        out[i * 2 + 1] = hex[digest[i] & 0xf];
    }
    return out;
}

void PrepareRoot(const std::string& root, const std::string& source,
                 const std::string& source_name) {
    // Keep the root directory itself: uvwasi's preopen fd must stay valid
    // across compiler runs. Only its inputs/outputs are replaced.
    fs::create_directories(root);
    fs::remove_all(root + "/plugin");
    fs::remove_all(root + "/work");
    fs::create_directories(root + "/plugin");
    fs::create_directories(root + "/work");
    fs::copy_file(g_lab + "/plugin/plugin_abi.h", root + "/plugin/plugin_abi.h",
                  fs::copy_options::overwrite_existing);
    fs::copy_file(source, root + "/plugin/" + source_name,
                  fs::copy_options::overwrite_existing);
}

void ClearWork(const std::string& root) {
    fs::remove_all(root + "/work");
    fs::create_directories(root + "/work");
}

bool CompilerOk(const codex::RunResult& result) {
    return (result.status == codex::RunStatus::Ok ||
            result.status == codex::RunStatus::Exit) &&
           result.exit_code == 0;
}

void PrintCompiler(const char* label, const codex::RunResult& result) {
    std::cout << "stage=compiler test=" << label << " " << result.to_json() << "\n";
    if (!result.stderr_text.empty()) {
        std::cout << "stage=compiler test=" << label << " stderr="
                  << result.stderr_text << "\n";
    }
}

bool RunCompilerExpectOk(const char* label, const std::string& root,
                         const std::vector<uint8_t>& llvm,
                         const std::vector<std::string>& args,
                         codex::RunResult* result_out) {
    codex::CompilerRequest request;
    request.wasm = &llvm;
    request.root_dir = root;
    request.args = args;
    auto result = codex::RunCompiler(request);
    PrintCompiler(label, result);
    if (result_out) *result_out = result;
    const bool ok = CompilerOk(result);
    if (!ok) ++g_failures;
    return ok;
}

std::string CompilePlugin(const std::string& root,
                          const std::vector<uint8_t>& llvm,
                          const std::string& source_name) {
    const std::string root_source = g_lab + "/plugin/" + source_name;
    PrepareRoot(root, root_source, "plugin_status.cpp");
    std::vector<std::string> clang = {
        "clang", "-cc1", "-triple", "wasm32-unknown-wasip1", "-std=c++17",
        "-emit-obj", "-o", "/work/plugin_status.o", "/plugin/plugin_status.cpp"};
    if (!RunCompilerExpectOk("clang", root, llvm, clang, nullptr)) return {};
    std::vector<std::string> lld = {
        "wasm-ld", "--no-entry", "--allow-undefined", "-o",
        "/work/plugin_status.wasm", "/work/plugin_status.o"};
    if (!RunCompilerExpectOk("lld", root, llvm, lld, nullptr)) return {};
    return root + "/work/plugin_status.wasm";
}

codex::PluginResult RunPluginBytes(const std::vector<uint8_t>& wasm,
                                   const std::vector<uint8_t>& input, bool grant,
                                   const char* entry = "plugin_status_run",
                                   uint64_t budget = 0,
                                   uint32_t cancel_after_ms = 0,
                                   codex::CancelToken* cancel_token = nullptr) {
    codex::PluginRequest request;
    request.wasm = &wasm;
    request.input = input.empty() ? nullptr : input.data();
    request.input_size = input.size();
    request.grant = grant;
    request.entry = entry;
    request.control.instruction_budget = budget;
    request.control.cancel_after_ms = cancel_after_ms;
    request.control.cancel_token = cancel_token;
    return codex::RunPlugin(request);
}

void CheckPluginRecovery(const char* label, const std::vector<uint8_t>& plugin,
                         const std::vector<uint8_t>& five) {
    auto result = RunPluginBytes(plugin, five, true);
    std::cout << "stage=plugin test=" << label << " " << result.run.to_json() << "\n";
    Check(label, result.run.status == codex::RunStatus::Ok &&
                     result.plugin_status == 5 && result.read_count == 1,
          "status=5,read_count=1",
          "status=" + std::to_string(result.plugin_status) +
              ",read_count=" + std::to_string(result.read_count) +
              ",run=" + codex::status_name(result.run.status));
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: core_tests <lab-root>\n";
        return 2;
    }
    g_lab = argv[1];

    std::atomic<bool> test_done{false};
    std::thread watchdog([&] {
        for (int i = 0; i < 600; ++i) {
            if (test_done.load()) return;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        std::cerr << "FATAL: watchdog expired; tests hung\n";
        std::_Exit(124);
    });

    const auto llvm = ReadFile(g_lab + "/deps/clang-wasm/llvm.wasm");
    const auto spin = ReadFile(g_lab + "/tests/wasm/spin.wasm");
    const auto normal = ReadFile(g_lab + "/tests/wasm/normal.wasm");
    const auto five = ReadFile(g_lab + "/tests/fixtures/five.txt");
    const auto empty = ReadFile(g_lab + "/tests/fixtures/empty.txt");
    if (llvm.empty() || spin.empty() || normal.empty() || five.size() != 5 ||
        !empty.empty()) {
        std::cerr << "missing test inputs\n";
        test_done = true;
        watchdog.join();
        return 1;
    }

    // A normal imported module completes under a budget.
    auto normal_result = RunPluginBytes(normal, {}, false, "marker", 100000);
    std::cout << "stage=plugin test=normal " << normal_result.run.to_json() << "\n";
    Check("normal_module_budget", normal_result.run.status == codex::RunStatus::Ok &&
                                      normal_result.plugin_status == 42 &&
                                      normal_result.run.metrics.entered_interpreter,
          "status=42,entered=true",
          "status=" + std::to_string(normal_result.plugin_status) +
              ",entered=" + std::string(normal_result.run.metrics.entered_interpreter ? "true" : "false"));

    // Uncooperative infinite loop: instruction budget.
    auto budget_result = RunPluginBytes(spin, {}, false, "spin", 100000);
    std::cout << "stage=abort test=budget " << budget_result.run.to_json() << "\n";
    Check("spin_budget", budget_result.run.status == codex::RunStatus::BudgetExceeded &&
                             budget_result.run.metrics.entered_interpreter &&
                             budget_result.run.metrics.instructions >= 100000,
          "budget_exceeded,entered=true",
          std::string(codex::status_name(budget_result.run.status)) +
              ",entered=" + (budget_result.run.metrics.entered_interpreter ? "true" : "false"));

    // The plugin is compiled before exercising recoveries.
    const std::string root = g_lab + "/work/core-tests/root";
    const std::string plugin_path = CompilePlugin(root, llvm, "plugin_status.cpp");
    if (plugin_path.empty()) {
        test_done = true;
        watchdog.join();
        return 1;
    }
    const auto plugin = ReadFile(plugin_path);
    std::cout << "artifact=plugin path=" << plugin_path
              << " sha256=" << Sha256(plugin)
              << " bytes=" << plugin.size() << "\n";

    CheckPluginRecovery("recovery_after_budget", plugin, five);

    // Uncooperative infinite loop: an explicit host thread requests cancel
    // through the public CancelToken while wasm3 is executing.
    codex::CancelToken cancel_token;
    std::thread cancel_requester([&] {
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
        cancel_token.request();
    });
    // A deliberately large budget proves cancellation, not budget exhaustion,
    // stops this run.
    auto cancel_result = RunPluginBytes(spin, {}, false, "spin", 1000000000ULL, 0,
                                        &cancel_token);
    cancel_requester.join();
    std::cout << "stage=abort test=cancel " << cancel_result.run.to_json() << "\n";
    Check("spin_cancel", cancel_result.run.status == codex::RunStatus::Cancelled &&
                             cancel_result.run.metrics.entered_interpreter &&
                             cancel_result.run.metrics.cancel_latency_ms > 0,
          "cancelled,entered=true,latency>0",
          std::string(codex::status_name(cancel_result.run.status)) +
              ",entered=" + (cancel_result.run.metrics.entered_interpreter ? "true" : "false") +
              ",latency_ms=" + std::to_string(cancel_result.run.metrics.cancel_latency_ms));

    CheckPluginRecovery("recovery_after_cancel", plugin, five);

    // Bounded host buffer semantics.
    auto deny = RunPluginBytes(plugin, five, false);
    Check("five_default_deny", deny.run.status == codex::RunStatus::Ok &&
                                   deny.plugin_status == -1 && deny.read_count == 0,
          "status=-1,read_count=0",
          "status=" + std::to_string(deny.plugin_status) +
              ",read_count=" + std::to_string(deny.read_count));
    auto empty_result = RunPluginBytes(plugin, empty, true);
    Check("empty_input", empty_result.run.status == codex::RunStatus::Ok &&
                             empty_result.plugin_status == 0 && empty_result.read_count == 1,
          "status=0,read_count=1",
          "status=" + std::to_string(empty_result.plugin_status) +
              ",read_count=" + std::to_string(empty_result.read_count));

    // Compiler diagnostics, then a normal Clang/LLD build.
    PrepareRoot(root, g_lab + "/plugin/plugin_status_syntax_error.cpp",
                "plugin_status_syntax_error.cpp");
    codex::CompilerRequest diag_request;
    diag_request.wasm = &llvm;
    diag_request.root_dir = root;
    diag_request.args = {"clang", "-cc1", "-triple", "wasm32-unknown-wasip1",
                         "-std=c++17", "-emit-obj", "-o", "/work/bad.o",
                         "/plugin/plugin_status_syntax_error.cpp"};
    auto diag = codex::RunCompiler(diag_request);
    PrintCompiler("syntax", diag);
    const bool diag_ok = diag.stderr_text.find("plugin_status_syntax_error.cpp:") !=
                             std::string::npos &&
                         diag.stderr_text.find("error: expected expression") !=
                             std::string::npos;
    Check("compiler_syntax_diagnostic", diag_ok,
          "filename:line:error:expected expression", diag.stderr_text);

    // Cancellation during Clang execution, then recovery with a fresh build.
    PrepareRoot(root, g_lab + "/plugin/plugin_status.cpp", "plugin_status.cpp");
    codex::CompilerRequest cancel_clang;
    cancel_clang.wasm = &llvm;
    cancel_clang.root_dir = root;
    cancel_clang.args = {"clang", "-cc1", "-triple", "wasm32-unknown-wasip1",
                         "-std=c++17", "-emit-obj", "-o", "/work/cancelled.o",
                         "/plugin/plugin_status.cpp"};
    cancel_clang.control.cancel_after_ms = 20;
    auto cancel_clang_result = codex::RunCompiler(cancel_clang);
    PrintCompiler("clang_cancel", cancel_clang_result);
    Check("clang_cancel", cancel_clang_result.status == codex::RunStatus::Cancelled &&
                              cancel_clang_result.metrics.entered_interpreter &&
                              cancel_clang_result.metrics.cancel_latency_ms > 0,
          "cancelled,entered=true", codex::status_name(cancel_clang_result.status));
    ClearWork(root);
    std::vector<std::string> clang_args = {
        "clang", "-cc1", "-triple", "wasm32-unknown-wasip1", "-std=c++17",
        "-emit-obj", "-o", "/work/plugin_status.o", "/plugin/plugin_status.cpp"};
    if (!RunCompilerExpectOk("clang_after_cancel", root, llvm, clang_args, nullptr)) {
        test_done = true;
        watchdog.join();
        return 1;
    }

    // Cancellation during LLD execution, then a fresh successful link.
    std::vector<std::string> lld_args = {
        "wasm-ld", "--no-entry", "--allow-undefined", "-o",
        "/work/plugin_status.wasm", "/work/plugin_status.o"};
    codex::CompilerRequest lld_cancel;
    lld_cancel.wasm = &llvm;
    lld_cancel.root_dir = root;
    lld_cancel.args = lld_args;
    lld_cancel.control.cancel_after_ms = 1;
    auto lld_cancel_result = codex::RunCompiler(lld_cancel);
    PrintCompiler("lld_cancel", lld_cancel_result);
    Check("lld_cancel", lld_cancel_result.status == codex::RunStatus::Cancelled &&
                            lld_cancel_result.metrics.entered_interpreter,
          "cancelled,entered=true", codex::status_name(lld_cancel_result.status));
    fs::remove(root + "/work/plugin_status.wasm");
    std::vector<std::string> lld_retry = {
        "wasm-ld", "--no-entry", "--allow-undefined", "-o",
        "/work/plugin_status.wasm", "/work/plugin_status.o"};
    if (!RunCompilerExpectOk("lld_after_cancel", root, llvm, lld_retry, nullptr)) {
        test_done = true;
        watchdog.join();
        return 1;
    }
    const auto rebuilt = ReadFile(root + "/work/plugin_status.wasm");
    const std::string rebuilt_sha = Sha256(rebuilt);
    std::cout << "artifact=rebuilt path=" << root + "/work/plugin_status.wasm"
              << " sha256=" << rebuilt_sha << " bytes=" << rebuilt.size() << "\n";
    CheckPluginRecovery("recovery_after_compiler_cancel", rebuilt, five);

    codex::CancelToken already_cancelled;
    already_cancelled.request();
    auto cancelled_before_load = cancel_clang;
    cancelled_before_load.control.cancel_token = &already_cancelled;
    cancelled_before_load.root_dir = root + "-missing";
    const auto preflight = codex::RunCompiler(cancelled_before_load);
    Check("compiler_preflight_cancel",
          preflight.status == codex::RunStatus::Cancelled && !preflight.metrics.entered_interpreter &&
              preflight.metrics.load_ms == 0,
          "cancelled without loading", codex::status_name(preflight.status));

#if defined(__linux__)
    const auto count_fds = [] {
        return std::distance(fs::directory_iterator("/proc/self/fd"), fs::directory_iterator{});
    };
    const auto descriptors_before = count_fds();
#endif
    const std::string second_root = root + "-second";
    const auto second_output = CompilePlugin(second_root, llvm, "plugin_status.cpp");
    const auto second_plugin = ReadFile(second_output);
    Check("second_wasi_root", !second_plugin.empty() && Sha256(second_plugin) == rebuilt_sha,
          "matching plugin in second root", second_output.empty() ? "build failed" : Sha256(second_plugin));
    CheckPluginRecovery("second_root_plugin", second_plugin, five);
    Check("first_wasi_root_preserved",
          Sha256(ReadFile(root + "/work/plugin_status.wasm")) == rebuilt_sha,
          "original artifact unchanged", Sha256(ReadFile(root + "/work/plugin_status.wasm")));

#if defined(__linux__)
    const auto descriptors_after = count_fds();
    Check("compiler_descriptors_released", descriptors_before == descriptors_after,
          std::to_string(descriptors_before), std::to_string(descriptors_after));
#endif

#ifdef CODEX_CORE_TEST_HOOKS
    std::promise<void> lock_acquired, release_lock, waiting;
    auto acquired = lock_acquired.get_future();
    auto release = release_lock.get_future();
    auto queued = waiting.get_future();
    codex::CancelToken queued_cancel;
    auto first_request = cancel_clang;
    first_request.args = clang_args;
    first_request.control = {};
    auto second_request = first_request;
    second_request.root_dir = second_root;
    second_request.control.cancel_token = &queued_cancel;

    auto first = std::async(std::launch::async, [&] {
        codex::compiler_queue_hook = [&](bool holds_lock) {
            if (holds_lock) {
                lock_acquired.set_value();
                release.wait();
            }
        };
        return codex::RunCompiler(first_request);
    });
    acquired.wait();
    auto second = std::async(std::launch::async, [&] {
        bool signalled = false;
        codex::compiler_queue_hook = [&](bool holds_lock) {
            if (!holds_lock && !signalled) {
                signalled = true;
                waiting.set_value();
            }
        };
        return codex::RunCompiler(second_request);
    });
    queued.wait();
    const auto cancel_started = std::chrono::steady_clock::now();
    queued_cancel.request();
    const bool returned_while_locked =
        second.wait_for(std::chrono::seconds(2)) == std::future_status::ready;
    const auto cancel_ms = std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - cancel_started).count();
    release_lock.set_value();
    const auto second_result = second.get();
    const auto first_result = first.get();
    Check("compiler_contended_queue_cancel",
          returned_while_locked && second_result.status == codex::RunStatus::Cancelled &&
              !second_result.metrics.entered_interpreter && second_result.metrics.load_ms == 0,
          "cancelled before lock release and module load",
          std::string(codex::status_name(second_result.status)) + ",wait_ms=" + std::to_string(cancel_ms));
    Check("compiler_lock_holder_completes",
          (first_result.status == codex::RunStatus::Ok || first_result.status == codex::RunStatus::Exit) &&
              first_result.exit_code == 0 && first_result.metrics.entered_interpreter,
          "first compiler execution succeeds", codex::status_name(first_result.status));
#endif

    std::ofstream report(g_lab + "/logs/core-test-report.json");
    report << "{\"result\":\"" << (g_failures == 0 ? "PASS" : "FAIL")
           << "\",\"plugin_sha256\":\"" << Sha256(plugin)
           << "\",\"rebuilt_sha256\":\"" << rebuilt_sha
           << "\",\"tests\":[";
    for (size_t i = 0; i < g_test_entries.size(); ++i) {
        if (i) report << ",";
        report << g_test_entries[i];
    }
    report << "]}\n";

    std::cout << "stage=result result=" << (g_failures == 0 ? "PASS" : "FAIL") << "\n";
    test_done.store(true);
    watchdog.join();
    return g_failures == 0 ? 0 : 1;
}
