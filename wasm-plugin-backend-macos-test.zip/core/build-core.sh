#!/bin/bash
# Build the patched wasm3 runtime and the native Core test harness.
# The patched interpreter is the component that enforces instruction budgets
# and host-thread cancellation. The Core host itself is native C++ (test/app
# embedding); plugin and compiler Wasm modules are loaded by this runtime.
set -euo pipefail

LAB_ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
SRC="$LAB_ROOT/runtime/wasm3-src/source"
UVWASI="${UVWASI_PREFIX:-$(brew --prefix uvwasi)}"
LIBUV="${LIBUV_PREFIX:-$(brew --prefix libuv)}"
CC="${HOST_CC:-cc}"
CXX="${HOST_CXX:-c++}"
OBJ="$LAB_ROOT/work/runtime/obj"
LIB="$LAB_ROOT/work/runtime/libwasm3-cancel.a"

[ -f "$SRC/wasm3.h" ] || { echo "missing patched wasm3 source" >&2; exit 1; }
[ -f "$UVWASI/include/uvwasi.h" ] || { echo "missing uvwasi headers" >&2; exit 1; }
PATCH="$LAB_ROOT/runtime/patches/0001-wasm3-budget-cancel.patch"
[ "$(/usr/bin/shasum -a 256 "$PATCH" | awk '{print $1}')" = \
  "f6c3db2127bc53bfdec1583ea5d9a2d721937e2cb7d79b18a5dbb9be98545ca9" ] || {
    echo "wasm3 cancellation patch hash mismatch" >&2
    exit 1
}
mkdir -p "$OBJ" "$LAB_ROOT/work/runtime"

echo "== patched wasm3 C sources =="
rm -f "$OBJ"/*.o "$LIB"
for f in "$SRC"/m3_*.c; do
    base="$(basename "${f%.c}")"
    echo "CC $base"
    "$CC" -O2 -DNDEBUG -Dd_m3HasUVWASI -std=gnu99 \
        -I"$SRC" -I"$UVWASI/include" -I"$LIBUV/include" \
        -c "$f" -o "$OBJ/$base.o"
done
/usr/bin/ar rcs "$LIB" "$OBJ"/*.o

echo "== Core API/tests =="
platform_libs=()
if [ "$(uname -s)" != Darwin ]; then platform_libs=(-lcrypto); fi
"$CXX" -O2 -std=c++17 -Dd_m3HasUVWASI -DCODEX_CORE_TEST_HOOKS \
    -I"$SRC" -I"$UVWASI/include" -I"$LIBUV/include" -I"$LAB_ROOT/core" \
    "$LAB_ROOT/core/core_tests.cpp" "$LAB_ROOT/core/core_api.cpp" \
    "$LIB" -L"$UVWASI/lib" -L"$LIBUV/lib" -luvwasi -luv -pthread -ldl -lm "${platform_libs[@]}" \
    -Wl,-rpath,"$UVWASI/lib" -Wl,-rpath,"$LIBUV/lib" \
    -o "$LAB_ROOT/work/runtime/core_tests"

echo "built $LAB_ROOT/work/runtime/core_tests"
