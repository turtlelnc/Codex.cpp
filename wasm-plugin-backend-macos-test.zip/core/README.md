# Codex Core API (macOS prototype)

Header: [`core_api.h`](core_api.h)  
Example/tests: [`core_tests.cpp`](core_tests.cpp)

This is the C++ interface an App can call. The compiler and plugin are both
executed by the patched wasm3 interpreter in [`../runtime`](../runtime); no JIT
is used. The host itself is native C++ (test harness/App embedding).

## Compiler

```cpp
std::vector<uint8_t> llvm = ReadFile("deps/clang-wasm/llvm.wasm");

codex::CompilerRequest request;
request.wasm = &llvm;
request.root_dir = "/path/to/temporary/build-root"; // guest "/" preopen
request.args = {"clang", "-cc1", "-triple", "wasm32-unknown-wasip1",
                "-std=c++17", "-emit-obj", "-o", "/work/plugin_status.o",
                "/plugin/plugin_status.cpp"};
request.control.instruction_budget = 0;      // optional
request.control.cancel_after_ms = 0;         // optional automatic cancel
request.capture_stderr = true;               // diagnostics into result.stderr_text

codex::RunResult result = codex::RunCompiler(request);
// result.status: Ok/Exit/BudgetExceeded/Cancelled/RuntimeError/HostError
// result.exit_code, result.stderr_text, result.metrics, result.to_json()
```

The guest root is restricted to the compiler's source/header and temporary
output directory. Each invocation opens the requested root and releases its
WASI descriptors on return. Use one dedicated temporary root per build and
pass the same root to its Clang and LLD invocations.

After Clang, run `wasm-ld` with the same API:

```cpp
request.args = {"wasm-ld", "--no-entry", "--allow-undefined", "-o",
                "/work/plugin_status.wasm", "/work/plugin_status.o"};
auto link = codex::RunCompiler(request);
```

`m3Err_trapExit` is reported as `Exit` with `exit_code`; a returned `_start`
without `proc_exit` is `Ok`.

## Plugin

```cpp
std::vector<uint8_t> plugin = ReadFile("work/.../plugin_status.wasm");
std::vector<uint8_t> input = ReadFile("tests/fixtures/five.txt");

codex::PluginRequest request;
request.wasm = &plugin;
request.input = input.data();      // host-owned bounded byte buffer
request.input_size = input.size();
request.read_limit = 0;            // 0 = input_size
request.grant = true;              // one-shot authorization for this call
request.entry = "plugin_status_run";
request.control.cancel_after_ms = 0;

codex::PluginResult result = codex::RunPlugin(request);
// result.plugin_status: >=0 length, -1 denied, -2 invalid buffer,
//                       -3 read failure, -4 limit
// result.read_count: actual successful copies from the host buffer
```

The `core.read_selected_file` callback copies from the host buffer into the
plugin's Wasm memory only if the one-shot grant is present and the buffer/out
pointer are in bounds. No host path is passed to the plugin.

## Cancellation

`CancelToken` is safe to set from a host thread:

```cpp
codex::CancelToken token;
request.control.cancel_token = &token;
// host/UI thread:
token.request();
```

`RunCompiler`/`RunPlugin` start a controller thread that polls the token (and
`cancel_after_ms`) and calls `m3_RequestCancel(runtime)`. The execution thread
owns the runtime; the controller never frees or destroys it. The Core joins the
controller before freeing the runtime.

Statuses after an abort:

- `RunStatus::BudgetExceeded` — instruction budget exhausted; `[trap]
  instruction budget exceeded`;
- `RunStatus::Cancelled` — host cancel observed; `[trap] execution cancelled`.

`metrics.entered_interpreter` proves the Wasm interpreter was entered;
`metrics.instructions` is the executed-instruction count; `cancel_latency_ms`
is the time from the request to the call returning.

## What cancellation covers

| Covered | Not covered while blocked |
|---|---|
| Wasm instruction dispatch (loops, calls, arithmetic, branches) | Host imports, including `uvwasi` file I/O / path operations |
| Compiler Clang/LLD compute after `_start` begins | `m3_ParseModule` / `m3_LoadModule` / module compilation |
| Plugin `plugin_status_run` compute | `m3_LinkWASIWithOptions` / `uvwasi_init` |
| Same-process recovery by creating a fresh runtime | A host callback that blocks forever |

Module load and WASI initialization happen before the cancel controller starts;
they are not interruptible with this mechanism. A future App should run file I/O
asynchronously or use a cancellation-aware VFS if it needs to interrupt that
phase too.

`capture_stderr` captures guest WASI fd 2 writes in a 64 KiB task buffer.
It does not redirect the app's stderr. Output beyond the cap is discarded and
marked as truncated. The Core serializes compiler calls and resets the WASI descriptor table after each call.
Clang and LLD can share one build directory, and the next build may use a different directory.
An external CancelToken can cancel a queued compiler call before module loading.
The automatic test timer still starts when the interpreter is about to execute.

## Build and test

On Linux, use a native C/C++ compiler, OpenSSL headers for the test harness, and
set `UVWASI_PREFIX` and `LIBUV_PREFIX` to directories with `include/` and
`lib/` subdirectories. The verified Linux run used uvwasi 0.0.23 and libuv
1.53.0. On macOS the prefixes default to Homebrew. Restore and verify
`deps/clang-wasm/llvm.wasm` using the instructions in `deps/clang-wasm/README.md`
before starting the offline run.

Prerequisites on macOS: Homebrew `uvwasi`/`libuv` (installed as dependencies of
`brew install wasm3`) and the macOS native compiler used to build this harness.

```bash
bash core/build-core.sh
./work/runtime/core_tests "$PWD"
# or, from the lab root:
bash scripts/run-core-tests.sh
```

The test binary runs all Wasm in one process and has a 60-second watchdog. The
watchdog only turns a hang into a failing exit (124); it is not counted as a
successful cancellation. See [`../report/CANCELLATION_REPORT.md`](../report/CANCELLATION_REPORT.md).

## App integration notes

- Embed the patched wasm3 source/static library; do not rely on a host process
  for cancellation.
- On iPadOS, build `uvwasi`/libuv for the target or replace the compiler file
  adapter with the app's own WASI/VFS. The Homebrew dylibs used here are macOS
  x86/arm binaries and are not shipped to iPadOS.
- The plugin instance needs no WASI; only the in-memory capability import.
- Keep one execution thread per runtime; cancellation is a flag, not a
  cross-thread free.
