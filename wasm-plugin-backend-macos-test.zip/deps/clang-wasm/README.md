# `llvm.wasm` 放置与来源

本交付包**不包含** `llvm.wasm`，因为它是约 49.6 MiB 的预编译工具链。Core tests
需要它位于：

```text
deps/clang-wasm/llvm.wasm
```

从 handoff 根目录执行：

```bash
bash scripts/fetch-llvm-wasm.sh
```

## 固定来源

- 仓库：<https://github.com/wasm3/wasm3-self-compiling>
- 固定提交：`a09f1996c5fdfca0d9d77e4270f747788fdd08ca`
- 路径：`wasm/llvm.wasm`
- 固定原始地址：
  <https://raw.githubusercontent.com/wasm3/wasm3-self-compiling/a09f1996c5fdfca0d9d77e4270f747788fdd08ca/wasm/llvm.wasm>
- Git blob SHA-1：`39dec7e8620d08d81070853fa14b48afbe4e569a`
- 上游：YoWASP/llvm-project，提交
  `44c7dadc811107e59e1e47c270230354c4fe7db6`；`clang version 19.0.0git`，
  `LLD 19.0.0`，目标 `wasm32-unknown-wasip1`，构建带 `+assertions`
- 许可证：Apache-2.0 WITH LLVM-exception；见 [`../../LICENSE-LLVM.txt`](../../LICENSE-LLVM.txt)

## 完整校验值

```text
文件大小  52048079 bytes
SHA-256  13acf8710b1f7b0cbf8fba75a455a4b023dd5ab3099736631d38e414216d19f7
```

手动下载并校验：

```bash
mkdir -p deps/clang-wasm
curl -L --fail --retry 3 \
  -o deps/clang-wasm/llvm.wasm \
  https://raw.githubusercontent.com/wasm3/wasm3-self-compiling/a09f1996c5fdfca0d9d77e4270f747788fdd08ca/wasm/llvm.wasm

shasum -a 256 deps/clang-wasm/llvm.wasm
# 13acf8710b1f7b0cbf8fba75a455a4b023dd5ab3099736631d38e414216d19f7

wc -c < deps/clang-wasm/llvm.wasm
# 52048079
```

也可以从 Git blob 取出，避免依赖 raw URL：

```bash
git clone https://github.com/wasm3/wasm3-self-compiling.git /tmp/wasm3-self-compiling
git -C /tmp/wasm3-self-compiling checkout a09f1996c5fdfca0d9d77e4270f747788fdd08ca
git -C /tmp/wasm3-self-compiling cat-file blob \
  39dec7e8620d08d81070853fa14b48afbe4e569a > deps/clang-wasm/llvm.wasm
```

## 说明

这是**运行已有 Wasm 产物**，不是在本机从 LLVM 源码构建。源码构建配方见
[`../../docs/SOURCE_BUILD.md`](../../docs/SOURCE_BUILD.md)；本机受 8 GB RAM /
约 9.5 GB 可用磁盘限制，未执行源码构建。`llvm.wasm` 是 multicall 模块，同一
模块内包含 `clang`、`clang++` 和 `wasm-ld`，只依赖 WASI Preview 1。
