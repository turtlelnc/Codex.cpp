;; Normal module used to prove the budget does not abort ordinary execution.
(module
  (func (export "marker") (result i32)
    i32.const 42))
