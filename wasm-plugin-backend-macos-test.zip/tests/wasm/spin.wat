;; No imports, no host calls, no yields: a deliberately uncooperative infinite loop.
(module
  (func (export "spin")
    (loop $forever
      br $forever)))
