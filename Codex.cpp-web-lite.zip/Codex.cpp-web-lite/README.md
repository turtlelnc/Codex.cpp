# Codex.cpp 网页精简体验包

当前首页布局、手机抽屉侧栏、两级模型/推理强度菜单与本地 Agent 源码。
不含多人协调器、部署脚本、历史归档、测试、截图或二进制。

## 编译

Linux / macOS，需要支持 C++17 的编译器：

```sh
clang++ -std=c++17 -O2 -Wall -Wextra -pedantic codex.cpp -o codex-cpp
# 或用 g++ 替代 clang++
```

## 查看网页

需要 Python 3.10+。保留 server/ 和 web/ 与 codex-cpp 在同一目录。

```sh
./codex-cpp web --root .
```

浏览器打开 http://127.0.0.1:8765 。终端会显示登录令牌文件路径，默认 ~/.codex-cpp/web-token。
自行读取文件并将令牌粘贴进网页登录框。只看首页不需要配置或调用模型。

网页跟随系统浅色/深色模式。点击模型按钮先显示强度面板，再点击模型名称进入模型列表。
获取真实模型列表、发任务需要配置 Provider 或登录；接口没有返回强度信息时提供手动选择。

## 调用模型（可选）

需要系统 curl；文件 Diff 需要 git；Linux 受限命令执行需要 bubblewrap（bwrap）。
Codex 订阅可先运行 `./codex-cpp --provider codex --login`，也可在网页设置配置 Provider。
例如已设置 DEEPSEEK_API_KEY 后：

```sh
./codex-cpp web --root /path/to/project --provider deepseek
```

不要将 API 密钥写进源码或命令参数。精简包用于本地 web 模式，不含 serve/SSH 协作的完整组件。
Linux 已验证。macOS 入口已提供但未实机验证；Windows 暂不支持托管网页。
