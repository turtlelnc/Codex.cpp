Portable profiles: --portable-dir DIR --portable-project ID store sessions, project state and user configuration in one explicit local directory and redirect CODEX_CPP_HOME for trusted worker processes; without the options, existing paths stay unchanged. portable status/capabilities, export and import are host-only CLI commands, never Agent tools or WebUI RPC. A shared runtime lease permits Web workers, while export/import and installation take an exclusive lease. Transfer packs are bounded (128 MiB, 4096 files) with strict path and collision validation: plaintext packs carry SHA-256 integrity and encrypted packs use PBKDF2-HMAC-SHA256 (600000 iterations) plus AES-256-GCM (Windows BCrypt, OpenSSL elsewhere). Account/provider files are excluded from plaintext packs, and --include-credentials requires an encrypted pack plus a password environment variable. Import extracts into a private staging directory, preserves executable modes, disables imported plugins, quarantines MCP autostart configuration and publishes only into a new directory, so existing data is never overwritten.

Plugin sharing and opt-in updates: plugin export/import validates declared cross-platform libraries and an imported bundle is never enabled automatically. update check|download|install follows fixed official GitHub Release metadata only, verifies the exact platform asset SHA-256 and size, runs the candidate format handshake, rechecks the target, requires explicit user consent, refuses to install while a task is active, records recovery metadata before replacement, retains a backup and supports rollback; updates are never silent and data is not moved into the executable. Portable profiles and updater state remain local, and locks are local filesystem locks, not distributed locks.

Local /web bridge and session safety: the TUI can start a loopback WebUI service in a separate Agent process that shares the same workspace and saved sessions, pauses terminal task execution while it runs, and reloads the terminal session on /web stop; protected portable data stays outside the browser workspace. Each open session now holds an exclusive per-session lock, so a second process resuming the same session fails with a clear message instead of racing transcript rewrites or journal compaction, and the lock is handed to the WebUI bridge during the pause. Portable roots ending in a path separator are canonicalized instead of being rejected as filesystem roots, and journal replacement uses a unique staging name.

Plugin naming update: CLI --plugin / --plugin-reviewed and plugin inspect/scaffold/check/build/test; model tools plugin_scaffold/plugin_build/plugin_check/plugin_test; manifest plugin.json; SDK plugin/native.h; native entry codex_plugin_init_v1; browser API CodexPlugin. Previously generated native modules must be rebuilt with the updated SDK and use the new manifest/arguments. Browser window.Plugin remains untouched.

Plugin Creator release: embedded SDK/Skill, scaffold/build/static review/isolated ABI probe, and explicit fingerprint-pinned activation. Both reviewed and manual-trust startup freeze plugin bytes for future Agent workers; changed original files cannot silently replace active code. Declared assets join the fingerprint and snapshot.

macOS automatic plugin builds compile plugin.cpp with fixed system clang++/codesign; project CMake/hooks are not run. Windows automatic isolated build/probe remains unsupported and fails closed; manual compilation and trusted loading work. Enabled native modules still have full host-account privileges, not sandboxed plugin permissions.

Linux downloads now include optional -native glibc executables supporting native Plugin loading (x64: glibc >= 2.35; ARM64: glibc >= 2.39). They still embed UI, TLS/Git libraries and bubblewrap, and need no third-party shared libraries. Existing static musl executables remain available for portability but cannot dlopen native plugins. Choose the .tar.gz/.zip archive to preserve executable permissions.

Provider-exposed reasoning now has a separate collapsible WebUI section, with
streaming updates and persisted history. New answer text fades across the whole
delta in up to 16 groups instead of appearing instantly except for its last tail.

Chat Completions agents (including DeepSeek-compatible providers) now request SSE
streaming and forward text deltas to WebUI, TUI and JSON events. Tool-call fragments
are assembled before execution; incomplete/error streams fail explicitly. Servers
returning ordinary JSON remain supported. Reasoning-only deltas are not shown as
answer text. Background text-only calls remain non-streaming.

Conversation-first WebUI: the inspector is closed by default, the file tree is
collapsible, and consecutive tool calls have expandable, event-based summaries.
Approvals remain inline. Full stored tool arguments/output are available on demand,
with the existing project, membership and personal-session boundaries preserved.

Streaming replies now reveal new text with a short fade and 1px
blur, reusing existing message/Markdown nodes. Animation is disabled for reduced
motion, hidden pages, text selection and history reading; temporary spans are
removed after the reveal. No new runtime dependencies or model calls are added.

WebUI reliability update: preserve edits made during file saves, reject stale
file/project/session responses, reuse historical message DOM, and fix sidebar
collapse layout across desktop and mobile widths. Add connection recovery,
conversation drafts, a jump-to-latest button, and keyboard tool-card controls.

ChatGPT device login now shows its address and device code in a dedicated dialog,
with login status instead of a misleading model-thinking indicator. Stored user
messages and session titles hide injected skill/environment context while keeping
actual user text. These changes retain the existing theme and native C++17 runtime.

Reliability fixes: HTTP requests have a total read deadline and stop promptly
during shutdown. Background task storage failures stop the service cleanly
instead of aborting the process. Windows state replacement checks write/flush/
close success before replacing the previous file. Hosted login cookies are
scoped by server port. Cancelling model selection in TUI preserves the provider.

Team hosting now supports direct IP/port access without a public HTTPS address,
domain, certificate or reverse proxy. In TUI or WebUI, set the listen IP/port and
leave the optional access URL blank. Connect using `http://SERVER-IP:PORT`.
CLI example: `codex-cpp serve --state-dir ./team-data --host 0.0.0.0 --port 8766`.
`0.0.0.0` listens on all IPv4 interfaces; `127.0.0.1` limits access to this machine.
An optional `--origin` pins a DNS or reverse-proxy URL. Existing HTTPS proxy
configurations remain compatible and retain loopback binding by default.
HTTP traffic is unencrypted; HTTPS proxying remains available when needed.
Authentication, same-origin/CSRF checks and direct-mode IP/port Host validation
remain enforced; HTTPS cookies retain Secure, HTTP cookies omit Secure.

TUI `/team` includes native team-server setup and an HTTP/HTTPS team client.
Use "Team projects (HTTP/HTTPS)" to sign in, create projects, manage members,
configure shared/personal models, publish/sync/commit/merge branches with exact
SHA confirmation, inspect tasks/audit and recover interrupted queues after review.
"Agent tasks on server" queues shared/personal tasks, displays conversations,
approves operations and stops tasks without opening WebUI. Any project member
can approve shared work; the server records the actual actor. Creator-only
membership and shared-credential rules are enforced by the same hosted API.

Credentials are masked and never saved on the TUI client; session cookies stay
in process memory. HTTPS certificate checks remain enabled. Normal chat outside
the team menu still uses the local workspace; team actions use server workspaces.
Local team-service settings remain shared with WebUI, and the TUI stops its own
managed service when it exits.

Download the executable for your OS/CPU. Windows x86 means 32-bit; x64 and
ARM64 are separate downloads. macOS includes Intel and Apple Silicon builds.
Linux includes x64 and ARM64 builds. On macOS, download the `.zip`; on Linux,
download the `.tar.gz`. Each archive contains exactly one executable and preserves
its executable permission. Bare downloads may lose this permission: run
`chmod +x codex-cpp-<platform>` before launching those from Terminal.
Use `./codex-cpp-<platform> web --root /path/to/project` or start the TUI directly.

WebUI, libgit2 and libcurl are embedded; Windows uses static CRT and system TLS,
macOS uses static OpenSSL with system certificate trust, Linux uses static
musl/OpenSSL and embedded bubblewrap.
No Python, Node, system Git, curl executable, extra DLLs or web directory is
required for the built-in UI and model transport. `--web-dir` overrides the UI.
Use `--licenses` for embedded third-party notices; SHA256SUMS.txt verifies downloads.

Platform requirements and limits:
- Windows 10/11; its restricted command execution/AppContainer backend is not
  implemented. Chat, native file tools and the editor work; restricted shell,
  sandboxed Git and team development operations report unavailable. This release
  does not silently disable isolation. Windows is not yet a complete team server.
- macOS 12+ and the system sandbox-exec facility; Apple may restrict downloaded
  unsigned applications. These builds are ad-hoc signed, not Apple notarized.
- Linux kernel with enabled unprivileged user namespaces. Embedded bubblewrap
  needs an executable temporary directory; distribution security policies can
  still deny namespaces. System CA certificates are needed for HTTPS on Linux.
- Shell tasks use the OS shell and whatever developer tools your task needs.
  Optional SSH, clipboard commands, MCP servers and plugins have their own
  dependencies. HTTPS team access requires a separately configured reverse proxy.

Each of the seven executables is tested on its matching architecture from an
isolated temporary directory with no curl/Git in PATH before release publication.
