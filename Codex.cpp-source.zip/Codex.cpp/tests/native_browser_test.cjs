// Browser regression for the native runtime. Node/Playwright are test-only.
const {chromium}=require('playwright'),{spawn,execFileSync}=require('child_process');
const fs=require('fs'),os=require('os'),path=require('path'),http=require('http'),https=require('https'),net=require('net'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..'),binary=path.resolve(process.argv[2]),base=fs.mkdtempSync(path.join(os.tmpdir(),'native-browser-'));let service,browser,proxy,model;

const artifactDir = process.env.CODEX_ARTIFACT_DIR || path.join(require('node:os').tmpdir(), 'codex-webui-artifacts');
async function unused(){const s=net.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}
async function wait(fn){for(let i=0;i<300;i++){if(await fn())return;await new Promise(r=>setTimeout(r,30));}throw Error('Readiness timeout');}
async function stop(){if(service&&service.exitCode===null){const p=service;service.kill('SIGTERM');await new Promise(resolve=>p.once('exit',resolve));}service=null;}
async function start(args,port){let logs='';service=spawn(binary,[...args,'--port',String(port),...(process.env.CODEX_TEST_EMBEDDED_ASSETS?[]:['--web-dir',path.join(root,'web')])],{env:{...process.env,NO_PROXY:'127.0.0.1,localhost',no_proxy:'127.0.0.1,localhost',CODEX_CPP_HOME:path.join(base,'auth')},stdio:['ignore','pipe','pipe']});service.stderr.on('data',b=>logs+=b);service.stdout.on('data',b=>logs+=b);await wait(async()=>{if(service.exitCode!==null)throw Error(logs);return new Promise(r=>{const s=net.connect(port,'127.0.0.1',()=>{s.destroy();r(true);});s.on('error',()=>r(false));});});}
(async()=>{try{
 model=http.createServer((req,res)=>{let body='';req.on('data',b=>body+=b);req.on('end',()=>{res.setHeader('Content-Type','application/json');if(req.url==='/v1/models'||req.url==='/models')return res.end(JSON.stringify({data:[{id:'fixture'}]}));if(req.url==='/chat/completions'){
 const messages=JSON.parse(body).messages,done=messages.some(message=>message.role==='tool');
 res.setHeader('Content-Type','text/event-stream');
 res.write('data: '+JSON.stringify({choices:[{index:0,delta:{reasoning_content:'检查文件，然后执行任务。'}}]})+'\n\n');
 return setTimeout(()=>{if(done){res.write('data: '+JSON.stringify({choices:[{index:0,delta:{content:'### **流式渐显检查**\n这段文字应当从浅色逐渐变深。'}}]})+'\n\n');for(let i=1;i<=8;i++)setTimeout(()=>res.write('data: '+JSON.stringify({choices:[{index:0,delta:{content:' 继续输出'+i}}]})+'\n\n'),i*100);return setTimeout(()=>res.end('data: '+JSON.stringify({choices:[{index:0,delta:{content:'DONE'},finish_reason:'stop'}]})+'\n\ndata: [DONE]\n\n'),1000);}const delta=done?{content:'DONE'}:{tool_calls:[{index:0,id:'write-once',function:{name:'write_file',arguments:JSON.stringify({path:'written.txt',content:'native'})}}]};res.end('data: '+JSON.stringify({choices:[{index:0,delta,finish_reason:done?'stop':'tool_calls'}]})+'\n\ndata: [DONE]\n\n');},700);
 }const input=JSON.parse(body).input||[],index=input.map(x=>x.role).lastIndexOf('user'),done=input.slice(index+1).some(x=>x.type==='function_call_output');res.end(JSON.stringify({id:'fixture',output:done?[{type:'message',role:'assistant',content:[{type:'output_text',text:'DONE'}]}]:[{type:'function_call',call_id:'write-once',name:'write_file',arguments:JSON.stringify({path:'written.txt',content:'native'})}]}));});});await new Promise(r=>model.listen(0,'127.0.0.1',r));
 const project=path.join(base,'project');fs.mkdirSync(project);fs.writeFileSync(path.join(project,'hello.txt'),'hello');let port=await unused();await start(['web','--root',project,'--api','chat','--provider','custom','--model','fixture','--base-url','http://127.0.0.1:'+model.address().port,'--no-api-key'],port);
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});let page=await browser.newPage({viewport:{width:1440,height:1000}});await page.addInitScript(() => {
 window.revealSamples = [];
 document.addEventListener('animationstart', event => {
   if (!event.target.classList.contains('stream-char') || window.revealSamples.length >= 16) return;
   const node = event.target, sample = [];
   window.revealSamples.push(sample);
   const start = performance.now();
   const frame = () => {
     if (!node.isConnected) return;
     sample.push({ ms: performance.now() - start, opacity: Number(getComputedStyle(node).opacity), active: document.querySelectorAll('.stream-char').length });
     if (performance.now() - start < 270) requestAnimationFrame(frame);
   };
   frame();
 });
});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+port);await page.locator('#project-files summary').click();await page.locator('.row.file[data-path="hello.txt"]').click();await page.locator('#editor-text').fill('saved in C++');await page.locator('#editor-save').click();await wait(()=>fs.readFileSync(path.join(project,'hello.txt'),'utf8')==='saved in C++');
 await page.locator('#model-chip').click();await page.getByRole('button',{name:'选择模型',exact:true}).click();await page.getByRole('button',{name:'刷新模型列表',exact:true}).waitFor();await page.keyboard.press('Escape');
 await page.locator('#prompt').fill('Write a native file');await page.locator('#send').click();await page.getByRole('button',{name:'允许',exact:true}).waitFor({timeout:20000});assert.equal(await page.locator('.tool .name').filter({hasText:'write_file'}).count(),1);await page.getByRole('button',{name:'允许',exact:true}).click();await page.waitForFunction(()=>document.getElementById('messages').textContent.includes('DONE'));assert.equal(fs.readFileSync(path.join(project,'written.txt'),'utf8'),'native');
 assert.equal(await page.locator('.message.assistant h3 b').textContent(), '流式渐显检查');
 const samples = await page.evaluate(() => window.revealSamples);
 assert(samples.some(sample => sample.some(frame => frame.opacity < .3) && sample.some(frame => frame.opacity > .93)), 'real backend stream must paint low and high opacity frames');
 assert(samples.flat().every(frame => frame.active <= 32), 'active reveal groups must stay bounded');
 fs.mkdirSync(artifactDir, {recursive:true});fs.writeFileSync(path.join(artifactDir, 'native-reveal-frames.json'), JSON.stringify(samples,null,2));
 console.log('PASS real SSE -> C++ -> snapshot -> DOM reveal frame progression');
 await wait(async()=>await page.locator('.reasoning').count()===2);
 await page.reload();await page.locator('.message.assistant h3 b').waitFor();assert.equal(await page.locator('.message.assistant h3 b').textContent(), '流式渐显检查');await page.locator('.reasoning summary').first().waitFor();await page.locator('.reasoning summary').first().click();assert((await page.locator('.reasoning-body').first().textContent()).includes('检查文件'));

 await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await page.close();await stop();
 // HTTPS reverse proxy drives real native token login and project management UI.
 const state=path.join(base,'server');let tokens={};for(const user of ['alice','bob'])tokens[user]=execFileSync(binary,['serve','--state-dir',state,'--add-user',user],{encoding:'utf8'}).match(/Login token \(save privately\): (\w+)/)[1];
 const key=path.join(base,'key.pem'),cert=path.join(base,'cert.pem');execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=127.0.0.1'],{stdio:'ignore'});let backend=await unused();proxy=https.createServer({key:fs.readFileSync(key),cert:fs.readFileSync(cert)},(req,res)=>{const upstream=http.request({host:'127.0.0.1',port:backend,path:req.url,method:req.method,headers:req.headers},reply=>{res.writeHead(reply.statusCode,reply.headers);reply.pipe(res);});upstream.on('error',()=>{res.writeHead(502);res.end();});req.pipe(upstream);});await new Promise(r=>proxy.listen(0,'127.0.0.1',r));const origin='https://127.0.0.1:'+proxy.address().port;await start(['serve','--state-dir',state,'--origin',origin],backend);
 const context=await browser.newContext({ignoreHTTPSErrors:true,viewport:{width:1440,height:1000}});page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(origin);await page.locator('#host-login').waitFor({state:'visible'});await page.locator('#host-user').fill('alice');await page.locator('#host-token').fill(tokens.alice);await page.locator('#host-login-form button').click();await page.locator('#host-controls').waitFor({state:'visible'});
 await page.locator('#host-create').click();await page.locator('[name="name"]').fill('demo');await page.locator('#dialog-submit').click();await page.waitForFunction(()=>document.querySelector('#host-project').value==='demo');await page.locator('#dialog').waitFor({state:'hidden'});await page.locator('#team-close').click();
 await page.locator('#host-manage').click();await page.getByRole('button',{name:'邀请成员',exact:true}).click();await page.locator('[name="username"]').fill('bob');await page.locator('#dialog-submit').click();await page.locator('#dialog').waitFor({state:'hidden'});await page.locator('#team-close').click();
 await page.locator('#host-scope').selectOption('personal');await page.waitForFunction(()=>document.getElementById('connection').textContent==='已连接');
 await page.locator('#settings-button').click();await page.locator('#provider-button').click();await page.getByRole('button',{name:'＋ 添加提供商',exact:true}).click();await page.locator('[name="name"]').fill('Browser fixture');await page.locator('[name="base_url"]').fill('http://127.0.0.1:'+model.address().port);await page.locator('[name="api"]').selectOption('responses');await page.locator('[name="models"]').fill('fixture');await page.locator('#dialog-submit').click();await page.getByRole('button',{name:'使用',exact:true}).click();await page.locator('#dialog-close').click();
 await page.locator('#prompt').fill('Personal native task');await page.locator('#send').click();await page.getByRole('button',{name:'允许',exact:true}).waitFor({timeout:20000});
 await page.locator('#prompt').fill('Queued while busy');await page.getByRole('button',{name:'加入任务队列',exact:true}).click();await page.waitForFunction(()=>document.getElementById('host-jobs').textContent.includes('排队任务')&&document.getElementById('host-jobs').textContent!=='无排队任务');
 await page.getByRole('button',{name:'允许',exact:true}).click();await page.getByRole('button',{name:'允许',exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.message.assistant').length>=2);const cookies=await context.cookies();assert(cookies.some(c=>c.name.startsWith('codex_session_')&&c.secure&&c.httpOnly&&c.sameSite==='Strict'));
 await page.screenshot({path:path.join(artifactDir, 'native-hosted-browser.png'),fullPage:true});await page.locator('#host-logout').click();await page.locator('#host-login').waitFor({state:'visible'});assert.deepEqual(errors,[]);console.log('PASS native local browser editor, model menu, single inline approval, real Agent write, mobile; HTTPS hosted login, project creation/invitation, personal provider/task, Secure cookies and logout');
 }finally{if(browser)await browser.close();await stop();if(proxy)await new Promise(r=>proxy.close(r));if(model)await new Promise(r=>model.close(r));fs.rmSync(base,{recursive:true,force:true});}})().catch(error=>{console.error(error);process.exitCode=1;});
