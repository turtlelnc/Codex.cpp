/* Cross-platform runtime smoke: no Agent sandbox, curl, Git, Python or paid provider needed. */
const assert=require('assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),net=require('net'),http=require('http');
const {spawn,spawnSync}=require('child_process');
const binary=path.resolve(process.argv[2]),root=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'native-smoke-'));let service;
async function port(){const s=net.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}
async function stop(){if(service&&service.exitCode===null){const process=service;service.kill();await new Promise(r=>process.once('exit',r));}service=null;}
async function start(args,p){let log='';service=spawn(binary,[...args,'--port',String(p),...(process.env.CODEX_TEST_EMBEDDED_ASSETS?[]:['--web-dir',path.join(root,'web')])],{env:{...process.env,CODEX_CPP_HOME:path.join(temp,'private')},stdio:['ignore','pipe','pipe']});service.stdout.on('data',b=>log+=b);service.stderr.on('data',b=>log+=b);for(let i=0;i<200;i++){if(service.exitCode!==null)throw Error(log);const ready=await new Promise(r=>{const s=net.connect(p,'127.0.0.1',()=>{s.destroy();r(true);});s.on('error',()=>r(false));});if(ready)return;await new Promise(r=>setTimeout(r,30));}throw Error('Service did not listen');}
class Client{
 constructor(p,host){this.p=p;this.host=host||'127.0.0.1:'+p;this.cookie='';this.csrf='';}
 async call(method,url,data,expected=200,headers={}){const encoded=data===undefined?'':JSON.stringify(data);const result=await new Promise((resolve,reject)=>{const req=http.request({host:'127.0.0.1',port:this.p,path:url,method,headers:{Host:this.host,Origin:(this.host==='smoke.native'?'https://':'http://')+this.host,Cookie:this.cookie,'Content-Type':'application/json','Content-Length':Buffer.byteLength(encoded),'X-Codex-Protocol':'1','X-CSRF-Token':this.csrf,...headers}},res=>{let body='';res.on('data',b=>body+=b);res.on('end',()=>resolve({code:res.statusCode,body,headers:res.headers}));});req.on('error',reject);req.end(encoded);});assert.equal(result.code,expected,(data?.op || method+' '+url)+': '+result.body);if(result.headers['set-cookie'])this.cookie=result.headers['set-cookie'][0].split(';')[0];const value=JSON.parse(result.body);if(value.csrf)this.csrf=value.csrf;return value;}
 rpc(op,data={},expected=200){return this.call('POST','/api/rpc',{op,...data},expected).then(r=>r.result);}
}
(async()=>{try{
 const project=path.join(temp,'project');fs.mkdirSync(project);fs.writeFileSync(path.join(project,'hello.txt'),'abc');let p=await port();await start(['web','--root',project],p);let c=new Client(p);await c.call('GET','/api/me');const file=await c.rpc('read',{path:'hello.txt'});assert.equal(file.version,require('crypto').createHash('sha256').update('abc').digest('hex'));await c.rpc('write',{path:'hello.txt',text:'native',base:file.version});assert.equal(fs.readFileSync(path.join(project,'hello.txt'),'utf8'),'native');await c.rpc('write',{path:'hello.txt',text:'stale',base:file.version},400);await c.rpc('read',{path:'../private'},400);await c.call('POST','/api/rpc',{op:'snapshot'},400,{'X-CSRF-Token':''});await c.call('GET','/api/me',undefined,400,{Host:'evil.example'});
 const journalDir=path.join(project,'.codex_cpp','sessions');fs.mkdirSync(journalDir,{recursive:true});
 const logArgs=JSON.stringify({command:'x'.repeat(40000)}),logOutput='exit_code=0\n'+'Y'.repeat(40000);
 fs.writeFileSync(path.join(journalDir,'session-log-test.items.jsonl'),[
 {type:'function_call',call_id:'log-test',name:'shell',arguments:logArgs},
 {type:'function_call_output',call_id:'log-test',output:logOutput}
 ].map(row=>JSON.stringify(row)).join('\n')+'\n');
 await c.rpc('session',{session_id:'session-log-test'});
 const preview=(await c.rpc('snapshot')).timeline[0];assert(preview.args_truncated&&preview.output_truncated);
 const full=await c.rpc('tool_log',{session_id:'session-log-test',call_id:'log-test'});assert.equal(full.arguments,logArgs);assert.equal(full.output,logOutput);
 await c.rpc('tool_log',{session_id:'another-session',call_id:'log-test'},400);
 await c.rpc('tool_log',{session_id:'session-log-test',call_id:'missing'},400);
 console.log('PASS current-session full tool logs, truncation flags and stale/missing log rejection');
await stop();
 const state=path.join(temp,'server');const enroll=spawnSync(binary,['serve','--state-dir',state,'--add-user','alice'],{encoding:'utf8'});assert.equal(enroll.status,0,enroll.stderr);const token=enroll.stdout.match(/Login token \(save privately\): (\w+)/)[1];p=await port();await start(['serve','--state-dir',state,'--origin','https://smoke.native'],p);c=new Client(p,'smoke.native');await c.call('GET','/api/me',undefined,401);await c.call('POST','/api/login',{username:'alice',password:'wrong'},400);await c.call('POST','/api/login',{username:'alice',password:token});await c.call('GET','/api/me');assert.deepEqual((await c.rpc('projects')).projects,[]);
 const concurrent=spawnSync(binary,['serve','--state-dir',state,'--add-user','bob'],{encoding:'utf8'});assert.notEqual(concurrent.status,0);await c.call('POST','/api/logout',{});await c.call('GET','/api/me',undefined,401);await stop();console.log('PASS native local editor/SHA256/CSRF/Host and hosted account/login/logout/state-writer lock');
 }finally{await stop();fs.rmSync(temp,{recursive:true,force:true});}})().catch(e=>{console.error(e);if(process.env.GITHUB_ACTIONS){const detail=(e.stack||String(e)).slice(0,6000).replaceAll('%','%25').replaceAll('\r','%0D').replaceAll('\n','%0A');console.error('::error title=Native smoke failure::'+detail);}process.exitCode=1;});
