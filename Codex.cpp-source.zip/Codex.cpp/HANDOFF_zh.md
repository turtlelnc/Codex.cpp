# MiniWeb 本地合并交接

这是源码包，不是预编译程序。已本地合并 PR #30 和 #31；未推送该合并、未合并 GitHub PR、未发布 Release。

main 基线：3334854ed8c5c38efd83b95a35d74f33de7dc12f
PR #30：https://github.com/turtlelnc/Codex.cpp/pull/30 （ec0102c604e169c0d30b1e8abdee8c5ed117b381）
PR #31：https://github.com/turtlelnc/Codex.cpp/pull/31 （479079f1b617c20396b6171a68559f71f154b5dd）
本地合并：e86e020df2fbff94523e926519fdfbe064f25f02
本地分支：handoff/local-merged-miniweb

## 已完成
字体 em 缩放、小数字号缓存、零宽及透明边框、currentColor、initial/unset 重置等修复。
基础表格支持独立边框、共享列宽、固定和简单自动列宽、换行、单元格对齐、行组、隐藏行、嵌套表格、CSS display:table、脚本插入行和计算样式/几何同步。常见 inline-block 按钮基线已修正。

本地构建、ASan（含泄漏检查）、CLI/Agent 图片回传/隔离及 Chromium 对照通过。表格用例在 640px 和 320px 下比较 56 个元素的矩形，误差小于 1px；另测像素、文字对齐和动态重排。参考截图在 handoff-reference。这不是任意页面的 Chromium 等价保证。

## 未完成与注意事项
最新远端 CI 未等待完成，不能声称全部通过。此前 Linux CI 遇到 Ubuntu 镜像 DNS/HTTPS 连接失败；macOS、Windows、ASan 有通过记录。CI 已增加代理/CA 传递、HTTPS 探测及 kernel.org 上 Ubuntu 签名归档的回退，未关闭 APT 签名或 TLS 验证。接手后请检查最新 Actions 日志，区分基础设施故障与代码错误，勿跳过测试。

PR #31 是草稿，base 为 #30 的分支。恢复验证后先合并 #30，再将 #31 的 base 改为 main，审查和验证后再合并；不要直接覆盖远端 main。

表格尚不支持或仅近似：rowspan/colspan、折叠边框、caption、col/colgroup、inline-table、匿名表格盒、复杂百分比/min/max 自动列宽、行组高度分配。其他限制见 docs/MINIWEB.md。下一步优先审查表格算法与负面用例，再逐项扩展。

## 编译
运行时仍是单文件 C++17，不需要 Python、Node 或 Chromium。构建需 CMake、C/C++ 编译器；首次下载 libgit2/libcurl，离线路径参数见 README.md。本包不含依赖缓存或构建产物。

    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build --config Release --target codex-cpp miniweb-regression --parallel 2
    ./build/miniweb/miniweb-regression miniweb/test/structural.html
    ./build/codex-cpp preview shot miniweb/test/tables.html -o tables.png --width 640 --height 800
    node tests/miniweb_test.cjs build/codex-cpp

仅开发测试需要 Node/Playwright/Chromium。安装后，Linux 可执行：

    node tests/miniweb_test.cjs build/codex-cpp build/miniweb/miniweb-regression --browser

Visual Studio 产物通常在 build/Release，回归工具在 build/miniweb/Release。Windows 公共预览仍因缺少 AppContainer 而拒绝执行；不要绕过隔离。macOS/Linux 预览需系统沙箱与字体。

包内保留源码、测试、文档、许可证、CI；不含 .git、账号、密钥、会话或构建目录。交接补丁仅供查看范围，源码已包含修改，不要重复应用。
