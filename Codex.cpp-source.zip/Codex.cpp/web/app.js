'use strict';
(() => {

/* ---------- 基础 ---------- */

const $ = id => document.getElementById(id);
const newId = () => crypto.randomUUID().replaceAll('-', '');
const state = {
  generation: 0, project: 'local', scope: 'shared', user: null, snap: null, polling: false, signature: '', toolSignature: '',
  openTools: new Set(), file: null, panel: 'code', model: '', reasoning: '', permission: 'workspace',
  tree: null, diffSignature: '', fileList: [], expanded: new Set(), provider: null,
};
const editor = {revision: 0, loadTicket: 0, baseline: '', path: null, version: '', crlf: false, editable: true, dirty: false, conflict: false, lines: 0, saving: false};

// 所有非可信文本（模型输出、文件、Diff）只经 textContent 写入。
function el(tag, text, cls) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (cls) node.className = cls;
  return node;
}

const STALE = '忽略过期请求';
function notice(message) {
  if (message === STALE) return;
  $('notice').textContent = message;
  $('notice').hidden = !message;
}

function setConnection(label, ok) {
  $('connection').textContent = label;
  $('connection').dataset.state = ok ? 'ok' : 'error';
  $('retry-connection').hidden=ok;
}

function onClick(id, fn) {
  $(id).addEventListener('click', async () => {
    try { await fn(); } catch (e) { notice(e.message); }
  });
}

/* ---------- 网络 ---------- */

async function http(path, body, wire = 1) {
  const generation = state.generation;
  const options = body === undefined ? {} : {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': state.user?.csrf || '', 'X-Codex-Protocol': String(wire)},
    body: JSON.stringify(body),
  };
  const controller = new AbortController();
  options.signal = controller.signal;
  const timeout = setTimeout(() => controller.abort(), 35000);
  let response, data;
  try {
    response = await fetch(path, options);
    data = await response.json();
  } catch (error) {
    if (generation !== state.generation) throw Error(STALE);
    const failure=error.name === 'AbortError' ? Error('请求超时，请检查连接后重试') : error;failure.network=true;throw failure;
  } finally { clearTimeout(timeout); }
  if (generation !== state.generation) throw Error(STALE);
  if (response.status === 401) { $('workspace').hidden = true; $('host-login').hidden = false; throw new Error('请登录服务器工作区'); }
  if (!response.ok) {const failure=new Error(data.error || '请求失败');failure.network=[408,429,500,502,503,504].includes(response.status);throw failure;}
  return data;
}

const teamReadOperations = new Set(['projects','list','project_status','member_candidates','providers','models','snapshot','files','read','diff','tool_log','plugin_catalog','status','side_snapshot','preferences','suggestions_snapshot']);
function teamProtocol() {
  const peer = state.user?.protocol;
  if (!peer) return { wire: state.user?.mode === 'server' ? 0 : 1, readOnly: state.user?.mode === 'server' };
  if (peer.application !== 'codex-cpp' || !Array.isArray(peer.protocols) || !peer.protocols.includes(1) ||
      !Array.isArray(peer.capabilities) || !peer.capabilities.includes('scope-auth.v1') || !peer.capabilities.includes('snapshot.full.v1'))
    throw Error('服务器协议不兼容，请更新网页或安装适用的服务端兼容插件');
  return { wire: 1, readOnly: !['approval.bound.v1','request-id.v1','team.write.v1'].every(name => peer.capabilities.includes(name)) };
}
async function rpc(op, values = {}) {
  const protocol = teamProtocol();
  if (op === 'snapshot' && !state.user?.protocol?.capabilities?.includes('snapshot.delta.v1')) delete values.since;
  if (protocol.readOnly && !teamReadOperations.has(op)) throw Error('兼容只读：服务器尚未协商审批、去重和写入语义，操作未发送');
  const generation=state.generation;const result=(await http('/api/rpc', {op, project: state.project, scope: state.scope, ...values}, protocol.wire)).result;if(generation!==state.generation)throw Error(STALE);return result;
}

/* ---------- 对话框 ---------- */

function field(name, label, type = 'text', value = '', options = [], required = type !== 'password') {
  return {name, label, type, value, options, required};
}

function showDialog(title, body) {
  $('dialog-title').textContent = title;
  $('dialog-submit').hidden=false;$('dialog-cancel').hidden=false;
  $('dialog-body').replaceChildren(body);
  $('dialog-error').textContent = '';
  $('dialog-submit').hidden = true;
  $('dialog-cancel').textContent = '关闭';
  $('dialog-form').onsubmit = event => event.preventDefault();
  if (!$('dialog').open) $('dialog').showModal();
}

function openDialog(title, fields, submit, preview = '') {
  $('dialog-submit').hidden = false;
  $('dialog-cancel').textContent = '取消';
  $('dialog-title').textContent = title;
  $('dialog-submit').hidden=false;$('dialog-cancel').hidden=false;
  $('dialog-body').replaceChildren();
  $('dialog-error').textContent = '';
  for (const f of fields) {
    const label = el('label', f.label);
    const input = el(f.type === 'select' ? 'select' : f.type === 'textarea' ? 'textarea' : 'input');
    input.name = f.name;
    if (f.type === 'select') for (const value of f.options) input.append(new Option(value, value));
    else if (f.type !== 'textarea') input.type = f.type;
    input.value = f.value;
    input.required = f.required;
    if (f.type === 'password') input.autocomplete = 'new-password';
    label.append(input);
    $('dialog-body').append(label);
  }
  if (preview) $('dialog-body').append(el('pre', preview));
  $('dialog-form').onsubmit = async event => {
    event.preventDefault();
    $('dialog-submit').disabled = true;
    try {
      const next = await submit(Object.fromEntries(new FormData(event.target)));
      for (const input of $('dialog-body').querySelectorAll('input[type=password]')) input.value = '';
      $('dialog').close();
      notice('');
      if (typeof next === 'function') next();
      await refresh();
    } catch (e) {
      $('dialog-error').textContent = e.message;
    } finally {
      $('dialog-submit').disabled = false;
    }
  };
  $('dialog').showModal();
}

onClick('dialog-close', () => $('dialog').close());
onClick('dialog-cancel', () => $('dialog').close());

/* ---------- 设置与缓存的模型建议 ---------- */
const preferences = { loaded: false, side_chat: true, auto_suggestions: false, carry_reasoning: false };
const suggestions = {
  cache: null,
  node: el('section', undefined, 'next-steps'),
  loading: false,
  ticket: 0,
  lastActivity: Date.now(),
  attempted: new Set(),
};
function applyPreferences(value) {
  Object.assign(preferences, {
    loaded: true,
    side_chat: value.side_chat !== false,
    auto_suggestions: value.auto_suggestions === true,
    carry_reasoning: value.carry_reasoning === true,
  });
  $('preference-reasoning').disabled = !state.user?.protocol?.capabilities?.includes('settings.reasoning.v1');
  $('preference-reasoning').checked = preferences.carry_reasoning;
  $('preference-reasoning').title = $('preference-reasoning').disabled?'当前服务器尚未支持推理回传设置':'';
  $('preference-side').disabled = false;
  $('preference-suggestions').disabled = false;
  $('preference-side').checked = preferences.side_chat;
  $('preference-suggestions').checked = preferences.auto_suggestions;
  $('side-chat-toggle').hidden = !preferences.side_chat;
  document.querySelector('[data-panel="side"]').hidden = !preferences.side_chat;
  if (!preferences.side_chat && state.panel === 'side') setInspector(false);
}
async function loadPreferences() {
  if (
    (state.user?.mode === 'server' && !state.project) ||
    !state.user?.protocol?.capabilities?.includes('suggestions.v1')
  ) {
    $('preference-reasoning').disabled = true;
    $('preference-side').disabled = true;
    $('preference-suggestions').disabled = true;
    return;
  }
  const generation = state.generation;
  const value = await rpc('preferences');
  if (generation === state.generation) applyPreferences(value);
}
for (const [id, name] of [
  ['preference-side', 'side_chat'],
  ['preference-suggestions', 'auto_suggestions'],
  ['preference-reasoning', 'carry_reasoning'],
])
  $(id).onchange = async () => {
    const input = $(id),
      value = input.checked,
      generation = state.generation;
    for(const id of ['preference-side','preference-suggestions','preference-reasoning'])$(id).disabled=true;
    try {
      const next = await rpc('preferences_save', { [name]: value });
      if (generation !== state.generation) return;
      applyPreferences(next);
      $('preference-status').textContent = '已保存';
      suggestions.lastActivity = Date.now();
    } catch (e) {
      if(generation!==state.generation)return;
      input.checked = !value;
      $('preference-status').textContent = e.message;
    } finally {
      if(generation===state.generation)applyPreferences(preferences);
    }
  };
function suggestionButton(action) {
  const chars = Array.from(String(action.title || '')),
    label = chars.length > 12 ? chars.slice(0, 11).join('') + '…' : chars.join('');
  const b = el('button', label);
  b.type = 'button';
  b.title = action.prompt;
  b.onclick = () => {
    if ($('prompt').value.trim() && !confirm('替换尚未发送的输入？')) return;
    $('prompt').value = action.prompt;
    $('prompt').focus();
  };
  return b;
}
function paintSuggestions() {
  const cache = suggestions.cache,
    box = $('messages');
  if (
    !cache?.actions?.length ||
    state.snap?.busy ||
    cache.source_session !== state.snap?.session_id ||
    cache.source_revision !== state.snap?.suggestion_context
  ) {
    suggestions.node.remove();
    return;
  }
  const signature = JSON.stringify(cache);
  if (suggestions.node._signature !== signature) {
    suggestions.node._signature = signature;
    const actions = el('div', undefined, 'sugg');
    for (const action of cache.actions) actions.append(suggestionButton(action));
    suggestions.node.replaceChildren(
      el('h3', '下一步 · 模型建议'),
      el('p', '已完成：' + (cache.done || '尚无明确记录')),
      el('p', '建议：' + (cache.next || '')),
      actions,
    );
  }
  box.append(suggestions.node);
}
async function updateSuggestions(generate = false) {
  if (!state.user?.protocol?.capabilities?.includes('suggestions.v1') || suggestions.loading)
    return;
  const generation = state.generation,
    ticket = suggestions.ticket;
  const view = captureChatView();
  suggestions.loading = true;
  try {
    const cache = await rpc(generate ? 'suggestions_generate' : 'suggestions_snapshot');
    if (generation !== state.generation || ticket !== suggestions.ticket) return;
    suggestions.cache = cache;
    paintSuggestions();
    if (!state.snap?.timeline?.length) {
      state.signature = '';
      await refresh();
    }
    if (view.nearBottom) $('messages').scrollTop = $('messages').scrollHeight;
  } catch (e) {
    if (generate && generation === state.generation) notice('未能生成自动建议：' + e.message);
  } finally {
    if (ticket === suggestions.ticket) suggestions.loading = false;
  }
}
for (const name of ['pointerdown', 'keydown', 'input', 'scroll'])
  document.addEventListener(name, () => (suggestions.lastActivity = Date.now()), {
    capture: true,
    passive: true,
  });
document.addEventListener('visibilitychange', () => (suggestions.lastActivity = Date.now()));
setInterval(() => {
  if (
    !preferences.loaded ||
    !preferences.auto_suggestions ||
    !state.snap ||
    state.switching ||
    !state.user ||
    document.hidden
  )
    return;
  if (state.snap.busy) {
    suggestions.lastActivity = Date.now();
    return;
  }
  if (suggestions.cache?.generating) {
    updateSuggestions().catch(() => {});
    return;
  }
  const session = state.snap.session_id,
    key = sideKey();
  if (
    !session ||
    !state.snap.timeline?.some((row) => row.k === 'assistant') ||
    $('prompt').value.trim() ||
    editor.dirty ||
    document.querySelector('dialog[open]') ||
    Date.now() - suggestions.lastActivity < 120000 ||
    suggestions.attempted.has(key)
  )
    return;
  suggestions.attempted.add(key);
  updateSuggestions(true).catch(() => {});
}, 5000);

/* ---------- 独立只读侧聊 ---------- */
const side = {
  key: '',
  loading: false,
  sending: false,
  ticket: 0,
  nodes: new Map(),
  drafts: new Map(),
  pending: null,
};
function sideKey() {
  return [state.user?.username, state.project, state.scope, state.snap?.session_id || ''].join('/');
}
function resetSide() {
  if (side.key) side.drafts.set(side.key, $('side-prompt').value);
  side.key = '';
  side.ticket++;
  side.loading = false;
  side.sending = false;
  side.nodes.clear();
  $('side-messages').replaceChildren();
  $('side-prompt').value = '';
  $('side-status').textContent = '';
}
function sideError(e) {
  if (e.message !== STALE) $('side-status').textContent = e.message;
}
async function refreshSide() {
  if (!state.snap || !state.user?.protocol?.capabilities?.includes('side-chat.v1')) {
    $('side-status').textContent = '此服务尚不支持侧聊';
    $('side-send').disabled = true;
    return;
  }
  const key = sideKey();
  if (side.key !== key) {
    resetSide();
    side.key = key;
    $('side-prompt').value = side.drafts.get(key) || '';
  }
  if (side.loading) return;
  side.loading = true;
  const ticket = side.ticket,
    generation = state.generation;
  try {
    const snap = await rpc('side_snapshot', { main_session: state.snap.session_id || '' });
    if (ticket !== side.ticket || generation !== state.generation || key !== sideKey()) return;
    const box = $('side-messages'),
      near = box.scrollHeight - box.scrollTop - box.clientHeight < 64,
      rows = [];
    for (const [i, row] of (snap.timeline || []).entries()) {
      if (!['user', 'assistant', 'tool'].includes(row.k)) continue;
      let text = row.text || '';
      if (row.k === 'user' && text.startsWith('You are a separate read-only discussion assistant.'))
        text = text.split('\nSide question:\n').slice(1).join('\nSide question:\n');
      if (row.k === 'tool')
        text = (row.name || '工具') + ': ' + String(row.output || row.text || '').slice(0, 1600);
      rows.push({ id: row.row_key || String(i), kind: row.k, text });
    }
    if (snap.busy && snap.draft)
      rows.push({ id: 'live', kind: 'assistant', text: snap.draft, live: true });
    if (!rows.length)
      rows.push({
        id: 'empty',
        kind: 'hint',
        text: '在这里讨论方案、询问进度或阅读代码。侧聊不会修改文件。',
      });
    const keep = new Set();
    let previous = null;
    for (const row of rows) {
      keep.add(row.id);
      let node = side.nodes.get(row.id);
      if (!node) {
        node = el('article', undefined, 'side-message ' + row.kind);
        side.nodes.set(row.id, node);
      }
      if (node._text !== row.text || node._live !== row.live) {
        node._text = row.text;
        node._live = row.live;
        node.replaceChildren(markdown(row.text));
        if (row.kind === 'assistant' && !row.live) {
          const b = el('button', '转交主 Agent');
          b.type = 'button';
          b.onclick = () => forwardSide(row.text);
          node.append(b);
        }
      }
      if (node !== (previous ? previous.nextSibling : box.firstChild))
        box.insertBefore(node, previous ? previous.nextSibling : box.firstChild);
      previous = node;
    }
    for (const [id, node] of side.nodes)
      if (!keep.has(id)) {
        node.remove();
        side.nodes.delete(id);
      }
    if (near) box.scrollTop = box.scrollHeight;
    $('side-status').textContent =
      snap.error ||
      (snap.busy
        ? snap.pending
          ? '侧聊等待授权，已拒绝写入权限；可停止侧聊'
          : '侧聊处理中 · 主任务独立运行'
        : '只读讨论 · 转交前可以编辑内容');
    $('side-send').disabled = snap.busy || side.sending || teamProtocol().readOnly;
    $('side-stop').hidden = !snap.busy;
  } finally {
    if (ticket === side.ticket) side.loading = false;
  }
}
$('side-composer').onsubmit = async (event) => {
  event.preventDefault();
  if (side.sending) return;
  const text = $('side-prompt').value;
  if (!text.trim()) return;
  const generation = state.generation,
    key = sideKey(),
    main = state.snap?.session_id || '';
  const pending =
    side.pending?.key === key && side.pending.text === text
      ? side.pending
      : { key, text, request_id: newId() };
  side.pending = pending;
  side.sending = true;
  $('side-send').disabled = true;
  try {
    await rpc('side_send', { text, request_id: pending.request_id, main_session: main });
    if (generation !== state.generation || key !== sideKey()) return;
    if ($('side-prompt').value === text) $('side-prompt').value = '';
    side.pending = null;
    side.drafts.delete(key);
    await refreshSide();
  } catch (e) {
    if (generation === state.generation && key === sideKey()) sideError(e);
  } finally {
    if (generation === state.generation) {
      side.sending = false;
      refreshSide().catch(sideError);
    }
  }
};
$('side-prompt').addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    $('side-composer').requestSubmit();
  }
});
onClick('side-stop', async () => {
  await rpc('side_stop', { main_session: state.snap?.session_id || '' });
  await refreshSide();
});
onClick('side-chat-toggle', () => {
  showInspector('side');
  $('side-prompt').focus();
});
function forwardSide(text) {
  const generation = state.generation,
    key = sideKey(),
    session = state.snap?.session_id || '',
    rid = newId();
  let interrupted = false;
  openDialog(
    '转交主 Agent（将中断当前任务）',
    [field('text', '确认或编辑要转交的内容', 'textarea', text)],
    async (fields) => {
      if (generation !== state.generation || key !== sideKey())
        throw Error('会话已切换，请重新转交');
      if (!interrupted) {
        await rpc('stop', { expected_session: session });
        interrupted = true;
      }
      for (let i = 0; i < 100; i++) {
        const snap = await rpc('snapshot');
        if (generation !== state.generation || key !== sideKey()) throw Error('会话已切换，未发送');
        if (!snap.busy) break;
        if (i === 99) throw Error('主任务尚未停止，内容已保留，请稍后重试');
        await new Promise((r) => setTimeout(r, 100));
      }
      await rpc('send', { text: fields.text, request_id: rid, expected_session: session });
      return () =>
        notice(
          state.user.mode === 'server'
            ? '已提交到主任务队列；若项目已暂停，请先审核并恢复项目。'
            : '已转交主 Agent',
        );
    },
    '只有确认提交才会停止主任务。现有修改会保留，主 Agent 继续遵守原有权限。多人项目可能需要审核恢复，侧聊不会绕过此检查。',
  );
}

/* ---------- 代码高亮与 Diff 解析 ---------- */

const KW = new Set('int char bool void auto const static inline struct class return if else for while switch case break continue namespace using include std string size_t nullptr true false new delete public private virtual template typename function let var import export from async await def'.split(' '));
const CODE_EXT = new Set(['c', 'cc', 'cpp', 'h', 'hpp', 'inc', 'mm', 'js', 'ts', 'java', 'rs', 'go', 'json']);
const extOf = p => (String(p).split('.').pop() || '').toLowerCase();

// 返回 [{text, cls}] 片段，调用方用 textContent 写入。
function highlight(src, path) {
  if (path && !CODE_EXT.has(extOf(path))) return [{text: src}];
  const re = /(\/\/.*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(^\s*#\s*\w+)|(\b\d+\b)|(\b[A-Za-z_]\w*\b)/gm;
  const out = [];
  let last = 0, m;
  while ((m = re.exec(src))) {
    if (m.index > last) out.push({text: src.slice(last, m.index)});
    const cls = m[1] ? 'c' : m[2] ? 's' : m[3] ? 'p' : m[4] ? 'nm' : KW.has(m[0]) ? 'k' : '';
    out.push({text: m[0], cls});
    last = m.index + m[0].length;
  }
  if (last < src.length) out.push({text: src.slice(last)});
  return out;
}

function codeLine(num, prefix, text, path, cls) {
  const row = el('div', undefined, 'ln' + (cls ? ' ' + cls : ''));
  const t = el('span', undefined, 't');
  if (prefix) t.append(prefix);
  for (const part of highlight(text, path)) t.append(part.cls ? el('span', part.text, part.cls) : document.createTextNode(part.text));
  if (!text && !prefix) t.append(' ');
  row.append(el('span', String(num), 'n'), t);
  return row;
}

function parsePatch(patch) {
  const files = [], rows = String(patch).split('\n');
  let cur = null, o = 0, n = 0, inHunk = false;
  for (let i = 0; i < rows.length; i++) {
    const raw = rows[i];
    if (raw.startsWith('diff ')) { inHunk = false; continue; }
    if (!inHunk || (raw.startsWith('--- ') && (rows[i + 1] || '').startsWith('+++ '))) {
      if (raw.startsWith('+++ ')) { cur = {path: raw.slice(4).replace(/^b\//, '').trim(), lines: []}; files.push(cur); inHunk = false; continue; }
      if (raw.startsWith('--- ')) { inHunk = false; continue; }
    }
    const h = /^@@ -(\d+)(?:,\d+)? \+(\d+)/.exec(raw);
    if (h) { o = +h[1]; n = +h[2]; inHunk = true; if (cur) cur.lines.push({t: 'hunk', n: '', s: raw}); continue; }
    if (!cur || !inHunk) continue;
    if (raw.startsWith('+')) cur.lines.push({t: 'add', n: n++, s: raw.slice(1)});
    else if (raw.startsWith('-')) cur.lines.push({t: 'del', n: o++, s: raw.slice(1)});
    else if (raw.startsWith(' ')) { cur.lines.push({t: 'ctx', n, s: raw.slice(1)}); o++; n++; }
  }
  return files;
}

function diffBlock(files, single) {
  const box = el('div', undefined, 'diff-files');
  for (const f of files) {
    if (!single || files.length > 1) box.append(el('div', f.path, 'diff-path'));
    const pre = el('div', undefined, 'code');
    for (const l of f.lines) {
      if (l.t === 'hunk') pre.append(codeLine('', '', l.s, '', 'dl hunk'));
      else pre.append(codeLine(l.n, l.t === 'add' ? '+ ' : l.t === 'del' ? '- ' : '  ', l.s, f.path, 'dl ' + l.t));
    }
    box.append(pre);
  }
  return box;
}

/* ---------- Markdown（DOM 构造，不使用 innerHTML） ---------- */

function markdown(text) {
  const node = CodexPlugin.call('markdown.render', { text });
  if (!(node instanceof HTMLElement) || !node.classList.contains('md')) throw Error('Plugin Markdown renderer must return an .md element');
  return node;
}
function markdownBuiltin(text) {
  return CodexMarkdown.render(text, {highlight, onFileLink: async path => {try{await openFile(decodeURIComponent(path.split('#')[0]));}catch(error){notice(error.message);}} });
}

/* ---------- 工具调用 ---------- */

function parseArgs(raw) { try { return JSON.parse(raw || '{}') || {}; } catch { return {}; } }

function toolSummary(name, rawArgs) {
  const a = parseArgs(rawArgs);
  if (name === 'shell') return a.command || '';
  if (name === 'apply_patch') return parsePatch(a.patch || '').map(f => f.path).join(', ') || 'patch';
  const first = a.path ?? a.name ?? Object.values(a)[0];
  return first === undefined ? '' : String(first);
}

// Describe the observable operation without asking a model to invent a summary.
function toolAction(name, rawArgs) {
  if (name === 'shell') {
    const command = String(parseArgs(rawArgs).command || '').trim();
    if (/^(?:printf|echo)\s/.test(command)) return '打印文本';
    if (/^(?:rg|grep)\s/.test(command)) return '搜索文本';
    if (/^git\s/.test(command)) return '运行 Git 命令';
  }
  return ({shell: '运行命令', read_file: '读取文件', list_dir: '查看目录',
    write_file: '写入文件', apply_patch: '应用补丁', search: '搜索代码',
    search_files: '搜索文件'})[name] || '调用 ' + name;
}
function executionSummary(group) {
  const active = group.find(item => item.status === 'running') ||
    group.find(item => item.status === 'queued');
  if (active) return (active.status === 'running' ? '正在' : '等待执行：') + toolAction(active.row.name, active.row.args);
  if (group.length === 1) {
    const row = group[0].row;
    return toolAction(row.name, row.args) + (row.name === 'shell' ? '' : '：' + toolSummary(row.name, row.args));
  }
  if (group.every(item => item.row.name === 'shell')) return '运行 ' + group.length + ' 条命令';
  if (group.every(item => item.row.name === 'read_file')) return '读取 ' + group.length + ' 个文件';
  return '执行 ' + group.length + ' 项操作';
}

function toolDetail(name, rawArgs) {
  const a = parseArgs(rawArgs);
  if (name === 'shell') return '$ ' + (a.command || '');
  if (name === 'write_file') return (a.path || '') + '\n\n' + (a.content || '');
  return rawArgs || '';
}

const toolLabels = {
  approval: '等待批准',
  running: '执行中',
  queued: '等待结果',
  returned: '已返回',
  completed: '已完成',
  failed: '失败',
  denied: '已拒绝',
  interrupted: '已中断',
};
function toolEventMap(snap) {
  const events = new Map();
  for (const event of snap.events || [])
    if (event.type === 'tool.started' || event.type === 'tool.completed')
      events.set(event.payload?.call_id, event);
  return events;
}
function toolStatus(row, snap, events) {
  if (snap.pending && (snap.pending.tool_call_id || snap.pending.call_id) === row.id && row.output == null)
    return 'approval';
  if (/^DENIED(?: by user|:)/.test(row.output || '')) return 'denied';
  if (/^(?:Interrupted |Cancelled after interruption)/.test(row.output || '')) return 'interrupted';
  const event = events.get(row.id);
  const code =
    event?.type === 'tool.completed'
      ? event.payload.exit_code
      : /^exit_code=(-?\d+)\b/.exec(row.output || '')?.[1];
  if (code !== undefined && Number(code) !== 0) return 'failed';
  if (row.output != null) return code !== undefined ? 'completed' : 'returned';
  if (!snap.busy) return 'interrupted';
  return event?.type === 'tool.started' ? 'running' : 'queued';
}
async function openToolLog(id) {
  const session = state.snap?.session_id;
  const result = await rpc('tool_log', { call_id: id, session_id: session });
  if (session !== state.snap?.session_id) return;
  const body = el('div');
  body.append(
    el('p', '当前会话保存的原始参数与输出。'),
    el('pre', result.arguments, 'raw-tool-log'),
    el('pre', result.output ?? '尚未收到工具结果', 'raw-tool-log'),
  );
  showDialog(result.name + ' · 完整日志', body);
}

async function decide(allow) {
  if (state.deciding) return;
  state.deciding = true;
  const trigger = document.activeElement;
  for (const b of document.querySelectorAll('[data-decide]')) b.disabled = true;
  try {
    await rpc('approve', { approval: state.snap?.pending?.call_id, allow });
  } catch (e) {
    notice(e.message);
  }
  state.deciding = false;
  await refresh();
  for (const b of document.querySelectorAll('[data-decide]')) b.disabled = false;
  if (trigger?.matches('[data-decide]') && !trigger.isConnected)
    (document.querySelector('.conversation').inert ? $('inspector-toggle') : $('prompt')).focus({
      preventScroll: true,
    });
}

function approvalBar(name) {
  const bar = el('div', undefined, 'approve');
  bar.append(
    el('span', name === 'apply_patch' ? '应用此补丁？' : name === 'shell' ? '运行此命令？' : '允许此操作？'),
    el('span', undefined, 'sp'),
  );
  const deny = el('button', '拒绝'),
    allow = el('button', '允许', 'primary');
  deny.dataset.decide = allow.dataset.decide = '1';
  deny.type = allow.type = 'button';
  deny.onclick = () => decide(false);
  allow.onclick = () => decide(true);
  bar.append(deny, allow);
  return bar;
}

function creatorReport(row) {
  if (!['plugin_check', 'plugin_test'].includes(row.name) || typeof row.output !== 'string') return null;
  try {
    const data = JSON.parse(row.output);
    return data.creator === true && typeof data.id === 'string' && typeof data.manifest === 'string' ? data : null;
  } catch { return null; }
}
function creatorReviewCard(data, probe) {
  const node = el('section', undefined, 'message creator-review');
  node.setAttribute('aria-label', '插件审阅：' + data.id);
  node.append(el('strong', 'Plugin · ' + data.id));
  const probed = probe?.status === 'native_probe_passed' && JSON.stringify(probe.sha256) === JSON.stringify(data.sha256);
  const status = data.kind === 'native'
    ? !data.built ? '等待构建 · 未启用' : probed ? '隔离加载测试通过 · 功能仍待验证 · 未启用' : '静态结构检查通过 · 尚未测试原生加载'
    : '静态结构检查通过 · 界面行为尚未验证 · 未启用';
  node.append(el('p', data.enabled ? status.replace('未启用', '同 ID 模组已加载，更改需重启') : status), el('p', data.kind === 'native' ? '原生插件拥有宿主权限；请审阅源代码和实际功能，再手动重启启用。多人服务由管理员配置。' : '网页插件可访问当前会话；请审阅并验证界面，再手动重启启用。多人服务由管理员配置。'));
  if (data.review_sha256) node.append(el('p', '审阅指纹 ' + data.review_sha256.slice(0, 16) + '… · 启动时校验 · 不代表安全审查或启用授权'));
  const actions = el('div', undefined, 'creator-actions');
  const inspect = el('button', '查看清单'); inspect.type = 'button';
  inspect.onclick = () => openFile(data.manifest_relative).catch(error => notice(error.message));
  actions.append(inspect);
  const details = el('details'); details.append(el('summary', '本地示例启动命令'), el('pre', data.launch_command || ''));
  if (data.kind === 'web' || data.built) {
    const copy = el('button', '复制手动启用命令'); copy.type = 'button';
    copy.onclick = async () => { try { await navigator.clipboard.writeText(data.launch_command); copy.textContent = '已复制 · 未执行'; } catch { notice('复制失败，请展开命令手动复制'); } };
    actions.append(copy);
  }
  node.append(actions, details);
  return node;
}

function toolCard(...args) { return CodexPlugin.call('tool.card', { args }); }
function toolCardBuiltin(
  id,
  name,
  args,
  output,
  awaiting,
  status = awaiting ? 'approval' : output == null ? 'queued' : 'returned',
  truncated = false,
) {
  const done = output !== null && output !== undefined;
  const failed = ['failed', 'denied', 'interrupted'].includes(status);
  const card = el('div', undefined, 'tool' + (failed ? ' err' : ''));
  card.dataset.toolId = id;
  card.dataset.state = status;
  const head = el('div', undefined, 'tool-h');
  head.append(
    el('span', failed ? '!' : done ? '·' : '', status === 'running' ? 'st spin' : 'st mark'),
    el('span', toolAction(name, args), 'name'),
    el('span', name === 'shell' ? '' : toolSummary(name, args), 'arg'),
    el('span', toolLabels[status], 'tool-state'),
  );
  const body = el('div', undefined, 'tool-b');
  if (name === 'apply_patch') {
    const files = parsePatch(parseArgs(args).patch || '');
    body.append(files.length ? diffBlock(files, true) : el('pre', args));
    if (done) body.append(el('pre', output, 'tool-out'));
  } else {
    body.append(el('div', name === 'shell' ? 'Shell' : name, 'tool-kind'), el('pre', toolDetail(name, args)));
    if (done) body.append(el('div', '输出', 'tool-kind'), el('pre', output, 'tool-out'));
  }
  const logs = el('button', truncated ? '预览已截断 · 查看完整日志' : '查看原始参数与完整日志', 'tool-log');
  logs.type = 'button';
  logs.onclick = () => openToolLog(id).catch((error) => notice(error.message));
  const actions = el('div', undefined, 'tool-actions');
  actions.append(logs);
  if (name === 'shell' || name === 'apply_patch') {
    const inspect = el('button', name === 'shell' ? '在终端查看' : '查看工作区变更', 'tool-log');
    inspect.type = 'button';
    inspect.onclick = () => showInspector(name === 'shell' ? 'terminal' : 'changes');
    actions.append(inspect);
  }
  body.append(actions);
  card.append(head, body);
  if (awaiting || state.openTools.has(id)) card.classList.add('open');
  head.setAttribute('role', 'button');
  head.tabIndex = 0;
  head.setAttribute('aria-expanded', String(card.classList.contains('open')));
  head.onkeydown = (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      head.click();
    }
  };
  head.onclick = () => {
    card.classList.toggle('open');
    head.setAttribute('aria-expanded', String(card.classList.contains('open')));
    if (card.classList.contains('open')) state.openTools.add(id);
    else state.openTools.delete(id);
  };
  if (awaiting) card.append(approvalBar(name));
  return card;
}

/* ---------- 对话渲染 ---------- */

function userBubble(text) { return CodexPlugin.call('message.user', { text }); }
function userBubbleBuiltin(text) {
  const node = el('div', undefined, 'message user');
  node.append(document.createTextNode(text));
  return node;
}

// Only new text animates, with at most 16 groups per update.
const streamReducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const streamSegmenter =
  typeof Intl.Segmenter === 'function' ? new Intl.Segmenter(undefined, { granularity: 'grapheme' }) : null;
function streamMarkup(text) {
  const body = markdown(text),
    walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
  const leaves = [];
  let leaf,
    offset = 0;
  while ((leaf = walker.nextNode())) if(!leaf.parentElement.closest('button, .md-code-header, .md-math'))leaves.push(leaf);
  for (const textNode of leaves) {
    const span = el('span', undefined, 'stream-text');
    span._offset = offset;
    offset += textNode.length;
    textNode.replaceWith(span);
    span.append(textNode);
  }
  body._streamText=leaves.map(leaf=>leaf.textContent).join('');
  return body;
}
function settleStreamLeaf(leaf) {
  for (const finish of [...(leaf._streamFinishes || [])]) finish();
  normalizeStreamLeaf(leaf);
}
function normalizeStreamLeaf(leaf) {
  const selection = getSelection();
  if (
    !selection ||
    selection.isCollapsed ||
    (!leaf.contains(selection.anchorNode) && !leaf.contains(selection.focusNode))
  )
    leaf.normalize();
}
function appendStreamText(leaf, delta, budget, offset) {
  if (!delta) return;
  // Formatting changes may create new elements around existing text. Never replay it.
  const existing = Math.min(delta.length, Math.max(0, budget.oldLength - offset));
  if (existing) leaf.append(document.createTextNode(delta.slice(0, existing)));
  delta = delta.slice(existing);
  if (!delta) return;
  if (
    !budget.remaining ||
    budget.groups >= 16 ||
    /^(?:\p{Mark}|\p{Emoji_Modifier}|\p{Regional_Indicator}|[\uDC00-\uDFFF\u200D\uFE0E\uFE0F])/u.test(delta)
  ) {
    leaf.append(document.createTextNode(delta));
    return;
  }
  // Cover the entire new delta, rather than making a large prefix appear instantly.
  // Large chunks fade as one unit; normal chunks use up to 16 grapheme-safe groups.
  const characters = delta.length <= 4096
    ? [...streamSegmenter.segment(delta)].map(part => part.segment) : [delta];
  const tailText = delta;
  const tail = el('span', undefined, 'stream-tail');
  const stride = Math.max(1, Math.ceil(characters.length / (16 - budget.groups)));
  for (let i = 0; i < characters.length; i += stride) {
    const part = el('span', characters.slice(i, i + stride).join(''), 'stream-char');
    budget.groups++;
    tail.append(part);
  }
  if (!tail.childNodes.length) return;
  const finish = () => {
    if (!leaf._streamFinishes?.has(finish)) return;
    const selection = getSelection();
    if (selection && !selection.isCollapsed && selection.containsNode(tail, true)) return;
    leaf._streamFinishes.delete(finish);
    tail.replaceWith(document.createTextNode(tailText));
    normalizeStreamLeaf(leaf);
  };
  (leaf._streamFinishes ||= new Set()).add(finish);
  tail.addEventListener('animationend', (event) => {
    if (event.target === tail.lastElementChild) finish();
  });
  tail.addEventListener('animationcancel', finish);
  leaf.append(tail);
}
function patchStreamMarkup(current, next, budget) {
  if(CodexMarkdown.updateElement(current,next))return;
  if (current.classList.contains('stream-text')) {
    const before = current.textContent,
      after = next.textContent;
    if (after === before) return;
    if (after.startsWith(before))
      appendStreamText(current, after.slice(before.length), budget, next._offset + before.length);
    else if (before !== after) { settleStreamLeaf(current); current.textContent = after; }
    return;
  }
  let cursor = current.firstElementChild;
  for (const child of [...next.children]) {
    const following = cursor?.nextElementSibling;
    if (cursor && cursor.tagName === child.tagName && (cursor.className === child.className || (cursor.classList.contains('stream-text') && child.classList.contains('stream-text'))))
      patchStreamMarkup(cursor, child, budget);
    else {
      for (const leaf of child.matches('.stream-text') ? [child] : child.querySelectorAll('.stream-text')) {
        const text = leaf.textContent;
        leaf.textContent = '';
        appendStreamText(leaf, text, budget, leaf._offset);
      }
      if (cursor) cursor.replaceWith(child);
      else current.append(child);
    }
    cursor = following;
  }
  while (cursor) {
    const following = cursor.nextElementSibling;
    cursor.remove();
    cursor = following;
  }
}
function updateLiveMessage(node, text) {
  if (node._text === text) return;
  const body = node.querySelector('.md'),
    next = streamMarkup(text),
    box = $('messages');
  const canAnimate =
    text.startsWith(node._text) &&
    next._streamText.startsWith(body._streamText) &&
    streamSegmenter &&
    !streamReducedMotion.matches &&
    !document.hidden &&
    getSelection()?.isCollapsed !== false &&
    box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  if (!canAnimate) for (const leaf of body.querySelectorAll('.stream-text')) settleStreamLeaf(leaf);
  const activeGroups = body.querySelectorAll('.stream-char').length;
  patchStreamMarkup(body, next, {
    remaining: canAnimate ? 1 : 0,
    groups: Math.max(0, activeGroups - 16),
    oldLength: body._streamText.length,
  });
  for (const leaf of body.querySelectorAll('.stream-end')) leaf.classList.remove('stream-end');
  const leaves = body.querySelectorAll('.stream-text');
  leaves[leaves.length - 1]?.classList.add('stream-end');
  body._streamText=next._streamText;
  node._text = text;
}
function settleStreamAnimations() {
  for (const leaf of $('messages').querySelectorAll('.stream-text')) settleStreamLeaf(leaf);
}
streamReducedMotion.addEventListener('change', () => {
  if (streamReducedMotion.matches) settleStreamAnimations();
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) settleStreamAnimations();
});
function reasoningMessage(text, live = false) {
  const node = el('details', undefined, 'message reasoning');
  const summary = el('summary', live ? '思考过程 · 正在生成' : '思考过程');
  const body = el('div', text, 'reasoning-body');
  node.append(summary, body);
  return node;
}
function assistantMessage(text, live) {
  const node = CodexPlugin.call('message.assistant', { text, live });
  if (!(node instanceof HTMLElement) || !node.querySelector('.md')) throw Error('Plugin assistant renderer must include .md');
  node._text = text;
  return node;
}
function assistantMessageBuiltin(text, live) {
  const node = el('div', undefined, 'message assistant' + (live ? ' live' : ''));
  node._text = text;
  node.append(live ? streamMarkup(text) : markdown(text));
  if (!live) addMessageCopy(node, text);
  return node;
}

function addMessageCopy(node, text) {
    const copy = el('button', '复制', 'copy');
    copy.type = 'button';
    copy.onclick = async () => {
      try {
        await navigator.clipboard.writeText(text);
        copy.textContent = '已复制';
      } catch {
        copy.textContent = '复制失败';
      }
      setTimeout(() => {
        copy.textContent = '复制';
      }, 1500);
    };
    node.append(copy);
}
function finalAssistantMessage(text, animate) {
  if (!animate) return assistantMessage(text, false);
  const draft = messageCache.get('draft')?.node;
  const node = draft && text.startsWith(draft._text) ? draft : assistantMessage('', true);
  updateLiveMessage(node, text);
  node.classList.remove('live');
  addMessageCopy(node, text);
  return node;
}

const messageCache = new Map();
const composerDrafts = new Map();
const executionGroups = new Map();
function loginRunning(snap) {
  return (
    snap.busy &&
    ((deviceLogin && !deviceLogin.finished && deviceLogin.generation === state.generation) ||
      (snap.events || []).some((event) => event.type === 'login.notice'))
  );
}
// Progress reflects observable protocol events, not inferred hidden reasoning.
function modelPhase(snap) {
  return snap.model_activity?.phase || (snap.reasoning_draft ? 'reasoning' : 'waiting');
}
function modelActivityLabel(snap) {
  const phase = modelPhase(snap),
    name = snap.model_activity?.name || '';
  if (phase === 'reasoning') return '思考中';
  if (phase === 'retrying') {
    const reason = snap.model_activity?.reason;
    return reason === 'overloaded'
      ? '服务繁忙，正在重连'
      : reason === 'rate_limited'
        ? '请求受限，等待重试'
        : '正在重连模型服务';
  }
  if (phase === 'quota') return '额度不足，等待恢复';
  if (phase === 'text') return '正在生成回复';
  if (phase === 'tool') {
    if (['write_file', 'apply_patch'].includes(name)) return '正在生成文件修改参数';
    if (name === 'shell') return '正在生成命令';
    if (name === 'read_file' || name === 'list_dir') return '正在准备读取文件';
    return '正在生成工具调用' + (name ? '：' + name : '');
  }
  return '等待模型响应';
}
function modelProgressNode(snap) {
  const node = el('div', undefined, 'message activity-progress');
  node.dataset.phase = modelPhase(snap);
  const cursor = el('span', undefined, 'activity-cursor');
  cursor.setAttribute('aria-hidden', 'true');
  const label = el('span', modelActivityLabel(snap));
  label.setAttribute('role', 'status');
  const elapsed = el('span', undefined, 'activity-elapsed');
  elapsed.setAttribute('aria-hidden', 'true');
  const started = Number(snap.model_activity?.started_at);
  node.dataset.startedAt = String(
    Number.isFinite(started) && started > 0 ? started : state.waitStarted || Date.now(),
  );
  if (snap.model_activity?.heartbeat_at)
    node.title = '已收到服务端保活；连接仍在，保活不能说明正在推理或排队。';
  if (modelPhase(snap) === 'tool')
    node.title = '模型仍在生成工具参数；完整验证并获得所需批准后才会执行。';
  node.append(cursor, label, elapsed);
  updateModelElapsed(node);
  return node;
}
function updateModelElapsed(node) {
  const seconds = Math.max(0, Math.floor((Date.now() - Number(node.dataset.startedAt)) / 1000));
  const value =
    seconds < 60 ? seconds + ' 秒' : Math.floor(seconds / 60) + ' 分 ' + (seconds % 60) + ' 秒';
  const counter = node.querySelector('.activity-elapsed');
  if (counter && counter.textContent !== value) counter.textContent = value;
}
setInterval(() => {
  if (!document.hidden)
    for (const node of document.querySelectorAll('.activity-progress')) updateModelElapsed(node);
}, 1000);

function buildChat(snap, wasBusy = false) {
  const used = new Set();
  const cached = (key, value, create) => {
    used.add(key);
    const signature = typeof value === 'string' ? value : JSON.stringify(value);
    let entry = messageCache.get(key);
    if (!entry || entry.signature !== signature) {
      entry = { signature, node: create() };
      messageCache.set(key, entry);
    }
    return entry.node;
  };
  const rows = snap.timeline || [];
  const pending = snap.pending;
  const creatorChecks = new Map(), creatorProbes = new Map();
  for (const [index, row] of rows.entries()) {
    if (row.name === 'plugin_build') {
      // Even an identical rebuild needs a fresh check/probe; a failed build
      // may have removed its previous artifact. Do not advertise old results.
      creatorChecks.clear(); creatorProbes.clear();
    }
    const data = creatorReport(row);
    if (data && row.name === 'plugin_check') creatorChecks.set(data.manifest, index);
    if (row.name === 'plugin_test' && row.output != null) {
      if (data) creatorProbes.set(data.manifest, data);
      else creatorProbes.clear(); // Never reuse a success after a failed/unreadable probe.
    }
  }
  const nodes = [];
  let matched = false;
  const toolEvents = toolEventMap(snap);
  const usedGroups = new Set();
  let group = [];
  const flushGroup = () => {
    if (!group.length) return;
    const key = group[0].key;
    usedGroups.add(key);
    let entry = executionGroups.get(key);
    if (!entry) {
      const node = el('details', undefined, 'execution');
      const summary = el('summary');
      const body = el('div', undefined, 'execution-tools');
      node.append(summary, body);
      entry = { node, summary, body };
      executionGroups.set(key, entry);
    }
    const tools = group.filter(item => item.row.k === 'tool');
    const thinking = group.filter(item => item.row.k === 'reasoning');
    const counts = new Map();
    for (const item of tools) counts.set(item.status, (counts.get(item.status) || 0) + 1);
    const summary =
      executionSummary(tools) + (thinking.length ? ' · ' + thinking.length + ' 段思考' : '') + ' · ' + [...counts].map(([status, count]) => count + ' ' + toolLabels[status]).join(' · ');
    if (entry.summary.textContent !== summary) {
      const visible = entry.summary.isConnected;
      entry.summary.textContent = summary;
      entry.transition?.cancel();
      if (visible && !streamReducedMotion.matches)
        entry.transition = entry.summary.animate([{opacity: .55}, {opacity: 1}], {duration: 140, easing: 'ease-out'});
    }
    entry.node.dataset.active = String(group.some(item => ['running', 'queued'].includes(item.status)));
    entry.node.dataset.attention = group.some((item) =>
      ['failed', 'denied', 'interrupted'].includes(item.status),
    )
      ? 'true'
      : 'false';
    reconcileChildren(
      entry.body,
      group.map((item) => item.node),
    );
    nodes.push(entry.node);
    group = [];
  };
  for (const [index, row] of rows.entries()) {
    const key = snap.session_id + ':' + row.k + ':' + (row.id || row.row_key || index);
    if(row.k==='preview'){
      flushGroup();nodes.push(cached(key,JSON.stringify(row.images),()=>{const box=el('details',undefined,'preview-result');box.append(el('summary','工具返回的图片'));for(const url of row.images||[]){if(typeof url!=='string'||!/^data:image\/(png|jpeg|webp|gif);base64,/.test(url))continue;const image=el('img');image.src=url;image.alt='工具返回的图片；渲染器限制请参阅工具结果';image.loading='lazy';box.append(image);}return box;}));
    } else if(row.k==='context'){
      flushGroup();nodes.push(cached(key,row.text,()=>{const box=el('details',undefined,'context-summary');box.append(el('summary','旧格式上下文摘要（内部记录）'),markdown(row.text));return box;}));
    } else if (row.k === 'reasoning') {
      const live = messageCache.get('reasoning-draft');
      if (!messageCache.has(key) && live && live.node.querySelector('.reasoning-body').textContent === row.text) {
        live.node.querySelector('summary').textContent = '思考过程';
        messageCache.set(key, { signature: row.text, node: live.node });
        messageCache.delete('reasoning-draft');
      }
      const node = cached(key, row.text, () => reasoningMessage(row.text));
      if (group.length) group.push({key, node, row});
      else nodes.push(node);
    } else if (row.k === 'user' || row.k === 'assistant') {
      flushGroup();
      nodes.push(
        cached(key, row.text, () =>
          row.k === 'user' ? userBubble(row.text) : finalAssistantMessage(row.text, wasBusy && !snap.busy && index === rows.length - 1),
        ),
      );
    } else if (row.k === 'tool') {
      const status = toolStatus(row, snap, toolEvents);
      const awaiting = status === 'approval';
      matched ||= awaiting;
      const node = cached(key, [row, status], () =>
        toolCard(
          row.id,
          row.name,
          row.args,
          row.output,
          awaiting,
          status,
          row.args_truncated || row.output_truncated,
        ),
      );
      if (awaiting) {
        flushGroup();
        nodes.push(node);
      } else group.push({ key, node, status, row });
      const report = creatorReport(row);
      if (report && row.name === 'plugin_check' && creatorChecks.get(report.manifest) === index) {
        flushGroup();
        const probe = creatorProbes.get(report.manifest);
        nodes.push(cached(key + ':creator', [report, probe], () => creatorReviewCard(report, probe)));
      }
    }
  }
  flushGroup();
  for (const key of executionGroups.keys()) if (!usedGroups.has(key)) executionGroups.delete(key);

  if (!rows.length)
    for (const [index, m] of (snap.messages || []).entries())
      nodes.push(
        cached('fallback:' + index, m, () =>
          m.role === 'user' ? userBubble(m.content) : assistantMessage(m.content, false),
        ),
      );
  // 用户消息写入会话日志之前先本地回显
  const lastSent = [...(snap.messages || [])].reverse().find((m) => m.role === 'user');
  const lastShown = [...rows].reverse().find((r) => r.k === 'user');
  if (
    rows.length &&
    snap.busy &&
    lastSent &&
    (!lastShown || !lastShown.text.includes(lastSent.content.trim()))
  )
    nodes.push(cached('sent', lastSent.content, () => userBubble(lastSent.content)));
  if (pending && !matched)
    nodes.push(
      cached('pending', pending, () =>
        toolCard(pending.tool_call_id || pending.call_id, pending.tool, pending.arguments, null, true),
      ),
    );
  if (snap.busy && snap.reasoning_draft && !rows.some(row => row.k === 'reasoning' && row.text === snap.reasoning_draft)) {
    used.add('reasoning-draft');
    let entry = messageCache.get('reasoning-draft');
    if (!entry) { entry = { node: reasoningMessage('', true) }; messageCache.set('reasoning-draft', entry); }
    const body = entry.node.querySelector('.reasoning-body');
    if (body.textContent !== snap.reasoning_draft) body.textContent = snap.reasoning_draft;
    nodes.push(entry.node);
  }
  if (snap.busy && snap.draft) {
    used.add('draft');
    let entry = messageCache.get('draft');
    if (!entry) {
      entry = { node: assistantMessage('', true) };
      messageCache.set('draft', entry);
    }
    updateLiveMessage(entry.node, snap.draft);
    nodes.push(entry.node);
  }
  if (loginRunning(snap))
    nodes.push(cached('login', true, () => el('div', '正在等待设备登录，请在登录窗口完成授权。', 'message')));
  else if (snap.busy && !pending && (!snap.draft || modelPhase(snap)!=='text') && !rows.some((r) => r.k === 'tool' && r.output === null))
    nodes.push(cached('activity', [modelActivityLabel(snap),snap.model_activity?.started_at,!!snap.model_activity?.heartbeat_at], () => modelProgressNode(snap)));
  for (const key of messageCache.keys()) if (!used.has(key)) messageCache.delete(key);
  return nodes;
}

// Reuse existing nodes, including focus and native <details> disclosure state.
function reconcileChildren(parent, nodes) {
  let cursor = parent.firstChild;
  for (const node of nodes) {
    if (node === cursor) cursor = cursor.nextSibling;
    else parent.insertBefore(node, cursor);
  }
  while (cursor) {
    const next = cursor.nextSibling;
    cursor.remove();
    cursor = next;
  }
}
function captureChatView() {
  const box = $('messages'),
    top = box.getBoundingClientRect().top;
  const anchor = [...box.querySelectorAll('.message, .execution > summary, .tool')].find(
    (node) => node.getClientRects().length && node.getBoundingClientRect().bottom > top,
  );
  const head = document.activeElement?.closest('.tool-h');
  return {
    nearBottom: box.scrollHeight - box.scrollTop - box.clientHeight < 120,
    scrollTop: box.scrollTop,
    anchor,
    offset: anchor?.getBoundingClientRect().top,
    focused: head,
    tool: head?.closest('.tool')?.dataset.toolId,
  };
}
function drawMessages(nodes, view = captureChatView()) {
  const box = $('messages');
  document.querySelector('.conversation').classList.toggle('is-empty', !nodes.length);
  reconcileChildren(box, nodes);
  if (!nodes.length) {
    const empty = $('empty-state').content.cloneNode(true);
    empty.querySelector('h2').textContent=state.user?.welcome||empty.querySelector('h2').textContent;
    for(const action of suggestions.cache?.actions||[])empty.querySelector('.sugg').append(suggestionButton(action));
    empty.querySelectorAll('[data-q]').forEach((button) => {
      button.onclick = () => {
        $('prompt').value = button.dataset.q;
        $('composer').requestSubmit();
      };
    });
    box.append(empty);
  }
  paintSuggestions();
  if (view.tool && !view.focused.isConnected) {
    const head = [...box.querySelectorAll('.tool')]
      .find((node) => node.dataset.toolId === view.tool)
      ?.querySelector('.tool-h');
    head?.focus({ preventScroll: true });
  }
  if (view.nearBottom) box.scrollTop = box.scrollHeight;
  else if (view.anchor?.isConnected) box.scrollTop += view.anchor.getBoundingClientRect().top - view.offset;
  else box.scrollTop = view.scrollTop;
  $('jump-bottom').hidden = view.nearBottom || !nodes.length;
}

/* ---------- 右侧面板 ---------- */
let diffTicket=0, filesTicket=0;

function showPanel(name) {
  state.panel = name;
  for (const tab of document.querySelectorAll('[data-panel]')) {
    tab.setAttribute('aria-pressed', String(tab.dataset.panel === name));
    $(tab.dataset.panel + '-panel').hidden = tab.dataset.panel !== name;
  }
  if (name === 'side') refreshSide().catch(e => sideError(e));
  if (name === 'changes') loadDiff().catch(e => notice(e.message));
}

for (const tab of document.querySelectorAll('[data-panel]')) tab.onclick = () => showPanel(tab.dataset.panel);
$('terminal-toggle').onclick = () => showInspector('terminal');

function showInspector(panel) {
  if ($('inspector-toggle').getAttribute('aria-pressed') !== 'true') $('inspector-toggle').click();
  showPanel(panel);
}

function renderTerminal(rows) {
  const signature=JSON.stringify(rows.filter(r=>r.k==='tool'&&r.name==='shell'));if($('term')._signature===signature)return;$('term')._signature=signature;
  const shells = rows.filter(r => r.k === 'tool' && r.name === 'shell').slice(-30);
  const box = $('term');
  if (!shells.length) { box.replaceChildren(el('span', '命令的输出会显示在这里', 'term-empty')); return; }
  const nodes = [];
  for (const r of shells) {
    const p = el('div', undefined, 'term-cmd');
    p.append(el('span', '$ ', 'pr'), document.createTextNode(toolSummary('shell', r.args)));
    nodes.push(p, el('pre', r.output === null ? '运行中…' : r.output, 'term-out'));
  }
  const stick = box.parentElement.scrollHeight - box.parentElement.scrollTop - box.parentElement.clientHeight < 80;
  box.replaceChildren(...nodes);
  if (stick) box.parentElement.scrollTop = box.parentElement.scrollHeight;
}

function renderPendingDiff(snap) {
  const host = $('pending-diff');
  const p = snap.pending;
  const signature=JSON.stringify(p);if(host._signature===signature)return;host._signature=signature;
  if (!p || p.tool !== 'apply_patch') { host.replaceChildren(); return; }
  const files = parsePatch(parseArgs(p.arguments).patch || '');
  if (!files.length) { host.replaceChildren(); return; }
  const block = el('div', undefined, 'dblock wait');
  const head = el('div', undefined, 'dblock-h');
  head.append(el('span', files.map(f => f.path).join(', '), 'path'), el('span', '待审批', 'tag'));
  const deny = el('button', '拒绝'), allow = el('button', '接受并应用', 'primary');
  deny.dataset.decide = allow.dataset.decide = '1';
  deny.type = allow.type = 'button';
  deny.onclick = () => decide(false);
  allow.onclick = () => decide(true);
  head.append(deny, allow);
  block.append(head, diffBlock(files, true));
  host.replaceChildren(block);
}

async function loadDiff() {
  const generation=state.generation, ticket=++diffTicket;
  let result;
  try { result = await rpc('diff'); }
  catch (e) {
    if(generation!==state.generation||ticket!==diffTicket)return;
    $('diff-stat').textContent = '';
    $('diff-view').replaceChildren(noneNode('无法显示变更', '需要在已有提交的 Git 仓库中查看工作区差异（' + e.message + '）'));
    return;
  }
  if(generation!==state.generation||ticket!==diffTicket)return;
  const files = parsePatch(result.diff || '');
  let add = 0, del = 0;
  for (const f of files) for (const l of f.lines) { if (l.t === 'add') add++; else if (l.t === 'del') del++; }
  $('diff-stat').textContent = add || del ? ` +${add} −${del}` : '';
  const nodes = files.map(f => { const b = el('div', undefined, 'dblock'); b.append(el('div', f.path, 'dblock-h path'), diffBlock([f], true)); return b; });
  if (result.untracked?.length) nodes.push(el('pre', '未跟踪文件：\n' + result.untracked.join('\n'), 'untracked'));
  if (result.truncated) nodes.push(el('p', '[内容已截断]'));
  $('diff-view').replaceChildren(...(nodes.length ? nodes : [noneNode('暂无变更', '工作区与 HEAD 没有差异')]));
}

function noneNode(title, text) {
  const n = el('div', undefined, 'none');
  n.append(el('b', title), document.createTextNode(text));
  return n;
}

/* ---------- 文件树 ---------- */

function buildTree(paths) {
  const root = {dirs: new Map(), files: []};
  for (const path of paths) {
    const parts = path.split('/');
    let node = root;
    for (const part of parts.slice(0, -1)) {
      if (!node.dirs.has(part)) node.dirs.set(part, {dirs: new Map(), files: []});
      node = node.dirs.get(part);
    }
    node.files.push({name: parts[parts.length - 1], path});
  }
  return root;
}

function renderTreeNode(node, host, prefix = '') {
  for (const [name, child] of [...node.dirs].sort((a, b) => a[0].localeCompare(b[0]))) {
    const dirPath = prefix + name;
    const open = state.expanded.has(dirPath);
    const row = el('button', undefined, 'row dir');
    row.type = 'button';
    row.dataset.path = dirPath;
    row.setAttribute('aria-expanded', String(open));
    row.append(el('span', open ? '▾' : '▸', 'ic'), el('span', name));
    const kids = el('div', undefined, 'kids');
    kids.hidden = !open;
    renderTreeNode(child, kids, dirPath + '/');
    row.onclick = () => {
      const hide = !kids.hidden;
      kids.hidden = hide;
      row.firstChild.textContent = hide ? '▸' : '▾';
      row.setAttribute('aria-expanded', String(!hide));
      if (hide) state.expanded.delete(dirPath);
      else state.expanded.add(dirPath);
    };
    host.append(row, kids);
  }
  for (const f of node.files.sort((a, b) => a.name.localeCompare(b.name))) {
    const row = el('button', undefined, 'row file' + (f.path === state.file ? ' on' : ''));
    row.type = 'button';
    if (f.path === state.file) row.setAttribute('aria-current', 'true');
    row.dataset.path = f.path;
    row.append(el('span', undefined, 'ic'), el('span', f.name));
    row.onclick = () => openFile(f.path).catch((e) => notice(e.message));
    host.append(row);
  }
}

function renderTree() {
  const host = $('tree');
  const focusedPath = host.contains(document.activeElement) ? document.activeElement.dataset.path : null;
  const scrollTop = host.scrollTop;
  host.replaceChildren();
  if (!state.fileList.length) {
    host.append(el('div', '工作区还没有文件', 'tree-empty'));
    return;
  }
  renderTreeNode(buildTree(state.fileList), host);
  if (focusedPath)
    [...host.querySelectorAll('[data-path]')]
      .find((node) => node.dataset.path === focusedPath)
      ?.focus({ preventScroll: true });
  host.scrollTop = scrollTop;
}

async function loadFiles() {
  const ticket=++filesTicket;const result=await rpc('files');if(ticket!==filesTicket)return;
  state.fileList = result.files;
  renderTree();
}

function expandTo(path) {
  let dir = '';
  for (const part of path.split('/').slice(0, -1)) {
    dir += part;
    state.expanded.add(dir);
    dir += '/';
  }
}

/* ---------- 编辑器 ---------- */

let paintTimer = 0;
function paintEditor() {
  const value = $('editor-text').value;
  const hl = $('editor-hl');
  hl.replaceChildren();
  if (value.length < 200000) {
    for (const part of highlight(value, editor.path)) hl.append(part.cls ? el('span', part.text, part.cls) : document.createTextNode(part.text));
  } else hl.append(document.createTextNode(value));
  hl.append(document.createTextNode('\n'));
  const lines = value.split('\n').length;
  if (lines !== editor.lines) {
    editor.lines = lines;
    $('editor-gutter').textContent = Array.from({length: lines}, (_, i) => i + 1).join('\n');
  }
  syncEditorScroll();
}

function syncEditorScroll() {
  const ta = $('editor-text');
  $('editor-hl').scrollTop = ta.scrollTop;
  $('editor-hl').scrollLeft = ta.scrollLeft;
  $('editor-gutter').scrollTop = ta.scrollTop;
}

function updateEditorState(message = '') {
  const label = $('editor-state');
  label.className = 'editor-state' + (editor.conflict ? ' conflict' : editor.dirty ? ' dirty' : '');
  label.textContent = message || (!editor.editable ? '二进制文件，只读' : editor.conflict ? '磁盘上的文件已变化' : editor.dirty ? '● 未保存' : '');
  $('editor-save').disabled = !editor.editable || !editor.dirty || editor.saving;
}

async function loadIntoEditor(path) {
  const ticket = ++editor.loadTicket,
    revision = editor.revision;
  let read;
  try {
    read = await rpc('read', { path });
  } catch (error) {
    if (ticket !== editor.loadTicket) return;
    throw error;
  }
  if (ticket !== editor.loadTicket || revision !== editor.revision) return;
  Object.assign(editor, {
    saving: false,
    path,
    version: read.version,
    editable: read.editable,
    crlf: read.text.includes('\r\n'),
    dirty: false,
    conflict: false,
  });
  state.file = path;
  const ta = $('editor-text');
  ta.value = read.text.replaceAll('\r\n', '\n');
  editor.baseline = ta.value;
  editor.revision++;
  ta.readOnly = !read.editable;
  ta.scrollTop = ta.scrollLeft = 0;
  $('editor-path').textContent = path;
  $('editor-path').title = path;
  $('file-view').hidden = true;
  $('editor').hidden = false;
  expandTo(path);
  renderTree();
  paintEditor();
  updateEditorState();
  showInspector('code');
}

async function openFile(path) {
  if (editor.dirty && editor.path === path) {
    showInspector('code');
    return;
  }
  if (editor.dirty && editor.path !== path) {
    return openDialog(
      '放弃未保存的修改？',
      [],
      () => () => loadIntoEditor(path).catch((e) => notice(e.message)),
      editor.path + ' 有未保存的修改，打开其他文件会丢弃它们。',
    );
  }
  await loadIntoEditor(path);
}

async function saveFile() {
  if (!editor.path || !editor.dirty || !editor.editable || editor.saving) return;
  const path = editor.path,
    generation = state.generation,
    revision = editor.revision,
    loadTicket = editor.loadTicket,
    value = $('editor-text').value;
  let text = value;
  if (editor.crlf) text = text.replaceAll('\n', '\r\n');
  editor.saving = true;
  updateEditorState();
  try {
    const result = await rpc('write', { path, text, base: editor.version });
    if (generation !== state.generation || editor.path !== path || loadTicket !== editor.loadTicket) return;
    editor.version = result.version;
    editor.baseline = value;
    editor.dirty = editor.revision !== revision && $('editor-text').value !== value;
    editor.conflict = false;
    notice('');
    editor.saving = false;
    updateEditorState(editor.dirty ? '● 未保存' : '已保存 ✓');
    setTimeout(() => {
      if (generation === state.generation && loadTicket === editor.loadTicket && !editor.dirty)
        updateEditorState();
    }, 1800);
    loadDiff().catch(() => {});
  } catch (e) {
    if (generation !== state.generation || editor.path !== path || loadTicket !== editor.loadTicket) return;
    editor.saving = false;
    if (/已变化|changed|conflict/i.test(e.message)) editor.conflict = true;
    notice(e.message);
    updateEditorState();
  }
}

// Agent 或外部程序改了磁盘上的文件：未编辑时静默更新，已编辑则提示冲突。
async function syncOpenFile() {
  if (!editor.path || editor.saving) return;
  const path=editor.path,ticket=editor.loadTicket,revision=editor.revision;
  let read;
  try { read = await rpc('read', {path}); } catch { return; }
  if(editor.path!==path||ticket!==editor.loadTicket||editor.saving)return;
  if (read.version === editor.version) return;
  if (editor.dirty||editor.revision!==revision) { editor.conflict = true; updateEditorState(); return; }
  const ta = $('editor-text');
  const top = ta.scrollTop, left = ta.scrollLeft;
  editor.version = read.version;
  editor.crlf = read.text.includes('\r\n');
  ta.value = read.text.replaceAll('\r\n', '\n');editor.baseline=ta.value;editor.revision++;
  ta.scrollTop = top; ta.scrollLeft = left;
  paintEditor();
  updateEditorState();
}

$('editor-text').addEventListener('input', () => {
  editor.revision++;editor.dirty = $('editor-text').value!==editor.baseline;
  updateEditorState();
  cancelAnimationFrame(paintTimer);
  paintTimer = requestAnimationFrame(paintEditor);
});
$('editor-text').addEventListener('scroll', syncEditorScroll);
$('editor-text').addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') { event.preventDefault(); saveFile(); return; }
  if (event.key === 'Tab' && !event.shiftKey && !event.isComposing && editor.editable) {
    event.preventDefault();
    const ta = event.target;
    ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end');
    ta.dispatchEvent(new Event('input'));
  }
});
onClick('editor-save', saveFile);
onClick('editor-reload', async () => {
  if (!editor.path) return;
  if (!editor.dirty) return loadIntoEditor(editor.path);
  openDialog('重新载入文件？', [], () => () => loadIntoEditor(editor.path).catch(e => notice(e.message)),
    '未保存的修改将被丢弃，并重新读取磁盘上的内容。');
});
window.addEventListener('beforeunload', event => {
  if (editor.dirty) { event.preventDefault(); event.returnValue = ''; }
});

onClick('refresh-files', loadFiles);
onClick('refresh-diff', loadDiff);

/* ---------- 轮询刷新 ---------- */

function setWorkspaceRoot(root) {
  const name = String(root || '').split(/[\\/]/).filter(Boolean).pop() || '';
  $('root-name').textContent = name;
  $('sidebar-root-name').textContent = name || '工作目录';
  $('sidebar-root-name').parentElement.title = String(root || '当前工作目录');
}

function renderSessions(sessions, busy) {
  const signature = JSON.stringify(sessions.map(s => [s.id, s.title, s.selected])) + busy;
  if ($('projects')._signature === signature) return;
  $('projects')._signature = signature;
  if (!sessions.length) { $('projects').replaceChildren(el('div', '暂无历史会话', 'tree-empty')); return; }
  $('projects').replaceChildren(...sessions.map(s => {
    const button = el('button', s.title || '空会话', s.selected ? 'selected' : '');
    button.title = s.title || '';
    if (s.selected) button.setAttribute('aria-current', 'true');
    button.disabled = busy && !s.selected;
    button.onclick = async () => {
      try { await changeSession(s.id); } catch (e) { notice(e.message); }
    };
    return button;
  }));
}

function setQueueState(text, busy) {
  if($('queue-state').textContent!==text)$('queue-state').textContent = text;
  $('queue-state').title = text;
  $('queue-state').dataset.busy = busy ? 'true' : 'false';
}

function setSendMode(busy) {
  const b = $('send');
  if (state.user?.mode === 'server') {
    b.textContent = '↑'; b.type = 'submit'; b.classList.remove('stop');
    b.setAttribute('aria-label', busy ? '加入任务队列' : '发送任务');
    b.title = '发送（Enter）；项目正在执行时加入队列';
    $('stop-task').hidden = !busy;
    return;
  }
  $('stop-task').hidden = true;
  b.textContent = busy ? '■' : '↑';
  b.classList.toggle('stop', busy);
  b.setAttribute('aria-label', busy ? '停止任务' : '发送任务');
  b.type = busy ? 'button' : 'submit';
}

async function refresh() {
  if ((state.user?.mode === 'server' && !state.project) || !state.user || state.polling || state.switching)
    return;
  state.polling = true;
  const generation = state.generation;
  try {
    const update = await rpc('snapshot', { since: state.snap?.revision || '' });
    if (generation !== state.generation) return;
    let snap = update;
    if (update.partial) {
      if (!state.snap || update.base_revision !== state.snap.revision) {
        if (state.snap) delete state.snap.revision;
        throw new Error('会话同步版本已变化，正在恢复完整状态');
      }
      const changes = { ...update.changes };
      if (changes.timeline_delta) {
        const patch = changes.timeline_delta;
        const rowsById = new Map((state.snap.timeline || []).map(row => [row.row_key, row]));
        for (const row of patch.rows || []) rowsById.set(row.row_key, row);
        if (!Array.isArray(patch.order) || patch.order.length > 400 ||
            new Set(patch.order).size !== patch.order.length || patch.order.some(id => !rowsById.has(id))) {
          delete state.snap.revision;
          throw new Error('历史记录版本已变化，正在恢复完整状态');
        }
        const rows = patch.order.map(id => rowsById.get(id));
        changes.timeline = rows.length === state.snap.timeline?.length &&
          rows.every((row, i) => row === state.snap.timeline[i]) ? state.snap.timeline : rows;
        delete changes.timeline_delta;
      }
      snap = { ...state.snap, ...changes, revision: update.revision };
    }
    if (state.user.mode === 'server') {
      const info = await rpc('project_status');
      if (generation !== state.generation) return;
      state.projectInfo = info;
      const queued = info.jobs.filter((j) => j.status === 'queued').length;
      $('host-jobs').textContent = info.blocked
        ? '项目需要检查后恢复'
        : queued
          ? `${queued} 个排队任务`
          : info.busy
            ? '项目处理中'
            : '无排队任务';
    }
    if (generation !== state.generation) return;
    const wasBusy = state.snap?.session_id === snap.session_id && state.snap?.busy;
    const previousSnap = state.snap;
    state.snap = snap;
    if(snap.busy&&!wasBusy)state.waitStarted=Date.now();
    const historyStatus = $('history-status');
    if (historyStatus) historyStatus.hidden = !snap.history_truncated;
    renderDeviceLogin(snap);
    const composerKey = JSON.stringify([state.project, state.scope, snap.session_id]);
    if (!state.composerKey) $('prompt').value = composerDrafts.get(composerKey) || $('prompt').value;
    state.composerKey = composerKey;
    const rows = snap.timeline || [];
    const signature = snap.revision || JSON.stringify([
      rows,
      snap.draft,
      snap.reasoning_draft,
      snap.model_activity,
      snap.busy,
      snap.pending,
      snap.messages,
      snap.session_id,
      (snap.events || []).filter(event => event.type === 'tool.started' || event.type === 'tool.completed'),
    ]);
    if (signature !== state.signature) {
      state.signature = signature;
      const view = captureChatView();
      drawMessages(buildChat(snap, wasBusy), view);
      if (previousSnap?.timeline !== rows) renderTerminal(rows);
      renderPendingDiff(snap);
    }
    // 工具完成数变化 → 刷新文件树与 Diff
    const finished =
      rows.filter(
        (r) => r.k === 'tool' && r.output !== null && r.name !== 'read_file' && r.name !== 'list_dir',
      ).length +
      ':' +
      snap.busy;
    if (finished !== state.toolSignature) {
      const first = state.toolSignature === '';
      state.toolSignature = finished;
      if (!first) {
        loadFiles().catch(() => {});
        loadDiff().catch(() => {});
        syncOpenFile();
      }
    }
    renderSessions(snap.sessions || [], snap.busy);
    state.provider = snap.provider || null;
    updateChips(snap);
    const current = (snap.sessions || []).find((s) => s.selected);
    $('project-title').textContent = current?.title || '新会话';
    const queued = state.projectInfo?.jobs?.some((j) => j.status === 'queued');
    const interrupted = state.projectInfo?.blocked;
    const toolEvents = toolEventMap(snap);
    const runningTool = rows.some(row => row.k === 'tool' && toolStatus(row, snap, toolEvents) === 'running');
    const waitingTool = rows.some(row => row.k === 'tool' && toolStatus(row, snap, toolEvents) === 'queued');
    setQueueState(
      interrupted
        ? '需要检查后恢复'
        : loginRunning(snap)
          ? '等待设备登录'
        : snap.pending
          ? '等待批准'
          : snap.busy
            ? runningTool
              ? '工具执行中'
              : waitingTool && !snap.draft ? '等待工具结果' : modelActivityLabel(snap)
            : queued
              ? '任务排队'
              : state.projectInfo?.busy
                ? '项目处理中'
                : snap.error ? (snap.error==='Task stopped'?'已停止':'任务失败') : '就绪',
      snap.busy,
    );
    setSendMode(snap.busy);
    if (snap.error) {
      notice(snap.error);
      state.snapNotice = true;
    } else if (state.snapNotice) {
      notice('');
      state.snapNotice = false;
    }
    if (state.connectionError && $('notice').textContent === state.connectionError) notice('');
    state.connectionError = '';
    if(state.panel==='side' && $('inspector-toggle').getAttribute('aria-pressed')==='true') refreshSide().catch(sideError);
    setConnection(teamProtocol().readOnly ? '已连接（兼容只读）' : '已连接', true);
    if(!preferences.loaded&&state.user?.protocol?.capabilities?.includes('suggestions.v1')){await loadPreferences();await updateSuggestions();}
  } catch (e) {
    if (generation !== state.generation) return;
    if (deviceLogin && !deviceLogin.finished && deviceLogin.generation === state.generation) $('device-login-status').textContent = '连接中断，正在尝试恢复登录状态…';
    state.connectionError = e.message;
    const status=e.network?'正在重连':'状态获取失败';
    setConnection(status, false);
    setQueueState(status, false);
    notice(e.message);
  } finally {
    state.polling = false;
    if (generation !== state.generation && !state.switching) refresh();
  }
}

/* ---------- 任务提交（沿用请求 ID 以安全重试） ---------- */

function pendingSubmission() {
  try { return JSON.parse(sessionStorage.getItem('codex.pending') || 'null'); } catch { return null; }
}

async function submitTask(event) {
  event.preventDefault();
  if (state.submitting) return;
  if (state.snap?.busy && state.user?.mode !== 'server') return;
  const text = $('prompt').value;
  if (!text.trim()) return;
  if (tryCommand(text)) return;
  const design = state.designNext || {mode: !!state.design, plan: false};
  const previous = pendingSubmission();
  const pending =
    previous &&
    previous.text === text &&
    !!previous.design_mode === design.mode && !!previous.design_plan === design.plan &&
    previous.project === state.project &&
    previous.scope === state.scope &&
    previous.user === state.user.username
      ? previous
      : { text, design_mode: design.mode, design_plan: design.plan, project: state.project, scope: state.scope, user: state.user.username, request_id: newId() };
  sessionStorage.setItem('codex.pending', JSON.stringify(pending));
  const generation = state.generation;
  state.submitting = true;
  $('send').disabled = true;
  try {
    await rpc('send', { text, request_id: pending.request_id, ...(pending.design_mode ? {design_mode: true, design_plan: !!pending.design_plan} : {}) });
    sessionStorage.removeItem('codex.pending');
    if (generation !== state.generation) return;
    if ($('prompt').value === text) $('prompt').value = '';
    state.designNext = null; updateDesignMode();
    notice('');
    await refresh();
  } catch (e) {
    if (generation !== state.generation) return;
    notice(e.message + '。保留相同内容再次发送可使用原请求 ID 安全重试。');
  } finally {
    state.submitting = false;
    $('send').disabled = false;
  }
}

$('composer').onsubmit = submitTask;
$('send').addEventListener('click', async event => {
  if (!state.snap?.busy || state.user?.mode === 'server') return;
  event.preventDefault();
  try { await rpc('stop'); await refresh(); } catch (e) { notice(e.message); }
});
onClick('stop-task', async () => { await rpc('stop'); await refresh(); });
$('prompt').addEventListener('keydown', event => {
  if (event.isComposing || event.keyCode === 229) return;
  if (menu.items.length) {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      menu.index = (menu.index + (event.key === 'ArrowDown' ? 1 : menu.items.length - 1)) % menu.items.length;
      drawMenu();
      return;
    }
    if (event.key === 'Tab' || (event.key === 'Enter' && !event.shiftKey)) {
      event.preventDefault();
      chooseCommand(menu.items[menu.index]);
      return;
    }
    if (event.key === 'Escape') { event.preventDefault(); closeMenu(); return; }
  }
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    $('composer').requestSubmit();
  }
});

/* ---------- 模型与权限 ---------- */

const PERMISSION_LABELS = {readonly: '只读', workspace: '默认权限', full: '完全访问'};
const PERMISSION_CHOICES = [
  ['readonly', '只读', '只能查看，不能修改文件'],
  ['workspace', '默认权限', '可写工作区，敏感操作需批准'],
  ['full', '完全访问', '无沙箱，不再请求批准'],
];

const EFFORT_LABELS = {'': '默认', none: '无', minimal: '极低', low: '低', medium: '中', high: '高', xhigh: '超高', max: '最大', ultra: 'Ultra'};
const DEFAULT_EFFORTS = ['', 'low', 'medium', 'high', 'xhigh'];
const effortLabel = value => EFFORT_LABELS[value] || value;
const catalog = {models: null, error: '', loading: false};

function updateChips(snap) {
  state.model = snap.model || '';
  state.reasoning = snap.reasoning || '';
  state.permission = snap.permission || 'workspace';
  $('model-chip').textContent = (state.model ? modelLabel(state.model) + (state.reasoning ? ' ' + effortTitle(state.reasoning) : '') : '默认模型') + ' ⌄';
  $('model-chip').title = '提供商：' + (snap.provider?.name || 'Codex');
  $('permission-chip').textContent = PERMISSION_LABELS[state.permission];
  $('permission-chip').dataset.level = state.permission;
  for (const id of ['model-chip', 'permission-chip']) $(id).disabled = snap.busy;
  if (snap.busy) closePopover();
}

const pop = {kind: null};

function closePopover() {
  pop.kind = null;
  $('popover').hidden = true;
  $('model-chip').setAttribute('aria-expanded', 'false');
  $('permission-chip').setAttribute('aria-expanded', 'false');
}

function popItem(title, desc, checked, onPick) {
  const item = el('button', undefined, 'pop-item');
  item.type = 'button';
  item.setAttribute('role', 'menuitemradio');
  item.setAttribute('aria-checked', String(checked));
  const text = el('span', undefined, 'pop-text');
  text.append(el('span', title, 'pop-title'));
  if (desc) text.append(el('span', desc, 'pop-desc'));
  item.append(text, el('span', checked ? '✓' : '', 'pop-check'));
  item.onclick = async () => {
    try { await onPick(); } catch (e) { notice(e.message); }
  };
  return item;
}

function modelLabel(id) {
  if (!id) return '默认';
  return /^gpt-/i.test(id) ? id.replace(/^gpt-/i, 'GPT-').replace(/-(sol|astra|terra|luna)$/i, (_, name) => ' ' + name[0].toUpperCase() + name.slice(1)) : id;
}
const effortTitle = value => ({'': '默认', none: '无', minimal: '极低', low: '轻', medium: '标准', high: '高', xhigh: '超高', max: '最大', ultra: 'Ultra'}[value] || value);
function currentModelInfo() { return (catalog.models || []).find(model => model.id === state.model); }
function drawEffortPopover() {
  const box = $('popover');
  box.dataset.view = 'effort'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', '推理强度'); box.replaceChildren();
  const info = currentModelInfo();
  const levels = [...new Set((info?.efforts || []).filter(level => typeof level === 'string' && level))];
  const current = state.reasoning || info?.default_effort || '';
  const head = el('div', undefined, 'effort-header');
  const choice = el('button', undefined, 'effort-choice'); choice.type = 'button'; choice.setAttribute('aria-label', '选择模型');
  const title = el('span', effortTitle(current), 'effort-title');
  choice.append(title, el('span', modelLabel(state.model) + ' ›', 'effort-model'));
  choice.onclick = () => { pop.view = 'catalog'; drawModelPopover(); $('popover').querySelector('.model-back').focus(); };
  head.append(choice); box.append(head);
  if (levels.length) {
    const track = el('div', undefined, 'effort-track');
    const input = el('input'); input.type = 'range'; input.min = '0'; input.max = String(levels.length - 1); input.step = '1'; input.value = String(Math.max(0, levels.indexOf(current))); input.disabled = levels.length < 2;
    input.setAttribute('aria-label', '推理强度'); input.setAttribute('aria-valuetext', effortTitle(current || levels[0]));
    const dots = el('div', undefined, 'effort-dots');
    levels.forEach(level => { const dot = el('span'); dot.title = effortTitle(level); dots.append(dot); });
    input.oninput = () => { title.textContent = effortTitle(levels[Number(input.value)]); input.setAttribute('aria-valuetext', title.textContent); };
    input.onchange = async () => { try { await rpc('reasoning', {effort: levels[Number(input.value)]}); await refresh(); drawModelPopover(); $('popover').querySelector('input[type=range]')?.focus(); } catch (error) { notice(error.message); drawModelPopover(); } };
    track.append(dots, input); box.append(track);
  } else {
    box.append(el('div', catalog.loading ? '正在获取模型能力…' : '提供商未声明推理强度，可手动指定。', 'pop-note-plain'));
    if (!catalog.loading) {
      const select = el('select'); select.setAttribute('aria-label', '手动指定推理强度');
      ['', ...new Set([...DEFAULT_EFFORTS.filter(Boolean), ...(state.reasoning ? [state.reasoning] : [])])].forEach(value => select.append(new Option(effortTitle(value), value)));
      select.value = state.reasoning || ''; select.onchange = async () => { try { await rpc('reasoning', {effort: select.value}); await refresh(); drawModelPopover(); } catch (error) { notice(error.message); } };
      box.append(select);
    }
  }
  if (catalog.error) box.append(el('div', '无法获取模型列表：' + catalog.error, 'pop-note-plain'));
}
function drawModelPopover() {
  const box = $('popover');
  if (pop.kind !== 'model') return;
  $('model-chip').setAttribute('aria-expanded', 'true');
  if (pop.view !== 'catalog') return drawEffortPopover();
  const typed = box.querySelector('.pop-custom input')?.value || '';
  box.dataset.view = 'catalog'; box.setAttribute('role', 'menu'); box.setAttribute('aria-label', '选择模型'); box.replaceChildren();
  const back = el('button', '‹ 选择模型', 'model-back'); back.type = 'button'; back.setAttribute('aria-label', '返回推理强度'); back.onclick = () => { pop.view = 'effort'; drawModelPopover(); box.querySelector('.effort-choice').focus(); }; box.append(back);
  const pick = value => async () => { await rpc('model', {model: value}); await refresh(); pop.view = 'effort'; drawModelPopover(); box.querySelector('.effort-choice').focus(); };
  box.append(popItem('默认', '使用提供商默认模型', !state.model, pick('')));
  const fetched = catalog.models || [];
  const own = (state.provider?.models || []).filter(id => !fetched.some(m => m.id === id)).map(id => ({id, description: '自定义模型'}));
  const known = [...own, ...fetched];
  const list = state.model && !known.some(model => model.id === state.model) ? [...known, {id: state.model, description: ''}] : known;
  for (const model of list) box.append(popItem(modelLabel(model.id), model.description, model.id === state.model, pick(model.id)));
  if (catalog.loading) box.append(el('div', '正在加载模型列表…', 'pop-note-plain'));
  else if (catalog.error && !own.length) box.append(el('div', '无法获取模型列表：' + catalog.error + '。可在“提供商”里手动添加模型，或在下方输入模型名。', 'pop-note-plain'));
  const refreshButton = el('button', '刷新模型列表', 'model-refresh'); refreshButton.type = 'button'; refreshButton.disabled = catalog.loading; refreshButton.onclick = () => loadCatalog(true); box.append(refreshButton);
  const custom = el('form', undefined, 'pop-custom'); const input = el('input'); input.placeholder = '自定义模型名'; input.setAttribute('aria-label', '自定义模型名'); input.pattern = '[A-Za-z0-9._:/\\-]+'; input.maxLength = 200; input.value = typed;
  const apply = el('button', '应用'); apply.type = 'submit'; custom.append(input, apply);
  custom.onsubmit = async event => { event.preventDefault(); if (!input.value.trim()) return; try { await pick(input.value.trim())(); } catch (error) { notice(error.message); } };
  box.append(custom);
}

async function loadCatalog(force = false) {
  if (catalog.loading || (!force && catalog.models)) return;
  const generation=state.generation;catalog.loading = true;
  drawModelPopover();
  try {
    const result = await rpc('models', {refresh: force});
    if(generation!==state.generation)return;
    catalog.models = result.models.length ? result.models : null;
    catalog.error = result.error || '';
  } catch (e) {
    if(generation!==state.generation)return;catalog.error = e.message;
  } finally {
    if(generation===state.generation){catalog.loading = false;if(pop.kind==='model')drawModelPopover();}
  }
}

function openPopover(kind) {
  if (pop.kind === kind) return closePopover();
  pop.kind = kind;
  pop.view = 'effort';
  const box = $('popover');
  box.replaceChildren();
  if (kind === 'model') {
    drawModelPopover();
    loadCatalog();
  } else {
    box.dataset.view = 'permissions'; box.setAttribute('role', 'menu'); box.setAttribute('aria-label', '执行权限');
    box.append(el('div', '执行权限', 'pop-heading'));
    for (const [mode, title, desc] of PERMISSION_CHOICES) {
      if (mode === 'full' && state.user?.mode === 'server') continue;
      box.append(popItem(title, desc, mode === state.permission, async () => { closePopover(); await openPermissions(mode); }));
    }
    $('permission-chip').setAttribute('aria-expanded', 'true');
  }
  box.hidden = false;
  if (kind === 'model') box.querySelector('.effort-choice')?.focus();
}

function openModel(value) {
  if (value !== undefined) return rpc('model', {model: value}).then(refresh);
  openPopover('model');
}

async function openPermissions(choice) {
  if (!choice) return openPopover('permission');
  if (choice === state.permission) return;
  if (choice !== 'full') { await rpc('permission', {permission: choice}); return refresh(); }
  openDialog('确认完全访问', [], () => rpc('permission', {permission: 'full'}),
    '完全访问会关闭沙箱，Agent 可在本机读写任意文件并运行任意命令，且不再请求批准。\n仅在信任当前任务时开启；重启服务后自动恢复默认权限。');
}

$('model-chip').onclick = () => openModel();
$('permission-chip').onclick = () => openPermissions();
document.addEventListener('mousedown', event => {
  if (pop.kind && !event.target.closest('#popover, .chip')) closePopover();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && pop.kind) { event.preventDefault(); closePopover(); $('prompt').focus(); }
});

/* ---------- 斜杠命令 ---------- */

async function copyLast() {
  const last = [...$('messages').querySelectorAll('.message.assistant')].pop();
  if (!last) throw new Error('还没有可复制的回复');
  await navigator.clipboard.writeText(last._text);
  notice('已复制上一条回复');
}

function statusText() {
  return [
    `工作区：${$('root-name').textContent || '-'}`,
    `模型：${state.model || '默认'}${state.reasoning ? ' · ' + effortTitle(state.reasoning) : ''}`,
    `权限：${PERMISSION_LABELS[state.permission] || '-'}`,
    `状态：${$('queue-state').textContent || '-'}`,
  ].join('\n');
}

const COMMANDS = [
  {name: '/model', desc: '切换模型（/model 名称）', takesArg: true, run: arg => openModel(arg || undefined)},
  {name: '/permissions', desc: '调整执行权限（readonly / default / full）', takesArg: true, run: arg => {
    const alias = {readonly: 'readonly', 'read-only': 'readonly', default: 'workspace', workspace: 'workspace', full: 'full'};
    if (arg && !alias[arg]) throw new Error('可选：readonly、default、full');
    openPermissions(alias[arg]);
  }},
  {name: '/design', desc: '设计模式（on / off / plan 任务）', run: designCommand},
  {name: '/new', desc: '开始新会话', run: newChat},
  {name: '/sessions', desc: '切换本地会话', run: openSessions},
  {name: '/provider', desc: '模型提供商与密钥', run: () => openSettings()},
  {name: '/login', desc: 'ChatGPT 设备登录', run: startDeviceLogin},
  {name: '/status', desc: '显示当前配置', run: () => openDialog('当前状态', [], () => {}, statusText())},
  {name: '/diff', desc: '查看当前修改', run: () => showInspector('changes')},
  {name: '/files', desc: '查看代码面板', run: () => showInspector('code')},
  {name: '/copy', desc: '复制上一条回复', run: copyLast},
  {name: '/help', desc: '列出所有命令', run: () => openDialog('斜杠命令', [], () => {},
    COMMANDS.map(c => `${c.name.padEnd(14)}${c.desc}`).join('\n'))},
];

const TERMINAL_ONLY = ['/plan', '/review', '/compact', '/init', '/resume', '/fork', '/rename',
  '/undo', '/memory', '/skills', '/plugins', '/mcp', '/image', '/mention', '/goal', '/personality',
  '/continue', '/archive', '/delete', '/clear', '/logout', '/auth', '/quit'];

function updateDesignMode() {
  $('design-mode').hidden = !state.design && !state.designNext;
  $('design-label').textContent = state.designNext?.plan ? 'Design · 只读方案' : 'Design · 界面设计';
}
function designCommand(arg = '') {
  if (!state.user?.protocol?.capabilities?.includes('design.v1')) throw Error('当前服务不支持 Design，请更新服务端。');
  if (arg === 'off') { state.design = false; state.designNext = null; }
  else if (!arg || arg === 'on') state.design = true;
  else {
    const plan = arg === 'plan' || arg.startsWith('plan ');
    const task = plan ? arg.slice(4).trim() : arg;
    if (!task) throw Error('用法：/design plan 任务');
    state.designNext = {mode: true, plan};
    $('prompt').value = plan ? '先提出设计方案，不修改文件：' + task : task;
    updateDesignMode();
    const generation=state.generation, text=$('prompt').value;
    setTimeout(()=>{if(generation===state.generation && $('prompt').value===text)$('composer').requestSubmit();},0);
    return;
  }
  updateDesignMode(); $('prompt').focus();
}
$('design-exit').onclick = () => designCommand('off');
const menu = {items: [], index: 0, kind: 'slash'};
let mentionTicket = 0;
function mentionQuery() {
  const input=$('prompt'), end=input.selectionStart ?? input.value.length;
  const match=/(?:^|\s)@([a-z0-9._-]*)$/i.exec(input.value.slice(0,end));
  return match ? {query:match[1],start:end-match[1].length-1,end} : null;
}
async function updateComposerMenu() {
  const ticket=++mentionTicket, generation=state.generation, mention=mentionQuery();
  menu.kind=mention ? 'plugin' : 'slash'; menu.index=0;
  if (!mention) { menu.items=menuMatches($('prompt').value);drawMenu();return; }
  menu.items=[];drawMenu();
  try {
    const result=await rpc('plugin_catalog');
    if(ticket!==mentionTicket || generation!==state.generation || document.activeElement!==$('prompt'))return;
    const current=mentionQuery();if(!current || current.start!==mention.start || current.query!==mention.query)return;
    menu.items=(result.plugins || []).filter(p=>/^[a-z0-9][a-z0-9._-]{0,127}$/.test(p.id) && p.id.toLowerCase().includes(mention.query.toLowerCase()))
      .map(p=>({name:'@'+p.id,desc:p.description || '使用此插件',plugin:p.id,mention}));
    if(!menu.items.length)menu.items=[{name:'没有匹配的可用插件',desc:'仅列出已启用或已加载的插件',unavailable:true}];
    drawMenu();
  } catch(error) { if(ticket===mentionTicket)notice(error.message); }
}


function menuMatches(value) {
  if (!value.startsWith('/') || /\s/.test(value)) return [];
  return COMMANDS.filter(c => c.name.startsWith(value.toLowerCase()));
}

function closeMenu() {
  mentionTicket++; menu.items = [];
  $('slash-menu').hidden = true;
  $('prompt').removeAttribute('aria-activedescendant');
  $('prompt').setAttribute('aria-expanded','false');
}

function drawMenu() {
  const box = $('slash-menu');
  const offset=box.scrollTop;
  box.hidden = !menu.items.length;
  box.setAttribute('aria-label',menu.kind==='plugin'?'选择插件':'斜杠命令');
  $('prompt').setAttribute('aria-expanded',String(!!menu.items.length));
  box.replaceChildren(...menu.items.map((c, i) => {
    const row = el('button', undefined, 'slash-item');
    row.type = 'button';
    row.id = 'composer-option-' + i;
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', String(i === menu.index));
    row.append(el('span', c.name, 'slash-name'), el('span', c.desc, 'slash-desc'));
    row.onmousedown = event => { event.preventDefault(); chooseCommand(c); };
    return row;
  }));
  box.scrollTop=offset;
  const selected=box.children[menu.index];
  if(selected){$('prompt').setAttribute('aria-activedescendant',selected.id);selected.scrollIntoView({block:'nearest'});}
  else $('prompt').removeAttribute('aria-activedescendant');
}

function chooseCommand(command) {
  closeMenu();
  if(command.unavailable){$('prompt').focus();return;}
  if(command.plugin){
    const input=$('prompt'), {start,end}=command.mention;
    input.setRangeText(command.name+' ',start,end,'end');input.focus();return;
  }
  if (command.takesArg) {
    $('prompt').value = command.name + ' ';
    $('prompt').focus();
    return;
  }
  $('prompt').value = '';
  executeCommand(command, '');
}

async function executeCommand(command, arg) {
  try { await command.run(arg); } catch (e) { notice(e.message); }
}

// 返回 true 表示输入已作为命令处理，不应发送给 Agent。
function tryCommand(text) {
  const match = /^(\/[A-Za-z-]+)(?:\s+([\s\S]*))?$/.exec(text.trim());
  if (!match) return false;
  const name = match[1].toLowerCase();
  const command = COMMANDS.find(c => c.name === name);
  if (command) {
    $('prompt').value = '';
    closeMenu();
    executeCommand(command, (match[2] || '').trim());
    return true;
  }
  if (TERMINAL_ONLY.includes(name)) {
    notice(`${name} 目前只能在终端界面使用；输入 /help 查看网页支持的命令。`);
    return true;
  }
  return false;
}

$('prompt').addEventListener('input', updateComposerMenu);
$('prompt').addEventListener('click', updateComposerMenu);
$('prompt').addEventListener('blur', closeMenu);

/* ---------- 设备登录（独立认证进程，不调用模型） ---------- */
let deviceLogin = null;
async function startDeviceLogin() {
  if (deviceLogin && deviceLogin.generation === state.generation && !deviceLogin.finished) {
    if (!$('device-login-dialog').open) $('device-login-dialog').showModal();
    return;
  }
  const login = deviceLogin = {generation: state.generation, starting: true, finished: false};
  $('device-login-code').value = '';
  $('device-login-copy').disabled = true;
  $('device-login-stop').disabled = true;
  $('device-login-status').textContent = '正在获取设备码…';
  $('device-login-details').textContent = '';
  $('device-login-details').hidden = true;
  if ($('dialog').open) $('dialog').close();
  $('device-login-dialog').showModal();
  try {
    await rpc('login', {request_id: newId()});
    if (deviceLogin !== login || login.generation !== state.generation) return;
    login.starting = false;
    $('device-login-stop').disabled = false;
    await refresh();
  } catch (error) {
    if (deviceLogin !== login || login.generation !== state.generation) return;
    login.finished = true;
    $('device-login-status').textContent = '无法发起登录：' + error.message;
    $('device-login-stop').disabled = true;
  }
}
function renderDeviceLogin(snap) {
  if (!deviceLogin || deviceLogin.generation !== state.generation || deviceLogin.starting || deviceLogin.finished) return;
  const lines = (snap.events || []).filter(e => e.type === 'login.notice').map(e => e.payload?.text || '');
  const text = lines.join('\n');
  const code = text.match(/and enter:\s*([^\s]+)/)?.[1];
  if (code) {
    $('device-login-code').value = code;
    $('device-login-copy').disabled = false;
    $('device-login-status').textContent = '打开上面的地址并输入设备码，正在等待你完成授权…';
  }
  if (/^Signed in\.$/m.test(text) || (!snap.busy && (lines.length || snap.error))) {
    deviceLogin.finished = true;
    const success = /^Signed in\.$/m.test(text);
    $('device-login-status').textContent = success ? '登录成功，可以关闭此窗口并使用 Codex。' : '登录未完成：' + (snap.error || '请重新发起登录');
    $('device-login-stop').disabled = true;
    $('device-login-copy').disabled = true;
    if (!success) {
      $('device-login-details').textContent = text;
      $('device-login-details').hidden = !text;
    }
  }
}
onClick('device-login-close', () => $('device-login-dialog').close());
onClick('device-login-copy', async () => {
  try { await navigator.clipboard.writeText($('device-login-code').value); }
  catch { $('device-login-code').focus(); $('device-login-code').select(); }
});
onClick('device-login-stop', async () => {
  if (!deviceLogin || deviceLogin.finished || deviceLogin.generation !== state.generation) return;
  $('device-login-stop').disabled = true;
  try { await rpc('stop'); await refresh(); }
  catch (error) { $('device-login-status').textContent = error.message; $('device-login-stop').disabled = false; }
});

/* ---------- 设置与会话 ---------- */

function providerForm(p) {
  openDialog(p ? '编辑提供商' : '添加提供商', [
    field('name', '名称', 'text', p?.name || ''),
    field('base_url', '服务地址（如 https://api.example.com/v1）', 'text', p?.base_url || ''),
    field('api', 'API 类型', 'select', p?.api || 'chat', ['chat', 'responses']),
    field('models', '模型（多个用逗号分隔，第一个为默认；可留空）', 'text', (p?.models || []).join(', '), [], false),
    field('key', p?.has_key ? 'API 密钥（留空保持不变）' : 'API 密钥（本地服务可留空）', 'password'),
  ], async data => {
    await rpc('provider_save', {id: p?.id, ...data});
    catalog.models = null; catalog.error = '';
    return () => openProviders().catch(e => notice(e.message));
  });
}

async function fillProviders() {
  const generation=state.generation,ticket=settingsTicket,inside=$('workspace-settings').open&&settingsTab==='providers';
  const data = await rpc('providers');
  if(generation!==state.generation||(inside&&(ticket!==settingsTicket||!$('workspace-settings').open)))return;
  const editable=state.user.mode!=='server'||state.scope==='personal'||state.projectInfo?.owner===state.user.username;
  const list = el('div', undefined, 'prov-list');
  const act = (label, fn, cls) => {
    const b = el('button', label, cls); b.type = 'button';
    b.onclick = async () => { b.disabled=true;try { await fn(); if (fn !== startDeviceLogin&&settingsTab==='providers'&&$('workspace-settings').open) await fillProviders(); await refresh(); } catch (e) { $(settingsTab==='providers'?'provider-error':'dialog-error').textContent = e.message; }finally{if(b.isConnected)b.disabled=false;} };
    return b;
  };
  for (const p of data.providers) {
    const row = el('div', undefined, 'prov' + (p.id === data.active ? ' on' : ''));
    const info = el('div', undefined, 'prov-info');
    const sub = p.id === 'codex' ? '内置 · 使用 ChatGPT / Codex 订阅登录'
      : p.builtin ? '由启动参数指定'
      : `${p.base_url} · ${p.api} · ${p.models.length ? p.models.length + ' 个模型' : '未设置模型'}${p.has_key ? ' · 已保存密钥' : ''}`;
    info.append(el('b', p.name), el('span', sub, 'prov-sub'));
    const actions = el('div', undefined, 'prov-actions');
    if (p.id === data.active) actions.append(el('span', '使用中', 'prov-badge'));
    else if (p.id !== 'cli') actions.append(act('使用', async () => {
      await rpc('provider_use', {id: p.id}); catalog.models = null; catalog.error = '';
    }, 'primary'));
    if (p.id === 'codex' && editable) actions.append(act('设备登录', startDeviceLogin));
    if (!p.builtin && editable) {
      const edit = el('button', '编辑'); edit.type = 'button';
      edit.onclick = () => { $('dialog').close(); providerForm(p); };
      actions.append(edit, act('删除', async () => { await rpc('provider_delete', {id: p.id}); catalog.models = null; catalog.error = ''; }));
    }
    row.append(info, actions);
    list.append(row);
  }
  const add = el('button', '＋ 添加提供商', 'prov-add'); add.type = 'button';
  add.onclick = () => { $('dialog').close(); providerForm(null); };
  if(editable) list.append(add);
  list.append(el('p', '只内置 Codex；其他兼容服务可手动添加。密钥只写入当前会话所属的私有凭据目录，不提供读取接口。', 'prov-note'));
  if($('workspace-settings').open&&settingsTab==='providers')$('settings-providers').replaceChildren(list);
  else showDialog('模型提供商', list);
}

async function openProviders() { return showSettings('providers'); }
function openSettings() { return showSettings('providers'); }

const settingsNarrow = matchMedia('(max-width:600px)');
function settingsOrientation() {
  document
    .querySelector('.settings-nav')
    ?.setAttribute('aria-orientation', settingsNarrow.matches ? 'horizontal' : 'vertical');
}
let settingsTab = 'general',
  settingsTicket = 0;
settingsNarrow.addEventListener('change', settingsOrientation);
settingsOrientation();
function selectSettings(tab, focus = false) {
  settingsTab = tab;
  settingsTicket++;
  if (tab !== 'team') closeTeam();
  if (tab !== 'plugins' && $('plugin-dialog').open) $('plugin-dialog').close();
  for (const button of document.querySelectorAll('[data-settings]')) {
    const active = button.dataset.settings === tab;
    button.setAttribute('aria-selected', String(active));
    button.tabIndex = active ? 0 : -1;
    $(button.getAttribute('aria-controls')).hidden = !active;
    if (active && focus) button.focus();
  }
  $('preference-status').textContent = '';
}
async function showSettings(tab = 'general', focus = false) {
  if (!$('workspace-settings').open) $('workspace-settings').showModal();
  selectSettings(tab, focus);
  const ticket = settingsTicket;
  try {
    await loadPreferences();
    if (ticket !== settingsTicket || !$('workspace-settings').open) return;
    if (tab === 'providers') await fillProviders();
    if (tab === 'team') await openTeam();
    if (tab === 'plugins') await openPluginSettings(ticket);
    if (focus && ticket === settingsTicket && $('workspace-settings').open)
      document.querySelector('[data-settings="' + tab + '"]').focus();
    if (tab === 'about')
      $('settings-location').textContent =
        state.user?.mode === 'server' ? '当前为远程团队模式' : '当前为本机模式';
  } catch (e) {
    if (ticket === settingsTicket) $('preference-status').textContent = e.message;
  }
}
onClick('settings-button', () => showSettings());
for (const button of document.querySelectorAll('[data-settings]')) {
  button.onclick = () => showSettings(button.dataset.settings);
  button.onkeydown = (event) => {
    const buttons = [...document.querySelectorAll('[data-settings]')].filter((b) => !b.disabled);
    let index = buttons.indexOf(button);
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight')
      index = (index + 1) % buttons.length;
    else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft')
      index = (index + buttons.length - 1) % buttons.length;
    else if (event.key === 'Home') index = 0;
    else if (event.key === 'End') index = buttons.length - 1;
    else return;
    event.preventDefault();
    showSettings(buttons[index].dataset.settings, true);
  };
}
onClick('workspace-settings-close', () => $('workspace-settings').close());
$('workspace-settings').addEventListener('close', () => {
  settingsTicket++;
  closeTeam();
  if ($('plugin-dialog').open) $('plugin-dialog').close();
  const trigger = $('settings-button').getClientRects().length ? $('settings-button') : $('sidebar-toggle');
  trigger.focus();
});

async function openSessions() {
  const snap = await rpc('snapshot');
  openDialog('切换本地会话',
    [field('session_id', '会话', 'select', '新建', ['新建', ...snap.sessions.map(s => s.id)])],
    data => changeSession(data.session_id === '新建' ? null : data.session_id));
}

async function newChat() {
  await changeSession(null);
  state.openTools.clear();
  $('prompt').focus();
  await refresh();
}
onClick('new-chat', newChat);

/* ---------- 侧栏与检查器开关 ---------- */

const narrowScreen = matchMedia('(max-width: 760px)');
const overlayInspector = matchMedia('(max-width: 1100px)');
const panels = { desktop: { sidebar: true, inspector: false }, mobile: { sidebar: false, inspector: false } };
try {
  const saved = JSON.parse(localStorage.getItem('codex.layout.v2') || '{}');
  for (const key of ['sidebar', 'inspector'])
    if (typeof saved[key] === 'boolean') panels.desktop[key] = saved[key];
} catch {}
function rememberPanel(key, value) {
  panels[narrowScreen.matches ? 'mobile' : 'desktop'][key] = value;
  try {
    localStorage.setItem('codex.layout.v2', JSON.stringify(panels.desktop));
  } catch {}
}
function setSidebar(open, restoreFocus = false) {
  const sidebar = $('navigation-sidebar');
  const hadFocus = sidebar.contains(document.activeElement);
  if (open && narrowScreen.matches) setInspector(false);
  rememberPanel('sidebar', open);
  $('sidebar-toggle').setAttribute('aria-pressed', String(open));
  $('sidebar-toggle').setAttribute('aria-expanded', String(open));
  $('workspace').classList.toggle('sidebar-collapsed', !open);
  $('workspace').classList.toggle('sidebar-open', open);
  document.querySelector('main').inert = narrowScreen.matches && open;
  if (narrowScreen.matches && open) sidebar.querySelector('a').focus();
  else if (!open && (restoreFocus || hadFocus)) $('sidebar-toggle').focus();
}
function setInspector(open) {
  const inspector = $('workspace-inspector');
  if (open) {
    closePopover();
    closeMenu();
  }
  const hadFocus = inspector.contains(document.activeElement);
  rememberPanel('inspector', open);
  $('inspector-toggle').setAttribute('aria-pressed', String(open));
  $('inspector-toggle').setAttribute('aria-expanded', String(open));
  document.querySelector('.workspace-body').classList.toggle('no-inspector', !open);
  document.querySelector('.conversation').inert = overlayInspector.matches && open;
  if (!open && hadFocus) $('inspector-toggle').focus();
  else if (open && overlayInspector.matches) $('inspector-close').focus();
}
setSidebar(panels[narrowScreen.matches ? 'mobile' : 'desktop'].sidebar);
setInspector(panels[narrowScreen.matches ? 'mobile' : 'desktop'].inspector);
narrowScreen.addEventListener('change', () => {
  const mode = panels[narrowScreen.matches ? 'mobile' : 'desktop'];
  setSidebar(mode.sidebar);
  setInspector(mode.inspector);
});
overlayInspector.addEventListener('change', () =>
  setInspector($('inspector-toggle').getAttribute('aria-pressed') === 'true'),
);
onClick('sidebar-toggle', () => setSidebar($('sidebar-toggle').getAttribute('aria-pressed') !== 'true'));
onClick('sidebar-backdrop', () => setSidebar(false, true));
onClick('inspector-toggle', () =>
  setInspector($('inspector-toggle').getAttribute('aria-pressed') !== 'true'),
);
onClick('inspector-close', () => setInspector(false));
document.querySelector('.sidebar').addEventListener('click', (event) => {
  if (narrowScreen.matches && event.target.closest('#projects button, #new-chat, .row.file'))
    setSidebar(false);
});
document.addEventListener('keydown', (event) => {
  // Let native dialogs handle their own Escape and focus restoration.
  if (event.defaultPrevented || document.querySelector('dialog[open]')) return;
  if (event.key === 'Escape') {
    if (narrowScreen.matches && $('workspace').classList.contains('sidebar-open')) setSidebar(false, true);
    else if ($('inspector-toggle').getAttribute('aria-pressed') === 'true') setInspector(false);
  }
  if (event.key === 'Tab' && narrowScreen.matches && $('workspace').classList.contains('sidebar-open')) {
    const focusable = [
      ...$('navigation-sidebar').querySelectorAll('a, button, select, summary, [tabindex="0"]'),
    ].filter((node) => !node.disabled && node.getClientRects().length);
    const first = focusable[0],
      last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }
});

async function openPluginSettings(ticket){
  const rows=await http('/api/plugins');if(ticket!==settingsTicket||settingsTab!=='plugins')return;
  const body=$('plugin-services');body.replaceChildren();
  for(const service of [...rows,...CodexPlugin.inspect()]){const row=el('p');row.append(el('code',service.service),document.createTextNode(' → '+service.owner));body.append(row);}
  $('settings-panel-plugins').append($('plugin-dialog'));
  if(!$('plugin-dialog').open)$('plugin-dialog').show();
}
onClick('plugin-close',()=>showSettings());
onClick('retry-connection',async()=>{if(state.user)await refresh();else await initialize();});
onClick('jump-bottom',()=>{$('messages').scrollTop=$('messages').scrollHeight;$('jump-bottom').hidden=true;});
$('messages').addEventListener('scroll',()=>{const box=$('messages');if(box.scrollHeight-box.scrollTop-box.clientHeight<120)$('jump-bottom').hidden=true;},{passive:true});
/* ---------- 启动 ---------- */

async function initialize() {
  state.user = await http('/api/me');
  await CodexPlugin.load(state.user.plugins, { rpc, element: el });
  document.body.dataset.mode = state.user.mode;
  $('environment-label').textContent = state.user.mode === 'server' ? '远程工作区' : '本机';
  $('workspace').hidden=false; $('host-login').hidden=true;
  if(state.user.mode==='server'){ $('host-controls').hidden=false; await hostProjects(); if(!state.project){$('team-button').disabled=false;notice('先创建项目，或请项目创建者邀请你。'); if(!state.loopStarted){state.loopStarted=true;loop();} return;} }
  const status = await rpc('status');
  setWorkspaceRoot(status.workspace);
  await refresh();
  if(state.user?.protocol?.capabilities?.includes('suggestions.v1')){await loadPreferences();await updateSuggestions();}
  await loadFiles().catch(e => notice(e.message));
  $('team-button').disabled=false;
  if(!state.loopStarted){state.loopStarted=true;loop();}
}

CodexPlugin.mount({ id: 'builtin.web', services: {
  'markdown.render': { handler: ({ text }) => markdownBuiltin(text) },
  'message.user': { handler: ({ text }) => userBubbleBuiltin(text) },
  'message.assistant': { handler: ({ text, live }) => assistantMessageBuiltin(text, live) },
  'tool.card': { handler: ({ args }) => toolCardBuiltin(...args) },
}});
addEventListener('plugin:changed', () => { messageCache.clear(); executionGroups.clear(); state.signature = ''; });

function loop() {
  setTimeout(async () => { await refresh(); loop(); }, state.snap?.busy ? 200 : 1200);
}

async function hostProjects(preferred) {
 const {projects}=await rpc('projects'); $('host-project').replaceChildren(...projects.map(id=>new Option(id,id)));
 state.project=preferred&&projects.includes(preferred)?preferred:projects.includes(state.project)?state.project:(projects[0]||'');$('host-project').value=state.project;
}
function resetContext(clearRoot = false) {
  notice('');
  closeMenu(); state.design=false;state.designNext=null;updateDesignMode();
  resetSide();
  preferences.loaded=false;suggestions.ticket++;suggestions.loading=false;suggestions.cache=null;suggestions.node.remove();suggestions.lastActivity=Date.now();
  deviceLogin = null;
  if ($('device-login-dialog').open) $('device-login-dialog').close();
  if (state.composerKey) composerDrafts.set(state.composerKey, $('prompt').value);
  state.composerKey = null;
  state.generation++;
  state.switching = false;
  editor.loadTicket++;
  editor.saving = false;
  editor.baseline = '';
  editor.revision++;
  messageCache.clear();
  executionGroups.clear();
  state.signature = '';
  state.toolSignature = '';
  state.snap = null;
  state.openTools.clear();
  state.file = null;
  editor.path = null;
  editor.dirty = false;
  state.expanded.clear();
  catalog.models = null;
  catalog.loading = false;
  catalog.error = '';
  $('tree').replaceChildren();
  $('projects').replaceChildren();
  $('messages').replaceChildren();
  closePopover();
  state.diffSignature = '';
  $('editor').hidden = true;
  $('file-view').hidden = false;
  $('editor-text').value = '';
  for (const id of ['pending-diff', 'term', 'projects']) delete $(id)._signature;
  $('pending-diff').replaceChildren();
  $('diff-view').replaceChildren();
  $('term').replaceChildren();
  $('prompt').value = '';
  if (clearRoot) setWorkspaceRoot('');
  state.projectInfo = null;
}
async function changeSession(id) {
  if (editor.dirty && !confirm('放弃未保存的编辑？')) return;
  // Explicit navigation starts a new submission context; an assigned session ID
  // from an accepted task must not invalidate a failed-response retry.
  sessionStorage.removeItem('codex.pending');
  resetContext();
  const generation = state.generation;
  state.switching = true;
  try {
    await rpc('session', { session_id: id });
  } finally {
    if (generation === state.generation) {
      state.switching = false;
      await refresh();
      await loadFiles();
    }
  }
}
async function switchContext() {
  resetContext(true);
  const generation = state.generation;
  if (!state.project) return;
  state.switching = true;
  try {
    if (state.scope === 'personal') await rpc('personal');
    const status = await rpc('status');
    if (generation !== state.generation) return;
    setWorkspaceRoot(status.workspace);
  } finally {
    if (generation === state.generation) {
      state.switching = false;
      await refresh();
      await loadFiles();
    }
  }
}

$('host-login-form').onsubmit=async event=>{event.preventDefault();try{await http('/api/login',{username:$('host-user').value,password:$('host-token').value});$('host-token').value='';await initialize();}catch(error){$('host-login-error').textContent=error.message;}};
onClick('host-logout',async()=>{await http('/api/logout',{});location.reload();});
$('host-project').onchange=async()=>{if(editor.dirty&&!confirm('放弃未保存的编辑？')){$('host-project').value=state.project;return;}state.project=$('host-project').value;try{await switchContext();}catch(error){notice(error.message);}};
$('host-scope').onchange=async()=>{if(editor.dirty&&!confirm('放弃未保存的编辑？')){$('host-scope').value=state.scope;return;}state.scope=$('host-scope').value;try{await switchContext();}catch(error){notice(error.message);}};
onClick('host-create',openTeamProjectCreate);
onClick('host-manage', () => openTeam('members'));


/* ---------- 团队设置 ---------- */
let teamTicket=0,teamTimer=null,teamDraft=null;
function closeTeam(){if($('team-dialog').open)$('team-dialog').close();}
function teamAction(label,fn,primary=false){const b=el('button',label,primary?'primary':'');b.type='button';b.onclick=async()=>{b.disabled=true;try{await fn();}catch(e){$('team-error').textContent=e.message;}finally{if(b.isConnected&&!b.hasAttribute('data-stopped-only')&&!b.hasAttribute('data-running-only'))b.disabled=false;}};return b;}
function teamNote(text){return el('p',text,'team-note');}
function teamRow(title,subtitle){const row=el('div',undefined,'team-row'),content=el('div');content.append(el('strong',title));if(subtitle)content.append(el('small',subtitle));row.append(content);return row;}
function teamInput(form,label,name,value,type='text'){const group=el('label',label),input=el('input');input.name=name;input.type=type;input.value=value;input.required=true;group.append(input);form.append(group);return input;}
function serverOrigin(value){const url=new URL(value);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash||url.pathname!=='/')throw Error('请填写不含路径或账号的 HTTP/HTTPS 地址');return url.origin;}
function openTeamProjectCreate(){closeTeam();openDialog('创建项目',[field('name','项目名称')],async data=>{const result=await rpc('create',data);state.scope='shared';$('host-scope').value='shared';await hostProjects(result.project);await switchContext();return()=>openTeam('members').catch(e=>notice(e.message));});}
function showTeamToken(result){$('team-token-title').textContent='保存 '+result.username+' 的访问令牌';$('team-token').value=result.token;$('team-token').type='password';$('team-token-show').setAttribute('aria-pressed','false');$('team-token-show').textContent='显示令牌';$('team-token-feedback').textContent='';$('team-token-dialog').showModal();}
onClick('team-token-show',()=>{const input=$('team-token');const show=input.type==='password';input.type=show?'text':'password';$('team-token-show').setAttribute('aria-pressed',String(show));$('team-token-show').textContent=show?'隐藏令牌':'显示令牌';});
onClick('team-token-copy',async()=>{try{await navigator.clipboard.writeText($('team-token').value);$('team-token-feedback').textContent='已复制';}catch{$('team-token').type='text';$('team-token').select();$('team-token-feedback').textContent='请手动复制选中的令牌';}});
onClick('team-token-close',()=>{$('team-token-dialog').close();});
$('team-token-dialog').addEventListener('close',()=>{$('team-token').value='';$('team-token').type='password';openTeam('accounts').catch(e=>notice(e.message));});
onClick('team-close',()=>showSettings());
$('team-dialog').addEventListener('close',()=>{teamTicket++;clearTimeout(teamTimer);teamTimer=null;});

async function openTeam(selected,keyboard=false){
 const ticket=++teamTicket;clearTimeout(teamTimer);$('team-error').textContent='';
 const local=state.user?.mode==='local';const tabs=local?[['service','本机服务'],['accounts','账号'],['remote','连接远程']]:[['members','成员'],['models','共同模型'],['branches','分支'],['activity','活动']];
 selected=tabs.some(x=>x[0]===selected)?selected:tabs[0][0];
 $('team-title').textContent='团队设置';$('team-subtitle').textContent=local?'在本机管理团队服务，或连接已有服务器':state.project?'项目：'+state.project:'先创建项目，或请创建者邀请你';
 $('team-tabs').replaceChildren();for(const [id,label] of tabs){const button=el('button',label);button.type='button';button.id='team-tab-'+id;button.setAttribute('role','tab');button.setAttribute('aria-selected',String(id===selected));button.setAttribute('aria-controls','team-body');button.tabIndex=id===selected?0:-1;button.onclick=()=>openTeam(id,true).catch(e=>notice(e.message));button.onkeydown=event=>{const i=tabs.findIndex(t=>t[0]===id);let next;if(event.key==='ArrowRight')next=(i+1)%tabs.length;else if(event.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabs.length-1;else return;event.preventDefault();openTeam(tabs[next][0],true).catch(e=>notice(e.message));};$('team-tabs').append(button);}
 $('team-body').setAttribute('aria-labelledby','team-tab-'+selected);$('team-body').replaceChildren(el('p','正在加载…'));
 if(!$('workspace-settings').open)$('workspace-settings').showModal();
 if(settingsTab!=='team')selectSettings('team');
 $('settings-panel-team').append($('team-dialog'));
 if(!$('team-dialog').open)$('team-dialog').show();if(keyboard)$('team-tab-'+selected).focus();
 try {if(local){const data=await rpc('team_get');if(ticket!==teamTicket)return;renderLocalTeam(selected,data,ticket);}else {if(!state.project){$('team-body').replaceChildren(teamNote('创建项目后即可管理成员、共同模型和分支。'),teamAction('创建项目',openTeamProjectCreate,true));return;}const info=await rpc('project_status');if(ticket!==teamTicket)return;state.projectInfo=info;await renderHostedTeam(selected,info,ticket);}}catch(e){if(ticket===teamTicket){$('team-body').replaceChildren();$('team-error').textContent=e.message;}}
}
function renderLocalTeam(tab,data,ticket){
 const body=$('team-body');body.replaceChildren();let busy=false,current=data;
 const status=el('p',undefined,'team-note');status.id='team-server-state';
 const paint=next=>{current=next;status.textContent=next.stopping?'停止中…':next.running?'团队服务运行中':'团队服务已停止';for(const control of body.querySelectorAll('[data-stopped-only]'))control.disabled=next.running||busy;for(const control of body.querySelectorAll('[data-running-only]'))control.disabled=!next.running||next.stopping||busy;if(next.error)$('team-error').textContent=next.error;};
 const act=async fn=>{busy=true;paint(current);try{const result=await fn();if(ticket!==teamTicket)return;paint(result);}finally{busy=false;if(ticket===teamTicket)paint(current);}};
 const stopped=b=>{b.dataset.stoppedOnly='';return b;};
 body.append(status);
 if(!data.sandbox_available)body.append(teamNote('当前系统沙箱不可用，Agent 与协作仓库任务会被拒绝执行；服务配置和账号管理仍可使用。'));
 if(tab==='service'){
  const form=el('form');const host=teamInput(form,'监听 IPv4 地址','host',teamDraft?.host??data.host);host.placeholder='0.0.0.0';const origin=teamInput(form,'访问地址（可选）','origin',teamDraft?.origin??data.origin,'url');origin.required=false;origin.placeholder='留空即可通过 IP 和端口直接连接';
  const port=teamInput(form,'本机监听端口','port',teamDraft?.port??String(data.port),'number');port.min='1';port.max='65535';
  for(const input of [host,origin,port]){input.dataset.stoppedOnly='';input.oninput=()=>{teamDraft={host:host.value,origin:origin.value,port:port.value};};}
  const feedback=el('p',undefined,'team-note');feedback.setAttribute('role','status');
  const save=async()=>{if(!form.reportValidity())throw Error('请填写有效地址和端口');const result=await rpc('team_save',{host:host.value,origin:origin.value.trim()?serverOrigin(origin.value.trim()):'',port:Number(port.value)});origin.value=result.origin;port.value=String(result.port);teamDraft=null;return result;};
  const saveButton=stopped(el('button','保存配置'));saveButton.type='submit';
  form.onsubmit=async event=>{event.preventDefault();try{await act(save);feedback.textContent='配置已保存';$('team-error').textContent='';}catch(e){$('team-error').textContent=e.message;}};
  const start=stopped(teamAction('启动团队服务',()=>act(async()=>{await save();return rpc('team_start');}),true));
  const stop=teamAction('停止团队服务',()=>{closeTeam();openDialog('停止团队服务',[],async()=>{await rpc('team_stop',{confirmed:true});return()=>openTeam('service').catch(e=>notice(e.message));},'正在执行的团队任务会被中断，文件和排队任务仍会保留。');});stop.dataset.runningOnly='';
  const actions=el('div',undefined,'team-actions');actions.append(saveButton,start,stop);form.append(actions,feedback);body.append(form);
  body.append(teamNote('0.0.0.0 允许其他设备通过服务器 IP 和端口连接；127.0.0.1 只允许本机连接。访问地址可以留空，HTTPS 代理按需配置。HTTP 不加密传输内容。关闭本地程序也会停止它启动的团队服务。'));
  const details=el('details');details.append(el('summary','部署与数据位置'),el('pre',`直接连接：http://服务器IP:${data.port}\n本机访问：${data.url}\n\n可选 HTTPS 代理示例：\ncodex.example.com {\n    reverse_proxy 127.0.0.1:${data.port}\n}\n\n数据目录：${data.state_dir}`));body.append(details);
  if(data.url)body.append(teamAction('打开团队网页',()=>window.open(serverOrigin(current.url),'_blank','noopener,noreferrer')));
 } else if(tab==='accounts'){
  body.append(teamNote('先停止本机托管的团队服务，再登记或重置登录账号；项目成员仍由项目创建者管理。'));
  body.append(stopped(teamAction('登记账号',()=>{closeTeam();openDialog('登记团队账号',[field('username','用户名')],async fields=>{const result=await rpc('team_account',fields);return()=>showTeamToken(result);});},true)));
  if(!data.users.length)body.append(teamNote('还没有登录账号。登记至少一个账号后即可启动服务。'));
  for(const name of data.users){const row=teamRow(name,'访问令牌不会在这里回显');row.append(stopped(teamAction('重置令牌',()=>{closeTeam();openDialog('重置 '+name+' 的访问令牌',[],async()=>{const result=await rpc('team_account',{username:name,confirmed:true});return()=>showTeamToken(result);},'旧令牌将失效。服务重启后，该用户需要用新令牌重新登录。');})),stopped(teamAction('停用账号',()=>{closeTeam();openDialog('停用 '+name,[],async()=>{await rpc('team_revoke',{username:name,confirmed:true});return()=>openTeam('accounts').catch(e=>notice(e.message));},'账号将无法登录，不删除项目文件。同名账号重新登记后会恢复原有的成员关系。');})));body.append(row);}
 } else {
  const form=el('form'),url=teamInput(form,'服务器 HTTP/HTTPS 地址','server',data.url,'url');url.placeholder='http://192.168.1.10:8766';const button=el('button','打开服务器登录页','primary');button.type='submit';form.append(button);form.onsubmit=event=>{event.preventDefault();try{window.open(serverOrigin(url.value),'_blank','noopener,noreferrer');}catch(e){$('team-error').textContent=e.message;}};body.append(form,teamNote('账号和访问令牌在服务器登录页填写，不会发送给当前本地服务。'));
 }
 paint(data);
 if(tab!=='remote'){const poll=async()=>{try{const next=await rpc('team_get');if(ticket!==teamTicket)return;paint(next);}catch(e){if(ticket===teamTicket)$('team-error').textContent=e.message;}if(ticket===teamTicket&&$('team-dialog').open)teamTimer=setTimeout(poll,1000);};teamTimer=setTimeout(poll,1000);}
}
async function sharedProviderSettings(){if(editor.dirty&&!confirm('切换到共同会话会丢弃未保存的编辑，是否继续？'))return;closeTeam();state.scope='shared';$('host-scope').value='shared';await switchContext();await fillProviders();}
async function renderHostedTeam(tab,info,ticket){
 const body=$('team-body');body.replaceChildren();const owner=info.owner===state.user.username;
 const reopen=()=>openTeam(tab).catch(e=>notice(e.message));
 const enqueue=(op,data={})=>rpc(op,{...data,request_id:newId()});
 if(tab==='members'){
  body.append(teamNote('创建者管理成员和共同凭据；所有成员的开发与审批权限相同。'));
  if(owner)body.append(teamAction('邀请成员',async()=>{const {users}=await rpc('member_candidates');if(ticket!==teamTicket)return;if(!users.length){$('team-error').textContent='没有可邀请的账号，请先在服务器本机的团队设置中登记账号。';return;}closeTeam();openDialog('邀请项目成员',[field('username','用户名')],async fields=>{await rpc('invite',fields);return reopen;});const input=$('dialog-body').querySelector('[name=username]'),list=el('datalist');list.id='team-candidates';for(const name of users)list.append(new Option(name,name));input.setAttribute('list',list.id);$('dialog-body').append(list);},true));
  for(const member of info.members){const row=teamRow(member,member===info.owner?'项目创建者':'项目成员');if(owner&&member!==info.owner)row.append(teamAction('移除成员',()=>{closeTeam();openDialog('移除 '+member,[],async()=>{await rpc('remove',{username:member});return reopen;},'此成员将失去项目访问权限，排队任务会被取消，个人文件仍保留。');}));body.append(row);}
  body.append(teamAction('创建另一个项目',openTeamProjectCreate));
 } else if(tab==='models'){
  const data=await rpc('providers',{scope:'shared'});if(ticket!==teamTicket)return;
  body.append(teamNote(owner?'共同会话使用这里的项目凭据；个人会话仍使用每位成员自己的凭据。':'共同凭据由项目创建者配置；你可以使用，但无法读取或修改密钥。'));
  for(const provider of data.providers)body.append(teamRow(provider.name,(provider.id===data.active?'正在使用 · ':'')+(provider.has_key?'密钥已配置':provider.id==='codex'?'订阅登录':'未配置密钥')));
  body.append(teamAction(owner?'配置共同模型':'选择共同模型',sharedProviderSettings,true));
 } else if(tab==='branches'){
  body.append(teamNote('个人与共同工作区各自独立。先发布个人分支，再明确合并到共同分支。'));
  body.append(teamAction('查看 Diff',()=>{closeTeam();showInspector('changes');return loadDiff();}));
  const actions=el('div',undefined,'team-actions');
  actions.append(teamAction('发布个人分支',()=>{closeTeam();openDialog('发布个人分支',[field('message','提交说明')],fields=>enqueue('publish',fields));}),teamAction('同步共同分支',()=>{closeTeam();openDialog('同步共同分支',[],()=>enqueue('sync'),'个人工作区必须干净；冲突时保留原目标。');}),teamAction('提交共同修改',async()=>{const preview=await rpc('diff',{scope:'shared'});closeTeam();openDialog('检查并提交共同修改',[field('message','提交说明')],fields=>enqueue('checkpoint',{...fields,scope:'shared',fingerprint:preview.fingerprint}),JSON.stringify(preview,null,2));}),teamAction('合并成员分支',()=>{closeTeam();openDialog('选择成员',[field('username','用户名','select','',info.members)],async fields=>{const latest=await rpc('project_status'),source=latest.branches['users/'+fields.username];if(!source)throw Error('成员尚未发布分支');return()=>openDialog('确认合并',[],()=>enqueue('merge',{...fields,scope:'shared',source,target:latest.head,confirmed:true}),`来源 ${source}\n目标 ${latest.head}\n冲突时保留原目标。`);});}));body.append(actions);
  for(const [name,sha] of Object.entries(info.branches))body.append(teamRow(name,sha));
 } else {
  if(info.blocked){body.append(teamNote('任务中断后需要检查文件再恢复队列。'));if(owner)body.append(teamAction('检查并恢复队列',async()=>{const preview=await rpc('diff',{scope:'shared'});closeTeam();openDialog('恢复队列',[],()=>rpc('recover',{fingerprint:preview.fingerprint,confirmed:true}),JSON.stringify(preview,null,2));}));}
  const labels={queued:'排队中',running:'执行中',completed:'已完成',failed:'失败',interrupted:'已中断',cancelled:'已取消'};
  body.append(el('h3','最近任务'));if(!info.jobs.length)body.append(teamNote('还没有任务'));
  for(const job of info.jobs.slice(-20).reverse()){const row=teamRow(job.actor+' · '+job.op,(labels[job.status]||job.status)+(job.scope==='personal'?' · 个人会话':' · 共同会话'));if(job.result?.error)row.firstChild.append(el('small',job.result.error));body.append(row);}
  body.append(el('h3','操作记录'));if(!info.audit?.length)body.append(teamNote('还没有操作记录'));
  const operations={invite:'邀请成员',remove:'移除成员',approve:'审批操作',provider_save:'配置提供商',provider_use:'切换提供商',model:'切换模型',reasoning:'调整推理强度',recover:'恢复队列',stop:'停止任务'};
  for(const entry of (info.audit||[]).slice(-20).reverse())body.append(teamRow(entry.actor+' · '+(operations[entry.op]||entry.op),new Date(entry.time*1000).toLocaleString()));
 }
}

initialize().catch(e => notice(e.message));

})();
