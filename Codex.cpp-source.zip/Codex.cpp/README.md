# Codex.cpp：原生网页与多人服务

同一个 C++17 程序提供命令行 Agent、本地网页 `web` 和多人网页服务 `serve`。
本地及多人服务均由 C++ 实现，不需要 Python、Node.js 或前端构建工具。
浏览器就是客户端：本地模式操作本机工作区，服务器模式操作服务器上的工作区。
保留文件树、编辑器、工具审批、会话记录、两级模型菜单与自定义模型提供商。

程序始终使用 [内置 Git（libgit2）](docs/LIBGIT2_TRIAL.md)：网页 Diff、多人协作、
`apply_patch` 和 `git_read` / `git_write` 模型工具均无需系统 Git，沿用只读限制、写审批和系统沙箱。

## 编译

需要 CMake、C/C++ 编译器（主程序 C++17），不需要 Python。保留全部 `.inc` 源文件；
CMake 将网页资源直接编入程序；`web/` 目录仅在开发和覆盖页面时使用。
Linux/macOS 构建另需 OpenSSL 开发包及静态库；Windows 使用系统 Schannel。

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
```

Linux/macOS/Termux 产物通常是 `build/codex-cpp`；Windows 可使用 Visual Studio 或 MinGW，
Visual Studio 产物通常是 `build/Release/codex-cpp.exe`。
首次配置会下载固定版本 libgit2、libcurl 并校验 SHA-256，之后复用缓存；
离线构建可加 `-DFETCHCONTENT_SOURCE_DIR_CODEX_LIBGIT2=/path/to/libgit2` 和
`-DFETCHCONTENT_SOURCE_DIR_CODEX_CURL=/path/to/curl` 指定已取得的依赖源码。

后端开关和系统 Git 回退实现已移除；旧缓存中的关闭选项也不会再禁用内置 Git。
不需要任何启用宏或后端选择参数。CMake 会自动编译、链接依赖。

### 使用 g++（GCC）编译

在项目根目录执行，使用新的构建目录，避免复用其他编译器的 CMake 缓存：

```sh
cmake -S . -B build-gcc -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++
cmake --build build-gcc --config Release --parallel 2
./build-gcc/codex-cpp --help
```

Linux/Unix 下产物为 `build-gcc/codex-cpp`。启动本地网页：

```sh
./build-gcc/codex-cpp web --root /path/to/project
```

打开 `http://127.0.0.1:8765`。以上命令不需要额外的内置 Git 启用宏；
CMake 会用指定的 g++ 编译 C++17 主程序，并生成内嵌网页、构建和链接 libgit2、libcurl 等依赖。
单独执行 `g++ codex.cpp -o codex-cpp` 不足以完成当前项目的构建。
需要查看具体编译、链接命令时，执行 `cmake --build build-gcc --config Release --verbose`。

macOS 系统自带的 `gcc` / `g++` 通常实际是 Apple Clang，可用 `g++ --version` 确认。
若需要真正的 GNU GCC，先安装它，再将上面的编译器名称替换为实际安装的版本命令
（例如 `gcc-15` / `g++-15`），并使用新的构建目录。
macOS 若通过 Homebrew 安装 OpenSSL，可在配置命令中追加
`-DOPENSSL_ROOT_DIR="$(brew --prefix openssl@3)"`。
Windows MinGW 的配置还应指定 `-G "MinGW Makefiles"`，产物为 `build-gcc/codex-cpp.exe`。

### 运行依赖

网页、登录、编辑文件和模型请求不需要其他语言运行时或系统 `curl`；
上述 Git 操作不需要 Git 可执行文件，模型通过 Shell 主动运行其他 Git 命令时才需要安装它。
Agent 受限执行仍需要系统沙箱：Linux 使用 `bubblewrap`，macOS 使用 `sandbox-exec`。
Linux Release 将 bubblewrap 一起嵌入单文件，但仍需内核允许用户命名空间。
请以普通用户运行，程序拒绝以 root 启动网页服务。

### 平台验证范围

| 平台 | 当前状态 |
| --- | --- |
| Linux | 已验证本地网页、真实 Agent 子进程、审批、多人队列、分支冲突与重启恢复 |
| Windows | 提供 x86、x64、ARM64 单文件构建与运行测试；AppContainer 沙箱未实现，受限 Shell、沙箱 Git 和团队开发操作仍会拒绝执行；模型 HTTP 请求不再依赖沙箱 |
| macOS | 提供原生实现和 CI 构建配置，尚未实机验证；Agent 依赖系统提供可用的 `sandbox-exec` |
| Android / Termux | 不依赖 Python，尚未实机验证；Agent 运行取决于设备内核和应用权限是否允许所需的 Linux 沙箱 |

跨平台编译成功不等于完成所有平台的 Agent 沙箱。受限模式缺少沙箱时拒绝执行，不会自动放宽权限。
Windows/Android 设备也可以直接用浏览器连接已部署的 Linux 服务器，不需要在客户端安装这些工具。

### 单文件下载

[GitHub Releases](https://github.com/turtlelnc/Codex.cpp/releases) 的发布流程涵盖 Windows x86（32 位）、
x64、ARM64，macOS Intel / Apple Silicon，以及 Linux x64 / ARM64。
每个平台先验证把可执行文件独立复制到空目录、清空子进程 PATH 后的模型与网页功能，
并检查动态库依赖；全部成功才发布七个文件与 `SHA256SUMS.txt`。
Windows 静态链接 CRT，macOS 静态链接 OpenSSL 并使用系统证书信任，Linux 使用静态 musl/OpenSSL。
无需额外 DLL、网页目录、Python、Node、Git 或 curl 可执行文件。
macOS 建议下载 `.zip`，Linux 建议下载 `.tar.gz`；解压后仍是一个文件，并保留执行权限。
浏览器直接下载裸文件时通常会丢失执行权限，Finder 可能将其当作文本文件。
此时在终端对实际文件运行 `chmod +x 文件名`，再用 `./文件名` 启动。
运行 `--licenses` 可查看内嵌许可证；平台限制和可选工具依赖见 [发行说明](docs/RELEASE_NOTES.md)。

## TUI 团队设置

在终端运行 `./codex-cpp --ui tui`，输入 `/team` 打开菜单。
可配置监听 IPv4 地址和端口，登记账号、重置令牌、撤销账号，并启动或停止团队服务。
访问地址可以留空，直接用 `http://服务器IP:端口` 连接，不需要域名、证书或反向代理。
`0.0.0.0` 监听所有 IPv4 接口，`127.0.0.1` 只允许本机连接。
令牌只在临时面板显示一次，不写入会话或输入历史。
账号操作必须先停服，撤销账号保留项目文件；退出 TUI 会停止由它启动的服务。
配置与 WebUI 的“团队”入口共用，数据默认在 `~/.codex-cpp/team-server`。
两处均只管理自己启动的进程，不能接管另一实例；切换管理入口前请先停服。
选择“Team projects (HTTP/HTTPS)”可直接在 TUI 登录本机或远程团队服务器，无需打开浏览器。
支持创建项目、邀请和移除成员、共同及个人模型配置、模型选择、分支发布与同步、
审阅共同修改并提交、确认精确 SHA 后合并、查看任务和操作审计、检查文件后恢复中断队列。
共同凭据仍只允许创建者配置；成员可以使用，无法查看密钥。

项目菜单“Agent tasks on server”支持共同或个人会话的任务排队、查看会话、审批和停止任务。
其他成员也可以审批共同任务，服务器记录实际操作人。这里的任务始终操作服务器工作区；
退出团队菜单后的普通聊天仍使用当前本地工作区。
访问令牌和 API 密钥输入会被遮罩，登录 Cookie 只存在进程内存中，退出登录会撤销会话。
HTTP 不加密传输内容；需要加密时可选用 HTTPS 代理。HTTPS 证书照常校验，不提供跳过验证的开关。

## 本地网页

```sh
./codex-cpp web --root /path/to/project
```

打开 `http://127.0.0.1:8765`。本地模式自动建立会话，不需要登录；服务只监听回环地址，
校验 Host、Origin、SameSite Cookie 和 CSRF。可以用 `--port` 改端口，或用 `--web-dir` 指定静态资源目录。
在 CMake 构建目录使用 `./build/codex-cpp`（Windows 使用对应 `.exe` 路径）。

网页默认以对话和工具审批为主，侧栏用于会话与项目导航，项目文件可折叠。编辑器、Diff 与终端通过右上角检查器按需打开，连续工具记录可展开查看原始参数和日志。
编辑器支持 Ctrl/⌘+S；只能保存已有普通文件，单文件上限 1 MiB，不提供新建、删除或重命名。
符号链接、硬链接、特殊文件和内部状态目录会被拒绝；二进制和无效 UTF-8 文件只读。
保存时校验 SHA-256，文件被其他人或 Agent 修改后，需要重新载入再保存。

### 模型与提供商

模型按钮先打开推理强度面板，点击模型名称进入模型列表。列表从当前提供商获取，
也可在提供商配置里填写模型 ID；页面不硬编码某一组模型名称。能否选择推理强度取决于提供商能力。

- 内置 Codex 使用订阅设备登录，可在网页中登录；本地也可先运行 `./codex-cpp --provider codex --login`。
- OpenAI、DeepSeek 等兼容服务可在设置里添加，填写服务地址、`chat` / `responses`、模型 ID 和密钥。
- 密钥不返回页面，不放进 Agent 命令参数；自定义密钥通过子进程环境变量传递。
- 本地提供商配置保存在 `~/.codex-cpp/web-providers.json`，可用 `CODEX_CPP_HOME` 改目录。
  同一用户的本地工作区共用该配置。已有的这一格式可以继续读取。
- 也支持启动参数，例如设置好 `DEEPSEEK_API_KEY` 后运行：

```sh
./codex-cpp web --root /path/to/project --provider deepseek
```

`--model`、`--base-url`、`--api`、`--api-key-env`、`--no-api-key` 和 `--reasoning` 也可用于本地模式。
执行权限在网页中选择；多人服务禁止不受限的 `full` 模式。

## 多人服务器

团队连接现在协商协议和能力，而不是要求软件版本相同。服务器验证每个远程 RPC 的协议选择；旧客户端需要服务器显式加载官方兼容插件。新客户端连接不能协商安全语义的旧服务器时，只开放读取。安装方法、支持范围和插件接口见 [团队协议与兼容适配器](docs/TEAM_PROTOCOL.md)。

### 从 WebUI 配置

运行 `./codex-cpp web --root /path/to/project` 后，点击顶部“团队”。
在“本机服务”中设置监听 IP 与端口，访问地址留空；在“账号”中登记成员并保存仅显示一次的访问令牌，
再启动团队服务。成员直接打开 `http://服务器IP:端口`，使用用户名和令牌登录即可。
如需固定域名或 HTTPS 代理，再填写对应的访问地址；页面提供可选代理示例。

此入口使用 `<CODEX_CPP_HOME>/team-server` 保存团队数据（默认 `~/.codex-cpp/team-server`），
与当前本地项目分开。它仅管理自己启动的服务，不接管单独运行的 `serve` 进程。
关闭浏览器标签页不会停止服务；退出本地 Codex.cpp 进程会停止其托管的团队服务。
新增、重置或撤销账号需要先停止团队服务；重置与撤销不会删除项目文件。
当前平台缺少工作区沙箱时，页面会提示限制，团队开发仍要求可用的沙箱。

登录团队服务器后，“团队”面板提供成员、共同模型、分支和活动四个页面。
项目创建者可邀请已登记账号、移除成员及配置共同模型凭据；所有成员拥有相同开发和审批权限。
个人模型凭据仍在个人工作区配置。

### 从命令行配置

先创建账户。以下命令会各输出一次随机访问令牌，请私下保存；登录时填写用户名与该令牌。
服务只保存令牌的 SHA-256 摘要，不使用用户自选密码。

```sh
./codex-cpp serve --state-dir /srv/codex-data --add-user alice
./codex-cpp serve --state-dir /srv/codex-data --add-user bob
./codex-cpp serve --state-dir /srv/codex-data --host 0.0.0.0 --port 8766
```

`/srv/codex-data` 须由运行服务的普通用户拥有且可写；也可以选择用户自己的目录。
新增、重置或撤销账户前必须停止服务，状态目录有独占写锁。对已有用户名再次 `--add-user` 会重置其令牌；
`--revoke-user bob` 撤销账户。账户管理命令不需要 `--origin`。

不填写 `--origin` 时，服务默认监听 `0.0.0.0`，通过 `http://服务器IP:端口` 直接访问。
直接连接模式接受监听 IP（以及本机的 `localhost`），校验请求端口、同源 Origin 和 CSRF；
使用自定义 DNS 名称时，可填写可选的 `--origin http://名称:端口` 并设置相应的监听地址。

HTTPS 反向代理是可选部署方式。已有 HTTPS 配置保持兼容，填写 `--origin` 且未指定 `--host` 时仍默认只监听本机：

```sh
./codex-cpp serve --state-dir /srv/codex-data --host 127.0.0.1 --port 8766 --origin https://codex.example.com
```

以 Caddy 为例：

```caddyfile
codex.example.com {
    reverse_proxy 127.0.0.1:8766
}
```

代理应保留浏览器的 Host、Origin，外部地址必须与 `--origin` 完全一致，包括非默认端口。
登录 Cookie 使用 HttpOnly、SameSite=Strict，HTTPS 模式额外使用 Secure，8 小时过期；重启需重新登录。
不需要 Docker，之后可按部署需求增加容器。

### 协作方式

登录后可创建项目、选择共同或个人工作区，创建者可以邀请已登记的账户。

- 创建者管理成员及共同会话的模型凭据；成员只能使用共同凭据，不能通过页面读取或修改密钥。
- 所有成员的开发权限相同。共同会话人人可发任务、停止任务和审批，审批记录实际登录的操作人。
- 每人有独立个人工作区、分支、会话和模型凭据；共同会话也有独立工作区和分支。
  页面不向其他成员提供个人会话、个人任务内容或个人审批。服务器管理员仍能访问磁盘上的数据。
- 每个项目的 Agent 与分支任务按 FIFO 串行执行，避免共同修改互相覆盖；不同项目可并行。
- 先在个人工作区开发，再“发布个人分支”，最后在共同工作区明确合并。
  合并需确认来源和目标的精确提交 SHA，排队期间分支变化会拒绝本次操作。
- 共同工作区的修改可先审阅 Diff 和未跟踪文件，再提交；内容变化后需重新确认。
  项目执行任务期间，网页编辑器暂停保存，避免覆盖运行中的修改。

新项目从空仓库开始。目前不提供远程仓库导入、自动 GitHub 推送或 PR 接口。
首次导入可由管理员把文件放进对应的 `workspaces/<项目>/shared/`，再通过网页审阅并提交。
服务器启动参数不接受全局模型密钥；请分别配置共同和个人提供商。

### 分支冲突

共同分支合并发生冲突时，会返回冲突路径并中止合并，保持目标分支原状。
个人工作区“同步共同分支”也会在冲突时中止，不会自动选一方覆盖。

需要人工解决时，先在个人工作区同步一次，再由 Agent 或操作者在该个人目录里运行
`git merge --no-ff FETCH_HEAD`，编辑冲突文件并 `git add`、`git commit`，然后重新发布个人分支，
由成员再次审阅并合并。失败的同步会保留 `FETCH_HEAD` 供此流程使用。
正式仓库存放在状态目录的 `repositories/` 中；工作区 `.git` 是给 Agent 使用的副本，发布会导入个人副本的提交历史。
服务器 Git 操作在系统沙箱内执行，不在主机上加载 Agent 修改过的 Git 配置或钩子。

### 中断与恢复

任务进入运行状态前会持久化；服务重启后，结果不明的运行任务标记为 `interrupted`，阻塞该项目的队列。
等待中的任务保留，不会自动重放中断任务。创建者应检查实际文件和旧进程是否已经退出，
在网页“检查并恢复队列”中明确确认后继续；涉及的个人/共同 Agent 会话会重新开始，旧会话记录仍保留。
存在未完成的正式仓库合并时，必须先由管理员解决或中止后才能恢复。
Linux 设置父进程退出信号，Windows 使用 Job Object 管理原生子进程；macOS 异常退出后的进程清理尚未实测。

### 数据、权限与规模

这是给可信团队使用的应用级多用户服务。账户和凭据在应用内分开，Agent 工具受工作区沙箱限制，
但进程仍使用同一个操作系统服务账号；没有为每位用户建立独立 Unix UID、容器或虚拟机，
不适合把互不信任的租户当作已完成系统级隔离来部署。
状态目录包含工作区、凭据和会话，必须限制访问并备份；POSIX 使用私有权限，Windows 设置所有者/系统 ACL。

当前限制：100 个项目、16 个同时执行的项目、每项目 100 个等待任务、全局 128 个等待任务，
总任务记录上限 5000；到达上限拒绝新增，避免丢失请求去重记录。每项目保留最近 1000 条操作审计。
HTTP 使用固定线程池和有界队列；不提供 WebSocket 实时共同光标，页面通过轮询同步。
Git 元数据归档与会话会增长，需要管理员监控磁盘容量。本版不自动迁移旧 Python 多人服务数据库。

## Everything is a Plugin（实验性）

内置模型、Agent 回合、提示词、工具执行、会话写入和网页渲染已接入可替换服务。默认仍为单文件；C/C++ 原生模组通过启动前缀 `--plugin /绝对路径/plugin.json` 显式加载。使用 `codex-cpp plugin inspect`、TUI `/plugin` 或网页左下角“模组”查看当前提供者。

示例、C ABI、服务契约、权限及平台限制见 [Plugin 开发指南](docs/PLUGIN.md)。原生模组是完全可信代码；现有 Linux musl 全静态 Release 不能加载动态库，Linux 原生模组需使用正常 glibc 构建。默认功能与纯网页扩展不受此限制。

### 让 Agent 制作插件

内置 `plugin-creator` Skill 与脚手架、构建、检查、隔离测试工具。可以直接要求 Agent 制作 Plugin 插件；完成后在对话中审阅文件与测试结果，再手动重启启用。程序内嵌 SDK，不需要项目源码。原生构建需要 CMake/C++17；Windows 暂不支持自动沙箱构建/探测。详见 [Creator 工作流](docs/PLUGIN_CREATOR.md)。

## 便携数据、更新与分享

同一份数据可在不同设备间迁移；程序仍按操作系统和 CPU 分别编译，不修改可执行文件来保存账户。前缀选项必须放在子命令及其他选项之前：

```sh
./codex-cpp --portable-dir ./codex-data --portable-project my-repo
./codex-cpp --portable-dir ./codex-data --portable-project my-repo web --port 9080
```

账户及提供商配置在数据目录的 `user/`，会话在 `projects/<ID>/`。跨设备使用相同项目 ID 可找回会话；不同项目请用不同 ID。省略 ID 时按工作区绝对路径生成标识。工程源码不包含在数据包中，需要另行复制或克隆。首次启用不会自动复制原来的账户或会话；可以重新登录，或在程序停止时将原配置复制到新目录的 `user/`、将原 `.codex_cpp/` 内容复制到 `projects/<ID>/`。便携模式仅支持本地运行，多人 `serve` 继续使用独立的 `--state-dir`。

```sh
# 普通导出不包含账户及提供商配置，但会话和插件本身仍可能含敏感信息
./codex-cpp --portable-dir ./codex-data portable export ./profile.pack
# 设置 PACK_PASSWORD 环境变量后，导出含凭据的加密包（不要把密码写进命令行）
./codex-cpp --portable-dir ./codex-data portable export ./private.pack --include-credentials --password-env PACK_PASSWORD
# 导入目的目录必须不存在；错误密码、篡改或路径冲突不会覆盖已有数据
./codex-cpp --portable-dir ./restored-data portable import ./private.pack --password-env PACK_PASSWORD
```

加密传输包使用 PBKDF2-HMAC-SHA256（600000 次）与 AES-256-GCM；运行时数据目录仍是明文，**尚未实现启动密码或磁盘静态加密**。导入会禁用插件，并把自动启动的 MCP 配置移至 `user/mcp.imported.json`，审核后再手动恢复。导出需要先停止使用此数据目录的程序；限制 4096 个文件、总计 128 MiB，不跟随链接，不覆盖已有包。请保护环境变量和解密后的目录。

TUI 中 `/web` 启动本机 WebUI 并打开浏览器，`/web start` 只显示地址，`/web status` 查看状态，`/web stop` 返回终端。两者共享已保存会话；这不是正在执行任务的实时移交。网页运行期间暂停终端任务，停止后重新读取会话。

```sh
./codex-cpp --portable-dir ./codex-data update check
./codex-cpp --portable-dir ./codex-data update download       # 可追加指定 Release tag
./codex-cpp --portable-dir ./codex-data update status
./codex-cpp --portable-dir ./codex-data update install --yes  # 关闭所有使用该目录的程序后执行
./codex-cpp --portable-dir ./codex-data update rollback --yes
```

交互模式可用 `/update check`、`/update download` 在后台查询或下载，`/update status` 查看结果。下载不会执行或安装；`/update install` 需确认后退出再安装。只从官方仓库 Release 选择匹配平台、CPU 和运行库的资产，校验 HTTPS、大小及 GitHub SHA-256。**这不是独立发布者签名验证**；信任仍包括 GitHub 仓库和发布账户。旧版本若不支持便携格式握手，会拒绝安装。

安装前再次校验缓存与目标，保留同目录备份，数据目录不被替换；元数据写入失败会尝试恢复旧程序，预先记录恢复凭据（不保证断电后文件系统的完整性）。Windows 通过退出后的辅助进程替换程序。请通过 `update status` 确认最终结果；备份和辅助程序暂不自动清理。不同设备不要同时写入同一个同步目录，文件锁不是分布式同步协议。

插件可静态打包分享，不会在导入时执行或自动启用：

```sh
./codex-cpp plugin export ./my-plugin ./my-plugin.pack
./codex-cpp plugin import ./my-plugin.pack ./imported-plugin
```

分享包校验用于完整性，不证明作者身份或安全性。原生库只能用于对应平台，其他平台需重新构建；启用原生插件仍代表信任其具有宿主进程权限。

## 长会话与上下文预算

```sh
./codex-cpp --provider custom --model my-model --base-url https://example.com/v1 \
  --context-window 32768 --output-reserve 4096
# WebUI 使用相同选项，启动的 Agent 子进程会继承预算
./codex-cpp web --context-window 131072 --output-reserve 8192
```

请按当前模型的实际窗口配置 `--context-window`，或设置 `CODEX_CPP_CONTEXT_WINDOW`。未配置时保守使用 32768；输出预留默认 `min(4096, window/8)`，可用 `--output-reserve` 或 `CODEX_CPP_OUTPUT_RESERVE` 修改。切换到窗口更小的模型时，也应调整部署预算。本版不根据模型名称猜测窗口，也不额外请求模型目录来推断它。

每次请求前按实际输入、系统提示词和工具定义估算 token，扣除输出预留及窗口的 10% 安全余量，再决定是否压缩。ASCII 约按每 3 字节一个 token、非 ASCII 每字节一个 token 保守估算，每张内联图片暂计 4096；**这不是精确 tokenizer，也不能保证匹配所有模型的图片计费**。输出预留用于输入预算，不强制更改现有提供商的输出上限参数，以保留不同 API 的兼容性。

压缩复用已有摘要，只加入新增记录；按预算分片，保留最新用户消息。第一次处理超长历史仍可能需要多次串行摘要请求。摘要失败或最新输入放不下时，不覆盖原上下文；输入会保留，并明确报错。

transcript 只追加写入，恢复时的内存显示尾部不覆盖磁盘原文，fork 复制完整原文；旧文本会话分段、原子地迁移。WebUI 按最多 16 MiB 的尾部窗口解析最近 400 条记录，窗口外的历史不会因此删除，界面会显示提示；完整工具日志按需流式读取。尚未提供无限滚动历史索引。

WebUI 仍使用 HTTP 轮询，但新客户端携带快照版本，只传输变化字段、变化的历史行及行顺序；基准过期、服务重启或页面刷新时恢复完整快照。旧客户端仍可获取原有完整快照。无需新增语言运行时或前端框架。

## 验证

Node.js 仅用作测试运行器，正式运行不需要它：

```sh
node tests/native_smoke.cjs ./build/codex-cpp
cmake --build build --target codex-self-test --parallel 2
./build/codex-self-test
node tests/native_web_test.cjs ./build/codex-cpp
node tests/team_service_test.cjs ./build/codex-cpp
```

第一项不依赖 Agent 沙箱；后两项完整测试需要受限进程执行可用，集成测试还需要 `curl` 和 `git`。
测试使用本地假模型服务，不消耗模型额度。浏览器回归脚本另需 Playwright、Chromium 和 OpenSSL。
GitHub Actions 配置包含 Linux/macOS/Windows 构建与基础冒烟测试，以及 Linux 集成测试。

WebUI 状态边界、浏览器回归运行方法和验证范围见 [WebUI 质量说明](docs/WEBUI_QUALITY.md)。

对话优先布局、真实工具摘要及完整日志接口的实现与验证边界见 [WebUI 对话布局说明](docs/WEBUI_CONVERSATION.md)。

WebUI 的独立只读侧聊、设置入口和默认关闭的自动下一步建议，见 [WebUI 辅助功能](docs/WEBUI_ASSISTANCE.md)。

WebUI 的模型运行状态、重试规则和独立 Markdown 渲染模块，见 [WebUI 流式状态与渲染](docs/WEBUI_RENDERING.md)。

WebUI 支持 `@` 插件引用、键盘滚动的斜杠菜单，以及 `/design` / `/design plan`，见 [输入辅助与 Design 模式](docs/WEBUI_COMPOSER.md)。

WebUI 的「设置」与 TUI 的 `/settings` 共用本地偏好、提供商和团队配置；远程设置按服务器账号和工作区隔离。支持选择是否回传提供商实际返回的历史推理文本，工具模式按协议保留已有推理，无工具模式可选回传。详见 [设置与同步](docs/SETTINGS.md)。

### 实验性内嵌页面预览

`codex-cpp preview shot index.html -o preview.png --width 1280 --height 800` 使用同一可执行文件内的 MiniWeb 生成截图，不依赖 Chromium、Python 或 Node.js。Agent 可用 `preview_screenshot` 获取图片并回传支持视觉的模型。它只读取工作区本地资源，禁止网络，需要可用的 OS 沙箱；Windows 当前明确拒绝执行。CSS/DOM 仅支持部分能力，不能作为真实浏览器兼容性验收。完整边界、命令和已知缺口见 [MiniWeb 文档](docs/MINIWEB.md)。
